# 清灵之眼 · CellSight

**以自然语言组织科学计算机视觉任务，用可追溯的规划、执行与评价连接 LLM 和 CV。**

CellSight 使用 MoE-inspired Skill Routing 按任务选择能力，以 Evals as PRDs 指导研发和回归。这个仓库整理了 **73 个独立 Skill：1 个 Planner、1 个 Evaluation Meta-Skill、71 个执行 Skill**。执行能力分属 12 类，所有 Skill 平级；类别是检索标签。

这是从既有交付中整理的核心源码快照，整理日期为 2026-11-01。执行库基线为 v0.2.1，控制运行时为 v0.5.1，控制指令采用 v1.1.1 加载补丁。[版本来源与整理范围](docs/RELEASE.md)

## 工作方式

```mermaid
flowchart LR
    U[科研需求] --> P[Planner: Task Intent]
    P --> E[Evaluation: Spec 草案]
    E --> D[共同发现能力]
    D --> F[保存规范版本与 hash]
    F --> L[Planner: 正式计划]
    L --> X[按需加载执行 Skill]
    X --> R[Evaluation: 真实产物与报告]
    R --> B{预算与修订上限}
    B -->|有限修订| L
    B -->|完成或需人工处理| O[结果、证据与局限]
```

宿主 LLM 理解自然语言并加载 Skill；包内 Python 工具处理结构化输入。仓库没有通用的 71 模型自动调度桥，也没有 SciencePal 私有安装 API。

## 快速开始

在仓库根目录执行，推荐 Python 3.12：

```bash
python -m venv .venv
# Windows PowerShell: .venv/Scripts/Activate.ps1
# macOS/Linux: source .venv/bin/activate
python -m pip install -r requirements.txt
python scripts/validate_repository.py
python -B -m unittest discover -s tests -p 'test_meta.py' -v
python -B -m unittest discover -s tests -p 'test_legacy_interfaces.py' -v
python -B examples/run_numeric_examples.py --output work/numeric-example-001
```

数值例验证规范、比例复算、评价模板和有限修订，不运行真实细胞模型或远程 LLM。输出目录须使用新名字。完整执行回归另见 [测试说明](docs/TESTING.md)。

## 在 SciencePal 或兼容宿主部署

1. 使用 [System Prompt](system-prompt/CellSight-System-Prompt.txt) 配置智能体。
2. 将 `upload-zips/` 中的 **73 个 ZIP 分别上传为独立 Skill**，挂载至同一智能体。每包根目录直接包含 `SKILL.md`，不要把整个仓库作为一个 Skill 上传。
3. 将 [能力索引](system-prompt/CellSight-Skill-Catalog.md) 按宿主能力放入知识库；它是静态声明，实际挂载、依赖、设备和权重须逐项核实。
4. 用少量有来源的数据试跑所需 Skill，保留实际调用和产物证据，再开展正式科研任务。

重新生成独立包：`python scripts/package_skills.py`。源码与上传包的一致性由校验脚本检查。[完整部署说明](docs/INSTALLATION.md)

## 73 个 Skill

控制入口：[`cellsight-planner`](skills/cellsight-planner/SKILL.md) 与 [`cellsight-evaluation`](skills/cellsight-evaluation/SKILL.md)。Project State 和内置评价处理器包含在控制包中，不额外计数。

执行类别包括目标检测、图像分割、图像分类、目标追踪、图像处理、图像复原、视觉语言与特征、科学定量、异常检测、关键点与姿态、OCR 和深度估计。[73 项可点击目录与上传清单](docs/SKILLS.md)

71 个执行条目中，34 个包含推理或计算适配器，37 个提供原生操作配方；部分条目属于同一家族或相近架构。不能据此宣称 71 种不同架构、71 个模型均已部署或均经过科学验证。训练说明覆盖范围也不等于内置 CLI 已支持训练。

## 仓库结构

```text
skills/          73 个平级、可独立分发的 Skill 源码
system-prompt/   稳定系统指令与静态能力索引
registry/        71 个执行能力与 12 类标签
schemas/         执行请求、结果与旧版契约 Schema
examples/        不依赖真实图像的数值工作流例子
tests/           原有控制与执行回归（仅调整目录引用）
scripts/         仓库检查、独立打包与文件清单工具
upload-zips/     从当前源码生成的 73 个独立上传包
docs/            部署、测试、版本、权利与发布说明
.github/         自动检查工作流
```

不包含模型权重、真实科研数据集、实验报告、用户附件、音乐、影片及历史重复版本。随执行 Skill 保留的微型合成数组和图像是原有软件测试样例，不能当作科研结果。未发现原交付给本项目指定明确的开源许可证；[权利与第三方依赖说明](docs/RIGHTS.md) 列出当前边界。

校验范围与实测结果见 [整理验证记录](docs/VALIDATION.md)。上传 GitHub 的命令见 [发布说明](docs/PUBLISHING.md)。
