"""Update release checksums after an intentional source/documentation change."""
import json
from _release import ROOT, release_files, digest


def main():
    entries = []
    for p in release_files():
        if p.name == 'artifact-manifest.json':
            continue
        data = p.read_bytes()
        entries.append({'path': p.relative_to(ROOT).as_posix(), 'bytes': len(data), 'sha256': digest(data)})
    (ROOT/'artifact-manifest.json').write_text(json.dumps({
        'schema_version': '1.0', 'prepared_on': '2026-11-01',
        'scope': 'Release files; excludes this manifest, Git metadata, local environments and scratch outputs.',
        'files': entries}, ensure_ascii=False, indent=2)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps({'manifest_files': len(entries)}))


if __name__ == '__main__':
    main()

