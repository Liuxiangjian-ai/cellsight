"""Shared byte-preserving release helpers; standard library only."""
from pathlib import Path
import hashlib
import zipfile

ROOT = Path(__file__).resolve().parents[1]
IGNORED = {'.git', '.venv', 'venv', '__pycache__', 'work', '.pytest_cache', '.mypy_cache', '.ruff_cache'}


def release_files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file()
                  and not (set(p.relative_to(ROOT).parts) & IGNORED)
                  and p.suffix not in {'.pyc', '.pyo'} and p.name not in {'.DS_Store', 'Thumbs.db'})


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_zip(output, files, base, prefix=''):
    """Fixed metadata and ordering; reject escaping resources and symlinks."""
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for f in sorted(files):
            if f.is_symlink() or not f.resolve().is_relative_to(base.resolve()):
                raise ValueError(f'Unsafe archive resource: {f.name}')
            name = prefix + f.relative_to(base).as_posix()
            info = zipfile.ZipInfo(name, (2026, 11, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            z.writestr(info, f.read_bytes(), compresslevel=9)

