"""Regenerate the 73 independent host-upload packages from current source."""
from pathlib import Path
import json
from _release import ROOT, digest, write_zip


def main():
    dirs = sorted(p.parent for p in (ROOT/'skills').glob('*/SKILL.md'))
    if len(dirs) != 73:
        raise SystemExit(f'Expected 73 Skills, found {len(dirs)}')
    output = ROOT/'upload-zips'
    expected = {p.name+'.zip' for p in dirs}
    stale = {p.name for p in output.glob('*.zip')} - expected
    if stale:
        raise SystemExit(f'Unexpected existing packages; inspect before removal: {sorted(stale)}')
    sums = []
    for directory in dirs:
        files = [p for p in directory.rglob('*') if p.is_file()
                 and '__pycache__' not in p.parts and p.suffix != '.pyc']
        target = output/(directory.name+'.zip')
        write_zip(target, files, directory)
        sums.append(f'{digest(target.read_bytes())}  {target.name}')
    (output/'SHA256SUMS').write_text('\n'.join(sums)+'\n', encoding='utf-8', newline='\n')
    print(json.dumps({'packages': len(dirs), 'output': 'upload-zips', 'root_entry': 'SKILL.md'}))


if __name__ == '__main__':
    main()

