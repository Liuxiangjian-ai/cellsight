"""Check release integrity, resource links, static declarations and common disclosure patterns."""
from pathlib import Path
from urllib.parse import unquote
import ast
import collections
import json
import re
import sys
import zipfile
from _release import ROOT, release_files, digest


def main():
    errors = []
    checks = collections.Counter()

    def require(condition, message):
        if not condition:
            errors.append(message)

    def load(path):
        return json.loads((ROOT/path).read_text(encoding='utf-8-sig'))

    directories = sorted((ROOT/'skills').iterdir())
    directories = [p for p in directories if p.is_dir() and p.name != '__pycache__']
    ids = {p.name for p in directories}
    require(len(ids) == 73, f'Expected 73 Skill directories, found {len(ids)}')
    controls = {'cellsight-planner', 'cellsight-evaluation'}
    require(controls <= ids, 'Missing control Skills')
    for directory in directories:
        skill = directory/'SKILL.md'
        require(skill.is_file(), f'Missing SKILL.md: {directory.name}')
        if not skill.is_file():
            continue
        text = skill.read_text(encoding='utf-8-sig')
        front = re.match(r'^---\s*\n(.*?)\n---', text, re.S)
        require(front is not None, f'Missing frontmatter: {directory.name}')
        if front:
            name = re.search(r'^name:\s*(\S+)\s*$', front[1], re.M)
            require(name is not None and name[1] == directory.name, f'Skill name mismatch: {directory.name}')
            require(bool(re.search(r'^description:\s*\S', front[1], re.M)), f'Missing description: {directory.name}')
        nested = list(directory.rglob('SKILL.md'))
        require(nested == [skill], f'Unexpected nested Skill entry: {directory.name}')
        checks['skill_entries'] += 1

    registry = load('registry/expert-registry.json')
    registered = [e['skill_id'] for e in registry['skills']]
    require(len(registered) == len(set(registered)) == 71, 'Execution Registry must contain 71 unique IDs')
    require(set(registered) == ids-controls, 'Execution Registry IDs do not match source')
    require(sum(bool(e['adapter_available']) for e in registry['skills']) == 34, 'Adapter count differs from declared 34')
    categories = load('registry/category-labels.json')['categories']
    require(len(categories) == 12 and len({c['id'] for c in categories}) == 12, 'Expected 12 unique categories')
    grouped = [sid for cat in categories for sid in cat['skills']]
    require(len(grouped) == len(set(grouped)) == 71 and set(grouped) == set(registered), 'Category coverage mismatch')
    for cat in categories:
        expected = {e['skill_id'] for e in registry['skills'] if e['category'] == cat['id']}
        require(expected == set(cat['skills']), f'Category membership mismatch: {cat["id"]}')
    for e in registry['skills']:
        require((ROOT/e['path']/'SKILL.md').is_file(), f'Broken Registry source path: {e["skill_id"]}')
        require((ROOT/e['zip_path']).is_file(), f'Broken Registry ZIP path: {e["skill_id"]}')
    for sid in controls:
        require(load(f'skills/{sid}/assets/execution-registry.json') == registry, f'Embedded Registry differs: {sid}')
    catalog = load('system-prompt/CellSight-Skill-Catalog.json')
    require(catalog['baseline_top_level_skills'] == 73, 'Catalog total mismatch')
    require(len(catalog['entries']) == 73 and {x['skill_id'] for x in catalog['entries']} == ids, 'Catalog IDs mismatch')
    checks.update(execution_skills=71, categories=12, builtin_adapter_skills=34, native_recipe_skills=37)

    patterns = {
        'credential': re.compile(r'(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{30,}|sk-[A-Za-z0-9_-]{24,}|AKIA[A-Z0-9]{16}|-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----)'),
        'personal_absolute_path': re.compile(r'(?:[A-Za-z]:[/\\](?:Users|Program Files)[/\\]|/' + r'Users/|/' + r'home/[A-Za-z0-9_.-]+/|/' + r'mnt/data/)'),
    }
    text_ext = {'.py', '.md', '.txt', '.json', '.yml', '.yaml', '.toml', '.csv', '.ps1', '.sh'}
    for f in release_files():
        rel = f.relative_to(ROOT).as_posix()
        require(not f.is_symlink(), f'Symlink is outside release scope: {rel}')
        require(f.stat().st_size < 50_000_000, f'Unexpected large file: {rel}')
        if f.suffix not in text_ext:
            continue
        try:
            text = f.read_text(encoding='utf-8-sig')
            if f.suffix == '.json':
                json.loads(text)
                checks['json_files'] += 1
            if f.suffix == '.py':
                ast.parse(text, filename=rel)
                checks['python_files'] += 1
        except (ValueError, SyntaxError, UnicodeError) as exc:
            errors.append(f'Invalid text/JSON/Python: {rel}: {type(exc).__name__}')
            continue
        for kind, pattern in patterns.items():
            for match in pattern.finditer(text):
                # Report location only; do not reveal a matched secret value.
                line = text[:match.start()].count('\n')+1
                errors.append(f'{kind}: {rel}:{line}')
        # Source Skill and repository documentation links. Ignore external URLs and fragment anchors.
        if f.suffix == '.md':
            for match in re.finditer(r'!?\[[^\]\n]*\]\(([^)\n]+)\)', text):
                target = match[1].strip().split(' "', 1)[0].strip('<>')
                if re.match(r'^[A-Za-z][A-Za-z0-9+.-]*:', target) or target.startswith('#'):
                    continue
                target = unquote(target.split('#', 1)[0])
                if target:
                    resolved = (f.parent/target).resolve()
                    require(resolved.is_relative_to(ROOT.resolve()) and resolved.exists(), f'Broken local link: {rel} -> {target}')
                    checks['local_links'] += 1
        checks['text_files_scanned'] += 1

    sums = {}
    for line in (ROOT/'upload-zips/SHA256SUMS').read_text(encoding='utf-8').splitlines():
        sha, name = line.split('  ', 1)
        require(name not in sums, f'Duplicate ZIP checksum: {name}')
        sums[name] = sha
    require(set(sums) == {sid+'.zip' for sid in ids}, 'ZIP checksum coverage differs from Skill IDs')
    require({p.name for p in (ROOT/'upload-zips').glob('*.zip')} == set(sums), 'Unexpected/missing ZIP files')
    for sid in sorted(ids):
        source = ROOT/'skills'/sid
        archive = ROOT/'upload-zips'/(sid+'.zip')
        if not archive.is_file():
            errors.append(f'Missing archive: {sid}')
            continue
        require(digest(archive.read_bytes()) == sums.get(archive.name), f'ZIP checksum mismatch: {sid}')
        expected = {p.relative_to(source).as_posix(): p for p in source.rglob('*') if p.is_file()
                    and '__pycache__' not in p.parts and p.suffix != '.pyc'}
        with zipfile.ZipFile(archive) as z:
            names = z.namelist()
            require(len(names) == len(set(names)), f'Duplicate ZIP entries: {sid}')
            require(set(names) == set(expected) and 'SKILL.md' in names, f'ZIP source coverage mismatch: {sid}')
            require(z.testzip() is None, f'ZIP CRC error: {sid}')
            for name in names:
                require(not name.startswith('/') and '..' not in Path(name).parts, f'Unsafe ZIP path: {sid}')
                if name in expected:
                    require(z.read(name) == expected[name].read_bytes(), f'ZIP source byte mismatch: {sid}/{name}')
                    checks['zip_entries'] += 1
        checks['standalone_zips'] += 1

    provenance = load('registry/source-provenance.json')
    for entry in provenance['files']:
        target = ROOT/entry['path']
        require(target.is_file(), f'Missing inherited file: {entry["path"]}')
        if target.is_file() and entry['transformation'] == 'none':
            require(digest(target.read_bytes()) == entry['source_sha256'], f'Inherited source changed: {entry["path"]}')
        checks['provenance_entries'] += 1

    manifest_path = ROOT/'artifact-manifest.json'
    require(manifest_path.is_file(), 'Missing artifact-manifest.json; run scripts/update_manifest.py')
    if manifest_path.is_file():
        entries = load('artifact-manifest.json')['files']
        current = {f.relative_to(ROOT).as_posix() for f in release_files() if f != manifest_path}
        require(len(entries) == len({e['path'] for e in entries}) and {e['path'] for e in entries} == current, 'Manifest file coverage mismatch')
        for entry in entries:
            p = ROOT/entry['path']
            if p.is_file():
                data = p.read_bytes()
                require(len(data) == entry['bytes'] and digest(data) == entry['sha256'], f'Manifest checksum mismatch: {entry["path"]}')
                checks['manifest_files'] += 1
    result = {'status': 'PASS' if not errors else 'FAIL', 'checks': dict(checks), 'errors': errors}
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not errors else 1


if __name__ == '__main__':
    sys.exit(main())
