"""Validate and create a source-repository ZIP plus SHA256 sidecar."""
from pathlib import Path
import argparse
import json
import subprocess
import sys
import zipfile
from _release import ROOT, release_files, digest, write_zip


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, help='New ZIP path outside the repository')
    args = parser.parse_args()
    output = Path(args.output).resolve()
    sidecar = output.with_suffix(output.suffix+'.sha256')
    if output.is_relative_to(ROOT) or output.exists() or sidecar.exists():
        raise SystemExit('Choose a new output path outside the repository; existing deliveries are preserved.')
    subprocess.run([sys.executable, '-B', str(ROOT/'scripts/validate_repository.py')], cwd=ROOT, check=True)
    files = release_files()
    write_zip(output, files, ROOT, prefix='cellsight/')
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        assert len(z.namelist()) == len(files)
        for f in files:
            assert z.read('cellsight/'+f.relative_to(ROOT).as_posix()) == f.read_bytes()
    sha = digest(output.read_bytes())
    sidecar.write_text(f'{sha}  {output.name}\n', encoding='utf-8', newline='\n')
    print(json.dumps({'archive': output.name, 'files': len(files), 'bytes': output.stat().st_size,
                      'sha256': sha, 'crc_and_source_bytes': 'PASS'}, indent=2))


if __name__ == '__main__':
    main()
