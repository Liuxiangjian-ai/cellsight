"""Reproducible arithmetic/protocol example. No images, CV models or actual LLM calls."""
import argparse
from pathlib import Path
import copy
import sys

OUT = Path(__file__).resolve().parents[1]
SKILL = OUT/'skills/cellsight-evaluation'
sys.path.insert(0, str(SKILL/'scripts'))
import cs_meta as meta
import meta_state
import cs_state
from metric_core import load, write, sha


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True)
    a = parser.parse_args()
    work = Path(a.output).resolve()
    if work.exists():
        raise ValueError('Use a new output directory')
    work.mkdir(parents=True)
    registry = work/'registry.json'
    meta.registry_init(registry)
    # Reuse and Compose. Counts are explicit hand-written arithmetic inputs.
    brief = load(SKILL/'assets/examples/brief-ratio.json')
    draft = meta.build_spec(brief, registry)
    write(work/'ratio-spec.draft.json', draft)
    frozen = write(work/'ratio-spec.frozen.json', meta.freeze(draft, registry))
    project = work/'project'
    b = {'schema_version': '1.0', 'experiment_id': brief['task_id'], 'dataset_version': brief['dataset_version'],
         'goal': brief['goal'], 'budget': {'wall_time_seconds': 60, 'device': 'cpu'},
         'limits': {'max_revisions': 1}, 'required_eval_stages': ['preflight', 'final']}
    cs_state.start(write(work/'project-brief.json', b), project)
    meta_state.attach(project, frozen)
    payload = load(SKILL/'assets/examples/ratio-values.json')
    bad = copy.deepcopy(payload)
    bad['values']['reported_ratio'] = 0.8
    failed = work/'ratio-r0.report.json'
    failure = meta.evaluate(frozen, registry, write(work/'ratio-r0.input.json', bad), failed)
    meta_state.record(project, failed)
    meta_state.reserve_revision(project, failed)
    passed = work/'ratio-r1.report.json'
    corrected = meta.evaluate(frozen, registry, write(work/'ratio-r1.input.json', payload), passed)
    meta_state.record(project, passed)
    write(work/'project-status.json', meta_state.status(project))
    # Generate only the uncovered range rule; actual template verification runs.
    d = load(SKILL/'assets/examples/custom-range-definition.json')
    custom_brief = {**brief, 'task_id': 'numeric-range-check', 'requirements': [
        {'id': d['id'], 'capability': 'field_range', 'required': True, 'definition': d}]}
    range_draft = meta.build_spec(custom_brief, registry)
    write(work/'range-spec.initial-draft.json', range_draft)
    generated = work/'cellsight-eval-custom-intensity'
    meta.generate(generated.name, d, generated)
    validation = meta.validate_bundle(generated)
    write(work/'generated-validation.json', validation)
    registration = meta.register(registry, generated)
    write(work/'generated-registration.json', registration)
    activation = meta.activate_template(registry, generated.name)
    write(work/'generated-local-activation.json', activation)
    resolved = meta.resolve(range_draft, registry)
    range_frozen = write(work/'range-spec.frozen.json', meta.freeze(resolved, registry))
    range_input = {'task_id': custom_brief['task_id'], 'dataset_version': custom_brief['dataset_version'],
                   'values': {'intensity': 15, 'unit': 'a.u.'}, 'artifacts': []}
    reviewed = meta.evaluate(range_frozen, registry, write(work/'range.input.json', range_input), work/'range.report.json')
    # Known classification labels check implementation, not any CV model.
    cb = {**brief, 'task_id': 'handwritten-label-check', 'task_type': 'classification', 'requirements': [
        {'id': 'classification-check', 'capability': 'classification_metrics', 'required': True,
         'definition': meta.definition('classification-check', 'classification',
                                      {'classes': ['A', 'B'], 'positive_class': 'B', 'zero_division': 0})}]}
    cspec = write(work/'classification-spec.frozen.json', meta.freeze(meta.build_spec(cb, registry), registry))
    cp = {'task_id': cb['task_id'], 'dataset_version': cb['dataset_version'], 'values': {}, 'artifacts': [],
          'predictions': [{'sample_id': '1', 'label': 'A'}, {'sample_id': '2', 'label': 'A'}, {'sample_id': '3', 'label': 'B'}]}
    labels = {'task_id': cb['task_id'], 'dataset_version': cb['dataset_version'], 'role': 'development',
              'source': 'handwritten protocol fixture; not a CV dataset',
              'records': [{'sample_id': '1', 'label': 'A'}, {'sample_id': '2', 'label': 'B'}, {'sample_id': '3', 'label': 'B'}]}
    classification = meta.evaluate(cspec, registry, write(work/'classification.input.json', cp), work/'classification.report.json',
                                   write(work/'evaluator-private-labels.json', labels))
    missing = meta.evaluate(cspec, registry, work/'classification.input.json', work/'classification-without-labels.report.json')
    result = {'scope': 'numeric/label software fixture only', 'image_data_used': False, 'cv_execution_performed': False,
              'host_llm_routing_tested': False, 'sciencepal_import_tested': False,
              'ratio_decision': draft['decision'], 'ratio_before': failure['status'], 'ratio_after': corrected['status'],
              'range_initial_decision': range_draft['decision'], 'template_validation': validation['executability'],
              'range_scientific_status': reviewed['status'], 'classification_protocol_status': classification['status'],
              'classification_without_labels': missing['status'], 'generated_host_skill_mounted': False}
    write(work/'summary.json', result)
    print(__import__('json').dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
