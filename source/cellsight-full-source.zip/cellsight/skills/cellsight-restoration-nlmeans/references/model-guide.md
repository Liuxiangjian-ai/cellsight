# Non-local Means

`implementation_id: nlmeans` · 框架：scikit-image · 支持任务：restore

## 选用条件与边界

需估计噪声尺度；平滑可能影响细节。

## 执行配方

显式选择channel_axis和preserve_range=True；用estimate_sigma给出候选噪声，再在开发集固定h、patch_size、patch_distance，保存浮点结果与完整参数。

本包模式：predict。内置CLI模式：无；按上述原生配方执行并适配标准产物。

依赖探测模块：numpy, skimage。权重要求：无模型权重。

## 参数与前置条件

先探测已安装版本的实际API；不要根据本文猜测未安装模块已可运行。内置adapter只暴露代码中接受的参数；其他模式走原生流程。保留类映射、输入尺度、归一化、阈值、坐标与资源记录。容量变体不能算独立架构。

训练时按任务提供复核框、实例掩膜或类别标签；记录样品级划分、初始化权重、优化器、有效batch、轮次与早停。纯推理条目不因为底层存在其他能力就被当作本包训练适配器。

## 交付与评价接口

提交真实预测/掩膜/特征/表格、effective request、模型来源与依赖版本。所需评价契约类型：`restoration_fidelity`；具体指标由主控与Eval约定。本技能不自签通过，缺失真值不生成监督指标。运行失败保存错误和未完成状态，不用其他算法的结果冒充本模型。

## 官方依据

- https://scikit-image.org/docs/stable/api/skimage.restoration.html

资料整理日期：2026-10-25。原生API与权重兼容性未全部实测，SciencePal环境和科研性能适用性尚未验证；实际执行按所选版本官方资料核对。第三方代码与权重许可证分别核查，本包不分发权重。
