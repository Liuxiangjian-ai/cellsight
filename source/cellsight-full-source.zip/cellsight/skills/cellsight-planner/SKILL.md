---
name: cellsight-planner
description: 为CellSight科研视觉任务生成Task Intent，接收Eval Profile或Evaluation Specification，按实际可用能力规划依赖、预算和产物，并根据有证据的评价报告有限修订。
---

# CellSight Planner

## 加载与交接纪律

科研工作流中按宿主真实机制读取本Skill完整说明；名称搜索和摘要不等于加载。形成Intent后须实际加载cellsight-evaluation，明确规范并保存快照，再形成正式执行计划。不能仅凭自身规划能力替代控制Skill。已有完整说明与可核验记录可复用；一般解释性问答及明确单Skill单元测试可省略完整链路。

发现历史执行绕过本流程时，明确作为事后复核，保留原记录，不倒填规范、加载记录或执行前审查；不因复核需要而自动重训。


采用MoE-inspired Skill Routing。你承担五项职责：理解科研目标、接收评价约束、查询可用专家、构建执行计划、依据评价报告有限修订。持久化、预算记账、恢复和失败历史由Project State承担，不要求角色模拟协商。

## Task Intent与评价需求

明确科学对象与类别、任务类型、模态、数据版本、输入/轴/通道/空间/标定、期望产物、标注用途、预算及修订上限。缺数据时形成草案与必要缺口。正式测试标签内容和路径不进入规划或预测请求。

将Intent交给cellsight-evaluation。标准任务复用Eval Profile快速生成轻量Spec；特殊任务由Evaluation Meta-Skill按Reuse → Compose → Generate配置。只有影响科学含义、可执行性或验收条件的问题才需澄清。不要为每个简单任务强制创建复杂Contract或要求用户重复批准默认结构检查。

冻结前可与Evaluation协作查询Registry、模型适用范围、输入输出和运行条件，提出候选方案；能力发现不改变原科学要求，也不等于正式Plan。接收已保存版本/hash的[Evaluation Specification](assets/schemas/evaluation-specification.schema.json)。生成Spec的Python工具不解析任意自然语言；宿主LLM负责提取结构化需求。未解决的科学定义或必要Eval缺失时可继续准备，不能宣称完整流程已可执行。

## 精确路由与Execution Plan

采用Minimal Sufficient Workflow：满足目标、科学约束和评价要求后，优先简单、可靠且资源合理的方案。只选必要的模型、预处理、转换与评价步骤，不为展示多Skill而增加调用。正式Plan在规范冻结后生成。

按任务→领域/数据→具体实现检索。完整Skill ID、版本、输入输出Schema、模式、依赖、权重、设备、权限及当前可用证据分别核实。静态71条目录只是候选；用户新增的兼容专家经实际挂载和验证后同样可选。

计划逐步声明step_id、task/mode、完整Skill ID/version、implementation_id（如适用）、参数/权重、输入和依赖、坐标转换、预期产物、预算及验收项。保留用户明确偏好，不静默换模型。不存在真实调用入口时保留待执行交接，不编造API。

检测框、语义图、实例图和掩膜栈不能直接互换；测细胞面积须获得有效区域，不能用框面积冒充。荧光测量使用原始或验证校正强度；无标定时保留像素单位。3D或变换后的空间须显式处理。

先确认科学要求与必要评价能力，再进入昂贵执行；用户只要预测时不强加监督准确率指标，用户要求准确率时保留其指标和缺口，不把格式QA通过说成达标。缺少Ground Truth可继续满足条件的预测，监督项目保持NOT_EVALUABLE；只有用户明确将监督验证条件设为执行前提时才按该前提阻塞。

## 执行与修订

宿主按实际机制加载Execution Skill，由真实工具执行；计划不代表执行。读取[Meta接口](references/meta-interfaces.md)，meta-plan只绑定规范、DAG、输出和预算，状态READY_FOR_HOST_CHECK不证明专家已挂载或运行。

接收带Spec/hash和实际证据的Report，区分FAIL、NEEDS_REVIEW、NOT_EVALUABLE与ERROR。根据REVISE、REPLAN、ESCALATE定位数据、环境、方案或评价问题；只修受影响步骤。原目标、冻结规则和失败证据保持可追溯。新要求须新版本。

预算与修订次数由[Project State](references/project-state.md)控制。正式测试报告不进入自动修订。恢复时先读原状态与job_id；停止调度不等于取消外部作业。

## 本地工具与兼容

新版eval_meta.py支持Spec/评价能力路由、计划绑定与Report交接；71个CV专家的实际选择和调用仍依赖宿主LLM及实际执行入口。它没有通用CV自动调度桥。

原plan.py、coordinate.py、cs_plan.py、cs_state.py和2.0 Contract接口保留原样供旧项目使用；旧CLI不直接接收新版Spec。新状态附件复用账本而不改写旧计划，详见[Runtime](references/meta-runtime.md)及[边界](references/release-scope.md)。
