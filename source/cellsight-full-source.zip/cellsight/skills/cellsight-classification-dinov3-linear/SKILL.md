---
name: cellsight-classification-dinov3-linear
description: 使用DINOv3＋线性分类头执行图像分类任务，适用于明确选择该模型或算法及符合其输入条件的科研图像流程；仅封装实现dinov3-linear，不作为其他模型或同类全部算法的入口。
---

# CellSight · DINOv3＋线性分类头

这是一个可单独上传的执行Skill，唯一实现ID是`dinov3-linear`。能力标签：**图像分类**（`classification`）。标签用于检索和答辩展示，不是需要上传的父Skill。

## 能力与适用条件

冻结特征＋训练头与端到端微调是不同实验；预训练骨干不自动输出科研类别。

支持任务：`classify`。框架/工具：`transformers-or-timm`。模式：predict, train；内置适配器模式：无，使用原生配方。本包提供原生执行配方，尚无统一CLI推理适配器；run命令会明确阻止，不能报告已运行。

先读取[执行契约](references/execution-contract.md)，核实数据、轴、通道、标签与预算。只在当前Eval契约范围内执行，不自行放宽验收条件。没有真值不生成监督指标；运行完成不等于科研验收通过。

## 本实现的执行方法

从本地DINOv3 checkpoint提取固定池化方式的embedding；仅训练训练集上的线性头，在验证集选正则/阈值；保存骨干版本、池化、头参数和类映射。分类时原样复用；不得以在全部样本拟合后拆分的结果宣称独立验证。

细节、参数边界和官方来源见[模型/算法操作说明](references/model-guide.md)。先探测安装版本的实际API并进行少量试跑。依赖或权重缺失时返回blocked及具体缺口；不以别的模型输出冒充本实现。

## 本包脚本

在当前Skill实际资源目录执行，路径可替换为环境中的绝对路径：

```bash
python scripts/run.py list
python scripts/run.py probe --implementation dinov3-linear
python scripts/run.py validate-request --request assets/request.example.json
python scripts/run.py run --request assets/request.example.json --output new-run
```

`list`只返回本实现；注册表中不存在其他专家。`probe`只发现模块，不证明设备、权重或域性能可用。示例为合成数据；本地模型路径需替换为真实文件。内置CLI按明确的任务/模式运行，无适配器或训练模式按上面的原生流程执行，并转换为契约要求的真实产物。

本包不安装依赖、不下载权重、不建立外部服务、不启动子Agent。SciencePal内所有专家平级挂载，由同一智能体按需加载。其他Skill不在本包中，也不会自动被调用或安装。

## 交付与恢复

保留原始图像和金标准；新请求使用新输出目录。返回真实产物、有效配置、输入/权重hash、版本与错误信息。保持原图坐标、instance_id和space_id；处理副本不能默认为原始强度图。失败时保留可恢复产物，只重做受影响步骤，不静默换模型或无限重试。

对于原生执行流程，按本包assets/request.schema.json和result.schema.json保存交接信息；没有运行就明确标记未完成。评价契约类型为`classification`，最终判断由已配置的Eval或实际专家承担。本包的同意示例仅表示演示字段，不代表独立审阅。
