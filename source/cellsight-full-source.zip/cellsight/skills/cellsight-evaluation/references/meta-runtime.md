# 可运行接口

Python 3.10+、jsonschema；不自动联网或安装。命令在本Skill实际资源目录运行，全部输出使用新路径。自然语言到brief由宿主LLM承担。

```powershell
python scripts/eval_meta.py init-registry --output registry.json
python scripts/eval_meta.py build-spec --brief assets/examples/brief-ratio.json --registry registry.json --output ratio.draft.json
python scripts/eval_meta.py freeze --spec ratio.draft.json --registry registry.json --output ratio.frozen.json
python scripts/eval_meta.py evaluate --spec ratio.frozen.json --registry registry.json --input assets/examples/ratio-values.json --output ratio.report.json
```

本例输入为手工数值1/2，与细胞图像无关。只检验已给值的计算一致性。

```powershell
python scripts/eval_meta.py generate --definition assets/examples/custom-range-definition.json --skill-id cellsight-eval-custom-intensity --output custom-intensity
python scripts/eval_meta.py validate-skill --skill custom-intensity --output validation.json
python scripts/eval_meta.py register --skill custom-intensity --registry registry.json
python scripts/eval_meta.py activate-template --skill-id cellsight-eval-custom-intensity --registry registry.json
```

activate-template是固定模板的本地启用。新增Spec用resolve重新选择已验证能力后freeze；不会让SciencePal自动挂载。上传任意实现时省略本地activate，由实际宿主审查安装。

`bind-plan --spec ... --plan ... --output ...`绑定Planner提出的结构化计划，不执行CV。`evaluate --private-labels ...`只在评价器边界读分类标签，缺失时NOT_EVALUABLE。`feedback --spec ... --report ... --output ...`拒绝最终测试反馈，输出动作与证据。LLM回调为Python的evaluate(..., judge=callable)，CLI不提供假LLM。

状态：现有cellsight.py start-project可创建账本；用eval_meta.py的attach-state、record-report、reserve-revision、state-status维护新Spec附件。复用锁、事件、hash、预算原语，不重写持久化。重复记录同一Report不重复计费；修订需已记录FAIL、剩余预算和次数，同一Report不能重复预留。旧自动调度器不读取新Spec附件。

旧接口见原runtime.md；旧Contract项目继续使用cellsight.py。新旧协议需显式选择，不能把新Spec假装成旧Contract。

## 发现与规范校验

`eval_meta.py discover --registry REGISTRY --kind execution --task TASK --domain DOMAIN --output NEW.json`：草案阶段只读查询声明及本地处理器就绪状态，不认证宿主挂载。evaluation候选也用同一命令查询。

`eval_meta.py validate-spec --spec SPEC --output NEW.json`：校验Spec，不把Evaluator标为ready。新Rubric模板缺少实际Judge试跑时保留待安装，activate-template拒绝启用；可由实际宿主审查并按真实机制运行。
