# Meta-Skill / Planner接口

主链路：Task Intent → Profile/Spec → 能力Reuse/Compose/Generate → 验证并保存快照 → Planner → 宿主Execution → Report → 有限修订。

| 对象 | 必需含义 | 实现 |
|---|---|---|
| brief | goal/task/domain/dataset/budget、requirements、科学问题 | 宿主LLM提取，assets/examples为格式例 |
| Spec 1.0 | 指标定义/参数/来源、证据、必需输出、评价器绑定、范围、失败策略 | evaluation-specification.schema.json；build-spec/resolve/freeze |
| Manifest 3.0 | execution/evaluation、ID/version、能力、Schema、依赖、来源、权限、三种状态 | meta-skill-manifest.schema.json；register |
| Meta Plan | Spec引用/hash、依赖、具体专家、输出、预算 | meta-execution-plan.schema.json；bind-plan |
| Report 3.0 | 项目状态/指标、实际范围、输入/产物证据、局限/建议 | meta-evaluation-report.schema.json；evaluate |

Profile是需求的默认配置；Spec是本任务具体化结果；冻结快照是同一个Spec的状态，不要求再创建第三种复杂文档。规则字段变更需新版本。基础Profile不增加领域阈值。

Spec的requirements可同时描述不同任务的评价对象；task_type用于检索，复合任务中必要时拆分Spec并保留父任务关联。`required_outputs`是产物类型要求，不是文件存在性证明。`bind-plan`仅检查ID语法、任务/版本绑定、DAG、输出覆盖和预算，不核验宿主挂载。Planner须另查真实Registry和目标Skill Schema，不能以READY_FOR_HOST_CHECK声称执行就绪。

评价方法：integrity、classification、count_consistency、ratio、field_range、rubric。支持的能力键为execution_qa、classification_metrics、count_consistency、ratio_validation、field_range、scientific_reporting。method与capability同时核对。范围检查支持已有标量及显式单位；它不实现通用组织病理/生物学判定。

分类协议目前为单标签：明确类别集合、sample_id、zero_division=0；Accuracy和Macro-F1，指定positive_class时额外Precision/Recall。未实现AUROC、多标签、通用检测mAP。比例为非负整数子集/有效总体，空分母NOT_EVALUABLE，reported_ratio是[0,1]分数。

正式测试标签仅给evaluate的private-labels参数，不能放入Spec、Plan或执行请求。测试报告source_type=external_benchmark，feedback/状态录入禁止将其传入操作性修订。开发标签可用于开发评价，但不伪称最终测试。单进程/文件隔离不等于宿主OS安全隔离。

原2.0协议完整保留。旧任务走cellsight.py，新任务走eval_meta.py；尚未实现新Spec到旧自动执行调度器的透明迁移。不要把3.0 Report直接传给旧record_eval。

## v0.5.1：草案协作与就绪边界

草案阶段可以discover查询execution/evaluation候选、领域、I/O及运行声明；该操作只读，不改变Spec/hash或授权。候选包括不可用项用于定位缺口，不能直接进入执行计划。宿主挂载仍需单独证据。

validate-spec通过与实际Evaluator可执行独立；freeze仍核查已绑定处理器及版本。新生成模板须实际完成所声明评价能力的试跑。Rubric只有缺Judge测试时executability=NOT_EVALUABLE，launcher_trial=PASS不等于评价ready。自动接入真实Judge并验证其判断质量尚未实现。

scientific_questions仅记录真正阻塞规范/执行的缺口，不能把缺少监督标签一律当作预测阻塞；用户明确将标签验证设为执行前提时保留该限制。分类指标本身保留为必需项，缺标签时Report整体NOT_EVALUABLE，预测阶段可完成而完整验收尚未完成。

Minimal Sufficient Workflow由宿主Planner按语义判断；本地bind-plan接受单步Plan并检查DAG/预算，不具有自动证明科研方案最简或最优的算法。

动态部署信息见[部署说明](deployment-context.md)。
