# 旧Contract辅助Runtime兼容说明

新任务优先阅读[Meta Runtime](meta-runtime.md)。下列命令仅服务原2.0协议，旧脚本保持原样：

```bash
python scripts/cellsight.py --help
python scripts/cellsight.py registry-init --registry registry.json
python scripts/cellsight.py register --registry registry.json --manifest actual-manifest.json
python scripts/cellsight.py build-contract --intent actual-intent.json --registry registry.json --output acceptance.draft.json
python scripts/cellsight.py freeze-contract --draft acceptance.draft.json --registry registry.json --output acceptance.frozen.json
python scripts/cellsight.py plan --intent actual-intent.json --contract acceptance.frozen.json --registry registry.json --output plan-r0
```

运行条件为Python及所需依赖（主要numpy、Pillow、jsonschema）；不自动安装依赖、联网或下载权重。CLI无SciencePal私有API。

本地Registry只激活固定可信处理器；当前执行桥为原threshold-boxes基线。SciencePal中已挂载的YOLO、分割等原生专家，可由宿主按其Skill说明执行；本CLI尚无通用第三方调用桥。不要把CLI的单一适配器表述为平台只允许一个模型。

Runtime已实现文件/请求/hash/坐标检查和检测面积一致性；LLM需judge回调，未配置时NOT_EVALUABLE。独立Benchmark支持单图固定IoU检测计数指标；其他指标需真实处理器。没有脚本能力时由宿主LLM填写结构化交接，未算出的指标保持未知。

旧接口仍保留：plan.py create/agree/materialize及coordinate.py服务旧项目；其中角色审阅仅属兼容路径，不能用作本版默认流程。
