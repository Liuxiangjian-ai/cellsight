# v0.5.1功能边界

已实现：独立Meta-Skill与Planner指令、结构化brief→Spec、轻量Profile、基于任务/领域/能力/可用性的Reuse/Compose/Generate决策、Spec快照/hash、五类本地处理器、三种固定模板生成、四维Validator、统一Manifest3.0注册、固定模板本地启用、Report3.0、Planner计划绑定和反馈接口、原账本的Spec/Report附件及预算/修订保护。

部分实现：自然语言→规范由宿主LLM按指令完成，未接远程LLM API；科学有效性只能保存来源和待审状态；原生第三方Skill运行依赖宿主；新Spec工作流由宿主驱动，未接入旧自动执行调度器；Rubric有judge回调但无真实模型服务验证；计划绑定不负责真实挂载检查。软件测试采用手写表格/数值，不证明Agent自然语言路由表现。

尚未实现：任意Python/科学公式安全自动生成与执行、SciencePal动态安装/沙箱API、外部Skill通用本地调用桥、新旧Registry自动迁移、通用mAP/Dice/AUROC指标库、专家身份认证、真实图像端到端测试、内部40题Agent Eval Set。

保留：原2.0 Contract/Runtime、plan.py、coordinate.py、cs_state.py、预算、恢复、溯源、坐标保护和失败记录的源码原样复制。新QA默认只验证输入/产物身份与文件完整性；坐标/单位/变换等任务要求须在Spec中显式声明并由实际方法验证，不能把基础QA当作全部科学约束检查。

生成与注册不会增加顶层Skill数量；只有实际安装的Task-specific Eval才成为新增顶层Skill。基线仍是2个控制Skill+71个执行Skill，12类标签不变。

本轮新增：只读草案能力发现、Spec独立校验结果、生成Rubric缺Judge时禁止ready。未实现：真实SciencePal能力自动探测、通用Judge接入/认证、科研方案自动最简性证明；Minimal Sufficient Workflow和自然语言协作目前由宿主LLM按Skill指令执行。
