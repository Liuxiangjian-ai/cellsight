# 部署信息由能力目录维护

本分发沿用2个控制Skill、71个执行条目和12类标签；它们不是自动可用承诺或数量上限。完整ID、implementation_id及模式映射见assets/execution-registry.json和system-prompt的Skill Catalog。内部评价器以scripts/cs_registry.py、cs_meta.py及实际Manifest为准，不作为宿主顶层调用目标。CLI支持范围与新旧协议见meta-runtime.md、runtime.md及release-scope.md。生成/注册不等于SciencePal已挂载。

System Prompt只保留稳定职责、完整ID调用纪律、科研真实性、权限和预算/恢复要求。数量、映射和版本迁移不在主Prompt重复维护。
