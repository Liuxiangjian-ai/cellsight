# Project State / Orchestration能力

事实账本、数据来源、预算记账、持久化、作业恢复和失败历史由包内模块维护，两个Skill共享同一项目，不要求额外挂载第三个协调Skill。

可运行Python时，cs_state.py复用原coordinate.py的独占写锁、事件快照、状态hash和预算原语。保留输入/输出来源、计划和冻结Contract、执行与Eval状态、真实耗时、修订次数及交付引用。旧plan.py/coordinate.py保留兼容用途，新默认入口无需角色审阅。

继续任务先status读取现有project.json。pending_job只reconcile已有终态产物，不重新提交；缺少结果时检查原作业。状态或证据改变需明确处理，不能静默修复。预算/修订耗尽则升级取舍；停止只阻止新调度，外部作业需原生取消接口。

全局预算覆盖已记录开销，不自动涵盖全部LLM等待。固定本地执行有单步子进程超时，不声称SciencePal或远程GPU已有硬预算。hash用于修改检测，不提供身份认证或OS安全隔离。

SciencePal无法运行/保存脚本时，用[项目记录模板](../assets/project-state.template.md)维护同一结构并标明未运行程序检查。文本记录不等于已执行证据。

## Meta Specification附件

meta_state.py通过原LEDGER.exclusive/read_state/commit附加Spec与Report记录，保留hash、预算、失败与修订历史。新附件用eval_meta.py state-status读取；旧自动调度器不处理新Spec。不要同时给同一项目绑定旧Plan与新Spec。
