# Planner / Eval接口

默认链路：用户科学问题→Planner输出Task Intent→Eval Builder输出Contract→冻结→Planner输出Execution Plan→宿主加载Execution Skill→Eval输出Report→有限修正或交付。

| 对象 | 必需内容 | 来源与接收方 |
|---|---|---|
| Task Intent | 目标、任务、数据域与版本、输入引用、输出要求、预算、评价需求 | Planner → Eval Builder |
| Evaluation Contract | 目标、必需输出、项目/协议、范围、阈值来源、失败策略、版本与冻结状态 | Eval → Planner / Runtime |
| Execution Plan | step_id、具体Skill ID/版本、依赖、输入/产物类型、参数与预算、Contract绑定 | Planner → 宿主执行与Project State |
| Evaluation Report | 状态、逐项证据、范围、版本、结果绑定、局限与修正建议 | Eval → Planner / Project State |

Schema：[Task Intent](../assets/schemas/task-intent.schema.json)、[Contract](../assets/schemas/evaluation-contract.schema.json)、[Report](../assets/schemas/evaluation-report.schema.json)、[Manifest](../assets/schemas/skill-manifest.schema.json)。

Python接口沿用已有结构化协议2.0；它要求本地可读取输入及真实Registry，无法在数据缺失时冻结可执行规范。Skill在对话中可以先形成明确标记的DRAFT，未满足程序条件时不能称为已验证或可执行。

冻结后的Execution Plan绑定Contract内容/hash、具体执行实现和输入hash。原专家协议1.0仍使用agreed字段，附带脚本把FROZEN规范投影为兼容执行视图；此字段不代表三方投票。

测试Ground Truth不进入Plan或预测Request；只传递数据集/类别/划分/格式等必要元数据。训练所需标注须由训练Skill的清单与权限管理，不复用测试标注。
