# 统一Registry与实际可用性

每个Execution或Evaluation Manifest声明唯一ID与版本、类型/能力、输入输出JSON Schema、领域与限制、依赖/设备/权重、可用状态、调用入口、权限和可信来源。

参考[Manifest Schema](../assets/schemas/skill-manifest.schema.json)、[Execution示例](../assets/manifests/custom-execution.example.json)与[Evaluation示例](../assets/manifests/cellsight-eval-basic.json)。用户自定义两类Skill均通过同一注册入口。

SciencePal候选列表取实际挂载信息或明确的用户配置；不从静态目录推断已安装，也不猜测平台API。内置execution-registry.json保留71个原专家与12类标签，供任务检索。目录分类不要求嵌套上传。

Python辅助Registry注册时校验Manifest与输入输出Schema、拒绝同ID/版本覆盖，默认pending_installation。仅包内固定可信处理器可以本地激活；外部Python、服务和host_skill不被自动import或执行。权限由真实宿主实施，Manifest声明不会赋予权限。

签名认证、通用沙箱、自动挂载与第三方运行桥尚未实现。来源trusted字段是声明，不能替代宿主认证与可用证据。LLM评价入口还需区分原生同模型Rubric评审和真正配置好的程序回调。
