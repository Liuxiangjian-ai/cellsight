# 新旧协议选择

新版接口见[Meta接口](meta-interfaces.md)，原2.0 Contract接口见[兼容接口](legacy-interfaces.md)。
