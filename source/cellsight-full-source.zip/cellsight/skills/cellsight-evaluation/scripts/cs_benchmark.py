"""Independent, single-use benchmark evaluator. Private labels never enter a Planner request."""
from pathlib import Path
import time
from cs_common import load,write,sha,digest,require,ref,now,sealed,check_seal,finite

def iou(a,b):
    left=max(a[0],b[0]); top=max(a[1],b[1]); right=min(a[2],b[2]); bottom=min(a[3],b[3])
    inter=max(0,right-left)*max(0,bottom-top)
    total=(a[2]-a[0])*(a[3]-a[1])+(b[2]-b[0])*(b[3]-b[1])-inter
    return inter/total if total>0 else 0.

def maximum_matches(predicted,truth,threshold):
    edges=[[j for j,t in enumerate(truth) if p['category_id']==t['category_id'] and iou(p['bbox_xyxy'],t['bbox_xyxy'])>=threshold] for p in predicted]
    assigned={}
    def augment(i,seen):
        for j in edges[i]:
            if j in seen: continue
            seen.add(j)
            if j not in assigned or augment(assigned[j],seen): assigned[j]=i; return True
        return False
    return sum(augment(i,set()) for i in range(len(predicted)))

def run(protocol_path,result_path,private_truth_path,output):
    started=time.monotonic(); protocol_path=Path(protocol_path).resolve(); protocol=load(protocol_path); check_seal(protocol,'protocol_hash')
    require(protocol['schema_version']=='2.0' and protocol['split']=='test','A frozen test protocol is required.')
    require(finite(protocol['iou_threshold']) and 0<protocol['iou_threshold']<=1,'Invalid IoU threshold.')
    require(protocol.get('threshold_source'),'Protocol threshold source required.')
    require(protocol['metric']=='object_precision_recall_f1_at_fixed_iou','Unsupported metric; do not label this AP/mAP.')
    # A protocol is consumed before looking at private labels. No iterative tuning on test feedback.
    marker=protocol_path.with_suffix('.consumed.json')
    write(marker,{'protocol_hash':protocol['protocol_hash'],'prediction_sha256':sha(Path(result_path)),'consumed_at':now()})
    result=load(result_path); truth=load(private_truth_path)
    require(result['status']=='succeeded' and result['task']=='detect','Benchmark requires an actual detection result.')
    require(result['dataset_version']==protocol['dataset_version']==truth['dataset_version'],'Benchmark dataset mismatch.')
    require(truth.get('annotation_source') in {'synthetic_generator','human','human_reviewed'},'Annotation source must be explicit.')
    groups={}; images={}
    for row in truth['split_manifest']:
        require(row['split'] in {'train','val','test'} and row['sample_group'],'Invalid split/sample group.')
        require(row['sample_group'] not in groups or groups[row['sample_group']]==row['split'],'Sample group leakage across splits.')
        require(row['image_sha256'] not in images or images[row['image_sha256']]==row['split'],'Identical image leaked across splits.')
        groups[row['sample_group']]=row['split']; images[row['image_sha256']]=row['split']
    require({'train','val','test'}<=set(groups.values()),'Declare train/val/test separation, including independent sample groups.')
    test=truth['test_record']; require(images.get(test['image_sha256'])=='test' and groups.get(test['sample_group'])=='test','Ground truth is not in the isolated test split.')
    require(any(p['sha256']==test['image_sha256'] for p in result['provenance']),'Prediction does not correspond to the test image.')
    det=next(a for a in result['artifacts'] if a['type']=='detections'); detection_path=Path(det['path'])
    require(sha(detection_path)==det['sha256'],'Prediction artifact changed.')
    predicted=load(detection_path)['records']; labels=test['boxes']
    for row in predicted+labels:
        box=row.get('bbox_xyxy'); require(isinstance(box,list) and len(box)==4 and all(finite(v) for v in box) and box[0]<box[2] and box[1]<box[3],'Invalid benchmark box.')
        require(type(row.get('category_id')) is int,'Explicit matching categories required.')
    tp=maximum_matches(predicted,labels,protocol['iou_threshold']); fp=len(predicted)-tp; fn=len(labels)-tp
    precision=tp/(tp+fp) if tp+fp else None; recall=tp/(tp+fn) if tp+fn else None
    f1=2*precision*recall/(precision+recall) if precision is not None and recall is not None and precision+recall else (0. if precision is not None and recall is not None else None)
    metrics={'tp':tp,'fp':fp,'fn':fn,'precision':precision,'recall':recall,'f1':f1,'iou_threshold':protocol['iou_threshold']}
    acceptance=protocol['acceptance']; available=precision is not None and recall is not None
    status='NOT_EVALUABLE' if not available else ('PASS' if precision>=acceptance['min_precision'] and recall>=acceptance['min_recall'] else 'FAIL')
    evidence=[ref(result_path),ref(protocol_path),ref(detection_path)]
    report={
      'schema_version':'2.0','source_type':'external_benchmark','experiment_id':result['experiment_id'],'dataset_version':result['dataset_version'],
      'plan_hash':protocol.get('prediction_plan_hash','external_prediction_frozen'),'contract_hash':protocol['protocol_hash'],'stage':'benchmark','status':status,
      'items':[{'id':'supervised-detection','kind':'deterministic','status':status,'evidence':evidence,'details':{'metrics':metrics,'acceptance':acceptance,'matching':'maximum_cardinality_bipartite','annotation_source':truth['annotation_source']}}],
      'public_checks':{k:'PASS' for k in ['data-provenance','artifact-integrity','spatial-and-unit-integrity','evaluation-boundaries']},
      'recommendation':{'action':'NONE' if status=='PASS' else 'ESCALATE','reason':'Independent test feedback is for reporting and comparison; it must not drive automatic parameter tuning.'},
      'evaluation_scope':'supervised_outcomes_on_isolated_test','evaluated_results_hash':digest({'prediction':sha(Path(result_path))}),
      'private_truth_sha256':sha(Path(private_truth_path)),'private_labels_exposed_to_planner':False,'wall_time_seconds':time.monotonic()-started,'created_at':now(),
      'limitations':['Synthetic benchmark accuracy applies only to this controlled fixture.','This fixed-IoU object metric is not AP or mAP; annotation quality is not independently certified.','Isolation is an application boundary; OS sandboxing must be supplied by the host.'],
    }
    report=sealed(report,'report_hash'); write(output,report); return report
