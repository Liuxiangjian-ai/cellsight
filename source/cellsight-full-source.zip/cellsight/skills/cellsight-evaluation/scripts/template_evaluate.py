"""Fixed CellSight evaluator launcher. Generated rules are data, never executable expressions."""
import argparse
from pathlib import Path
from metric_core import load, write, score, sha, seal, require


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    require(not Path(args.output).exists(), 'Use a new report path')
    definition = load(root/'definition.json')
    payload = load(args.input)
    import jsonschema
    jsonschema.Draft202012Validator(load(root/'schemas/input.schema.json')).validate(payload)
    # Standalone templates support evaluator-local scalar/rubric rules, not private GT joins.
    row = score(definition, payload)
    report = seal({'schema_version': '1.0', 'eval_skill_id': load(root/'manifest.json')['id'],
                   'definition_hash': __import__('metric_core').digest(definition),
                   'input_sha256': sha(args.input), 'evaluation_scope': 'supplied_values_only_not_cell_accuracy',
                   **row}, 'report_hash')
    write(args.output, report)
    print(report['status'])


if __name__ == '__main__':
    main()
