"""Shared file integrity and schema helpers; no host APIs or code installation."""
from pathlib import Path
import importlib.util
import json
import math
import os
from datetime import datetime, timezone

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('cellsight_v04_legacy_plan',ROOT/'scripts/plan.py')
CORE=importlib.util.module_from_spec(spec); spec.loader.exec_module(CORE)
load=CORE.load; digest=CORE.digest; sha=CORE.file_hash; resolve=CORE.resolve; require=CORE.require
VERSION='0.4.0'
STATUSES={'PASS','FAIL','NEEDS_REVIEW','NOT_EVALUABLE','ERROR'}

def now(): return datetime.now(timezone.utc).isoformat()

def write(path,value):
    path=Path(path); path.parent.mkdir(parents=True,exist_ok=True); CORE.write(path,value); return path

def finite(x): return isinstance(x,(int,float)) and not isinstance(x,bool) and math.isfinite(x)

def validate(value,schema):
    import jsonschema
    jsonschema.Draft202012Validator(schema).validate(value)

def schema(name): return load(ROOT/'assets/schemas'/(name+'.schema.json'))

def ref(path,base=None):
    p=resolve(str(path),base or Path.cwd()); require(p.is_file(),'Evidence missing: '+str(p)); return {'path':str(p),'sha256':sha(p)}

def check_ref(row):
    p=Path(row['path']); require(p.is_file() and sha(p)==row['sha256'],'Evidence missing or changed: '+str(p)); return p

def sealed(data,key):
    result=dict(data); result[key]=digest(data); return result

def check_seal(data,key):
    original=dict(data); recorded=original.pop(key,None); require(recorded==digest(original),key+' mismatch; immutable record changed.'); return data

def no_truth(value):
    """Public Intent/plan/request boundary: never carry labels into execution or routing."""
    banned={'ground_truth','ground_truth_refs','ground_truth_path','test_labels','labels','truth_path','label_path','annotations','annotation_path'}
    if isinstance(value,dict):
        require(not (set(value)&banned),'Ground Truth/labels must remain in the private evaluator boundary.')
        require(value.get('role') not in {'test_labels','ground_truth'},'Test-label input forbidden.')
        for item in value.values(): no_truth(item)
    elif isinstance(value,list):
        for item in value: no_truth(item)

def atomic_replace(path,value):
    path=Path(path); temp=path.with_name(path.name+'.next')
    write(temp,value); os.replace(temp,path)
