"""Eval-first acceptance specification: built before routing, immutable after freeze."""
from pathlib import Path
import copy
from cs_common import load,write,sha,digest,require,validate,schema,ref,check_ref,now,sealed,check_seal,no_truth,finite
import cs_registry as registry

def intent(path):
    value=load(path); validate(value,schema('task-intent')); no_truth(value)
    require(value['purpose'] in {'exploration','benchmark_prediction'},'Formal benchmark labels belong only to the External Benchmark.')
    for row in value['inputs']:
        p=ref(row['path'],Path(path).resolve().parent)
        if row.get('sha256'): require(row['sha256']==p['sha256'],'Declared input hash mismatch.')
        require(row.get('role') not in {'test_labels','ground_truth'},'Private labels cannot be a planning input.')
    return value

def build(intent_path,registry_path,output):
    task=intent(intent_path); catalog=registry.read(registry_path)
    items=[]
    def add(kind,method,acceptance,source):
        candidates=registry.query(catalog,'evaluation',task['steps'][0]['task'],task['domain'])
        candidates=[m for m in candidates if kind in m['capabilities']['methods']]
        require(candidates,'No actual available Evaluation Skill for '+kind)
        chosen=candidates[0]
        require(set(s['task'] for s in task['steps'])<=set(chosen['capabilities']['tasks']),'Eval does not cover every planned task.')
        items.append({'id':method,'kind':kind,'method':method,'required':True,
          'evaluator':{'id':chosen['id'],'version':chosen['version'],'manifest_hash':registry.identity(chosen)},
          'stages':['stage','final'],'acceptance':acceptance,'threshold_source':source,
          'on_failure':{'action':'REVISE' if kind=='scientific_consistency' else 'ESCALATE','reason':'Follow predeclared acceptance; preserve failures and scope.'}})
    add('deterministic','public-integrity',{'all_public_checks':'PASS'},
        {'kind':'protocol','reference':'cellsight-public-integrity-v2','rationale':'Data/identity/hash/coordinates/units/boundary checks; not accuracy.'})
    criteria=task['evaluation'].get('criteria',[])
    for row in criteria:
        require(row['method'] in {'bbox-area-range','scientific-rubric','supervised-detection'},'Unsupported criterion; register/implement its runtime explicitly.')
        kind={'bbox-area-range':'scientific_consistency','scientific-rubric':'llm_rubric','supervised-detection':'deterministic'}[row['method']]
        source=row['threshold_source']; require(source.get('kind') in {'user_requirement','protocol','dataset_specification','pilot_calibration'},'Untraceable threshold source.')
        if row['method']=='bbox-area-range':
            rule=row['acceptance']; require(finite(rule.get('min_area_px')) and finite(rule.get('max_area_px')) and 0<rule['min_area_px']<=rule['max_area_px'],'Finite positive pixel area limits required.')
            require(task['evaluation']['scope']=='scientific_consistency','Consistency requirements need explicit consistency scope.')
        if row['method']=='supervised-detection': require(task['evaluation']['scope']=='supervised_outcomes','Supervised metrics need explicit supervised scope.')
        add(kind,row['method'],row['acceptance'],source)
    if task['evaluation']['scope']=='supervised_outcomes':
        require(any(i['method']=='supervised-detection' for i in items),'Supervised scope needs a supervised protocol; never invent ground truth.')
    if task['evaluation']['scope']=='scientific_consistency':
        require(any(i['kind']=='scientific_consistency' for i in items),'Consistency scope requires an actual consistency criterion.')
    input_refs=[{'artifact_id':r['artifact_id'],**ref(r['path'],Path(intent_path).resolve().parent)} for r in task['inputs']]
    value={
      'schema_version':'2.0','contract_id':task['experiment_id']+'-acceptance','version':'1.0.0','status':'DRAFT',
      'experiment_id':task['experiment_id'],'dataset_version':task['dataset_version'],'goal':task['goal'],
      'intent_hash':digest(task),'task_intent_ref':ref(intent_path),'domain':task['domain'],'purpose':task['purpose'],
      'tasks':sorted({s['task'] for s in task['steps']}),'required_outputs':task['required_outputs'],
      'evaluation_scope':task['evaluation']['scope'],'ground_truth_status':'not_provided_to_operational_flow',
      'applicability':{'domain':task['domain'],'data_kind':task.get('data_kind','user_provided'),'limits':task['evaluation'].get('limitations',[])},
      'items':items,'input_refs':input_refs,'required_evidence':['data-provenance','artifact-integrity','spatial-and-unit-integrity','evaluation-boundaries'],
      'failure_policy':{'max_replans':task.get('max_replans',2),'allowed_actions':['REVISE','REPLAN','ESCALATE'],'allow_threshold_relaxation':False,'benchmark_feedback_for_replanning':False},
      'created_at':now(),'registry_at_build':catalog['registry_hash'],
    }
    validate(value,schema('evaluation-contract')); write(output,sealed(value,'contract_hash')); return load(output)

def read(path,frozen=True):
    value=load(path); check_seal(value,'contract_hash'); validate(value,schema('evaluation-contract'))
    if frozen: require(value['status']=='FROZEN','Contract must be frozen before formal planning/execution.')
    return value

def freeze(draft_path,registry_path,output):
    value=read(draft_path,False); require(value['status']=='DRAFT','Only a draft may be frozen.')
    catalog=registry.read(registry_path)
    for item in value['items']:
        m=registry.get(catalog,item['evaluator']['id'],item['evaluator']['version'])
        require(registry.ready(m) and registry.identity(m)==item['evaluator']['manifest_hash'],'Evaluator readiness/version changed before freeze.')
    check_ref(value['task_intent_ref'])
    for row in value['input_refs']: check_ref(row)
    value.pop('contract_hash'); value.update(status='FROZEN',frozen_at=now())
    write(output,sealed(value,'contract_hash')); return load(output)

def execution_view(contract):
    """Legacy 1.0 wire compatibility. 'agreed' encodes frozen status, not role votes."""
    return {'schema_version':'1.0','experiment_id':contract['experiment_id'],'dataset_version':contract['dataset_version'],
      'tasks':contract['tasks'],'status':'agreed','required_evidence':contract['required_evidence'],
      'contract_id':contract['contract_id'],'contract_version':contract['version'],'frozen_contract_hash':contract['contract_hash'],
      'compatibility_note':'Legacy wire value agreed means frozen acceptance specification; no simulated role agreement.'}
