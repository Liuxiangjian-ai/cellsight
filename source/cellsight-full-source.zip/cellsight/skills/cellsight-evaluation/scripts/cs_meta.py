"""Additive CellSight Evaluation Meta-Skill reference implementation.

The host LLM extracts a structured brief. This module never pretends to be an LLM,
installs a skill, imports uploaded code, or executes CV models.
"""
import copy
import re
import subprocess
import sys
import time
from pathlib import Path
from metric_core import (VERSION, METHODS, require, digest, sha, load, write, seal,
                         check_seal, validate_definition, score, aggregate, finite)
from meta_schemas import SCHEMAS, DEFINITION, MANIFEST, PAYLOAD, SPEC, REPORT, PLAN, COMPACT_REPORT

ROOT = Path(__file__).resolve().parents[1]
METHOD_CAP = {'integrity': 'execution_qa', 'classification': 'classification_metrics',
              'count_consistency': 'count_consistency', 'ratio': 'ratio_validation',
              'field_range': 'field_range', 'rubric': 'scientific_reporting'}
BUILTIN_IDS = {m: 'cellsight-eval-'+suffix for m, suffix in {
    'integrity': 'integrity', 'classification': 'classification',
    'count_consistency': 'count-consistency', 'ratio': 'ratio', 'rubric': 'reporting-rubric'}.items()}


def validate(value, schema):
    import jsonschema
    jsonschema.Draft202012Validator(schema).validate(value)


def definition(identifier, method, parameters=None, acceptance=None, source=None, basis=None):
    d = {'id': identifier, 'method': method, 'parameters': parameters or {},
         'acceptance': acceptance or {}, 'scientific_basis': basis or {
             'status': 'operational_rule', 'reference': 'CellSight declared computational protocol; not phenotype validation'},
         'limitations': ['Checks supplied evidence within declared scope; does not establish biological validity.']}
    if source:
        d['threshold_source'] = source
    validate(d, DEFINITION)
    return validate_definition(d)


def implementation_hash():
    return digest({n: sha(Path(__file__).parent/n) for n in ('metric_core.py', 'cs_meta.py', 'meta_schemas.py')})


def manifest(sid, method, origin='generated', task='*', domains=None):
    require(method in METHODS, 'Unknown evaluator method')
    m = {'schema_version': '3.0', 'id': sid, 'version': VERSION, 'type': 'evaluation',
         'capabilities': {'tasks': [task], 'methods': [METHOD_CAP[method]], 'modes': ['evaluate']},
         'input_schema': copy.deepcopy(PAYLOAD), 'output_schema': copy.deepcopy(REPORT),
         'domain_scope': {'domains': domains or ['*'], 'limitations': ['Domain validity needs separate evidence.'],
                          'scientific_validation': 'not_established'},
         'runtime': {'dependencies': ['jsonschema'], 'devices': ['cpu'], 'requires_weights': False},
         'entrypoint': {'kind': 'builtin' if origin == 'built-in' else 'python',
                        'name': method if origin == 'built-in' else 'scripts/evaluate.py'},
         'permissions': {'network': False, 'filesystem': 'host_scoped', 'subprocess': False},
         'source': {'origin': origin, 'publisher': 'CellSight' if origin != 'uploaded' else 'declared publisher',
                    'reference': 'cellsight-evaluation/'+VERSION if origin == 'built-in' else 'task-specific package'},
         'required_evidence': ['private_ground_truth'] if method == 'classification' else ['evaluation_input'],
         'validation_status': 'template_verified' if origin == 'built-in' else 'unverified',
         'registration_status': 'registered' if origin == 'built-in' else 'unregistered',
         'availability': 'ready' if origin == 'built-in' else 'pending_installation'}
    validate(m, MANIFEST)
    return m


def registry_init(path):
    require(not Path(path).exists(), 'Registry already exists')
    rows = [{'manifest': manifest(sid, method, 'built-in'), 'bundle': None,
             'readiness': {'scope': 'packaged_local_handler_not_host_mount', 'implementation_hash': implementation_hash()}}
            for method, sid in BUILTIN_IDS.items()]
    return write(path, seal({'schema_version': '3.0', 'entries': rows}, 'registry_hash'))


def registry_read(path):
    r = load(path)
    check_seal(r, 'registry_hash')
    require(r.get('schema_version') == '3.0', 'Use a Meta Registry 3.0; legacy registry remains separate compatibility storage')
    keys = []
    for row in r['entries']:
        validate(row['manifest'], MANIFEST)
        keys.append((row['manifest']['id'], row['manifest']['version']))
    require(len(keys) == len(set(keys)), 'Duplicate registry ID/version')
    return r


def registry_save(path, r):
    # Reuse existing lock/atomic persistence helpers; this is not a third-party installer.
    from cs_registry import lock
    from cs_common import atomic_replace
    with lock(path):
        current = registry_read(path)
        require(current['registry_hash'] == r['registry_hash'], 'Concurrent registry change; retry from fresh state')
        body = {k: v for k, v in r.items() if k != 'registry_hash'}
        atomic_replace(path, seal(body, 'registry_hash'))


def discover(registry_path, kind, task, domain):
    """Read-only candidate discovery before freeze; declarations are not readiness proof."""
    require(kind in {'execution', 'evaluation'}, 'Unknown Skill kind')
    registry = registry_read(registry_path)
    candidates = []
    for row in registry['entries']:
        m = row['manifest']
        if m['type'] != kind:
            continue
        if task not in m['capabilities']['tasks'] and '*' not in m['capabilities']['tasks']:
            continue
        if domain not in m['domain_scope']['domains'] and '*' not in m['domain_scope']['domains']:
            continue
        try:
            callable_here, issue = ready(row), None
        except (OSError, ValueError) as exc:
            callable_here, issue = False, str(exc)
        candidates.append({'manifest': copy.deepcopy(m), 'local_handler_ready': callable_here,
                           'host_mount_verified': False, 'readiness_issue': issue})
    return {'registry_hash': registry['registry_hash'], 'candidates': sorted(candidates, key=lambda r: r['manifest']['id']),
            'scope': 'read_only_discovery_not_formal_plan_or_permission', 'scientific_criteria_changed': False}


def validate_specification(spec):
    check_spec(spec)
    return {'specification_validation': 'PASS', 'spec_hash': spec['spec_hash'],
            'scope': 'schema_and_declared_protocol_consistency', 'evaluator_readiness_checked': False,
            'host_mount_verified': False, 'scientific_validity': 'not_certified'}


def check_manifest(m):
    validate(m, MANIFEST)
    import jsonschema
    for k in ('input_schema', 'output_schema'):
        jsonschema.Draft202012Validator.check_schema(m[k])
    if m['type'] == 'evaluation' and 'classification_metrics' in m['capabilities']['methods']:
        require('private_ground_truth' in m['required_evidence'], 'Classification metrics must declare private Ground Truth evidence')


def bundle_identity(bundle):
    root = Path(bundle).resolve()
    names = ['SKILL.md', 'manifest.json', 'definition.json', 'schemas/input.schema.json',
             'schemas/report.schema.json', 'scripts/evaluate.py', 'scripts/metric_core.py',
             'tests/test_evaluator.py', 'tests/cases.json', 'references/rubric.md']
    return digest({n: sha(root/n) for n in names})


def ready(row):
    m = row['manifest']
    if m['availability'] != 'ready':
        return False
    proof = row.get('readiness', {})
    if m['source']['origin'] == 'built-in' and m['id'] in BUILTIN_IDS.values():
        method = next(k for k, v in BUILTIN_IDS.items() if v == m['id'])
        return m == manifest(m['id'], method, 'built-in') and proof.get('implementation_hash') == implementation_hash()
    if proof.get('scope') == 'local_fixed_template_only' and row.get('bundle'):
        return (proof.get('bundle_hash') == bundle_identity(row['bundle'])
                and proof.get('implementation_hash') == implementation_hash())
    return False


def register(registry_path, bundle):
    root = Path(bundle).resolve()
    m = load(root/'manifest.json')
    check_manifest(m)
    require((root/'SKILL.md').is_file(), 'SKILL.md required')
    r = registry_read(registry_path)
    require(not any(x['manifest']['id'] == m['id'] and x['manifest']['version'] == m['version'] for x in r['entries']), 'Duplicate Skill ID/version')
    m = copy.deepcopy(m)
    m.update(registration_status='registered', availability='pending_installation', validation_status='unverified')
    # Source claims and self-reported validation do not grant local execution.
    row = {'manifest': m, 'bundle': str(root), 'declared_manifest_sha256': sha(root/'manifest.json'), 'readiness': {}}
    r['entries'].append(row)
    registry_save(registry_path, r)
    return row


def check_spec(spec, frozen=False):
    validate(spec, SPEC)
    check_seal(spec, 'spec_hash')
    ids = [r['id'] for r in spec['requirements']]
    require(len(ids) == len(set(ids)), 'Duplicate requirement IDs')
    item_ids = [r['id'] for r in spec['items']]
    require(len(item_ids) == len(set(item_ids)) and set(item_ids) <= set(ids), 'Invalid item IDs')
    require(any(r['required'] for r in spec['requirements']), 'At least one required evaluation check')
    require(spec['budget']['evaluation_reserve_seconds'] < spec['budget']['wall_time_seconds'], 'Evaluation reserve must fit budget')
    for row in spec['requirements']:
        validate_definition(row['definition'])
        require(row['id'] == row['definition']['id'], 'Requirement and definition IDs differ')
    for row in spec['items']:
        original = next(x for x in spec['requirements'] if x['id'] == row['id'])
        require(all(row[k] == original[k] for k in original), 'Resolved evaluator changed the requested criterion')
    if frozen:
        require(spec['status'] == 'FROZEN', 'Evaluation Specification must be frozen')
        require(not spec['issues'] and not spec['uncovered'], 'Unresolved criteria cannot be frozen')
        require(set(item_ids) == set(ids), 'Frozen specification must bind every criterion')
    return spec


def build_spec(brief, registry_path):
    """Host LLM supplies semantic fields; default profile adds only operational QA."""
    for k in ('task_id', 'dataset_version', 'goal', 'task_type', 'domain', 'budget'):
        require(k in brief, 'Structured brief missing '+k)
    qa = {'id': 'execution-qa', 'capability': 'execution_qa', 'required': True,
          'definition': definition('execution-qa', 'integrity')}
    reqs = [qa] + copy.deepcopy(brief.get('requirements', []))
    for r in reqs:
        validate_definition(r['definition'])
    spec = {'schema_version': '1.0', **{k: brief[k] for k in ('task_id', 'dataset_version', 'goal', 'task_type', 'domain')},
            'profile_id': brief.get('profile_id', 'cellsight-basic-task-qa'), 'version': brief.get('version', '1.0.0'),
            'status': 'DRAFT', 'evaluation_object': 'user_task', 'required_outputs': brief.get('required_outputs', []),
            'requirements': reqs, 'items': [], 'decision': 'UNAVAILABLE', 'uncovered': [],
            'issues': brief.get('scientific_questions', []),
            'evidence_policy': {'supervised_metrics_require_private_labels': True, 'final_test_feedback_for_replanning': False},
            'failure_policy': {'max_replans': brief.get('max_replans', 2), 'allow_threshold_relaxation': False},
            'budget': brief['budget']}
    return resolve(seal(spec, 'spec_hash'), registry_path)


def resolve(spec, registry_path):
    check_spec(spec)
    require(spec['status'] == 'DRAFT', 'Resolve a draft; create a new version to change frozen criteria')
    rows = registry_read(registry_path)['entries']
    body = {k: copy.deepcopy(v) for k, v in spec.items() if k != 'spec_hash'}
    body.update(items=[], uncovered=[])
    generatable = True
    for req in spec['requirements']:
        candidates = []
        for row in rows:
            m = row['manifest']
            if m['type'] != 'evaluation' or not ready(row):
                continue
            if req['capability'] not in m['capabilities']['methods']:
                continue
            if spec['task_type'] not in m['capabilities']['tasks'] and '*' not in m['capabilities']['tasks']:
                continue
            if spec['domain'] not in m['domain_scope']['domains'] and '*' not in m['domain_scope']['domains']:
                continue
            if row.get('bundle'):
                # Generated evaluator semantics are pinned, not interchangeable by method name.
                if digest(load(Path(row['bundle'])/'definition.json')) != digest(req['definition']):
                    continue
            candidates.append(row)
        if not candidates:
            body['uncovered'].append(req['id'])
            generatable &= req['definition']['method'] in {'ratio', 'field_range', 'rubric'} and req['capability'] == METHOD_CAP[req['definition']['method']]
            continue
        row = sorted(candidates, key=lambda x: (x['manifest']['source']['origin'] != 'built-in', x['manifest']['id']))[0]
        m = row['manifest']
        body['items'].append({**req, 'evaluator': {'id': m['id'], 'version': m['version'],
                             'manifest_hash': digest(m), 'implementation_hash': implementation_hash()}})
    body['decision'] = ('GENERATE' if generatable else 'UNAVAILABLE') if body['uncovered'] else (
        'REUSE' if len({x['evaluator']['id'] for x in body['items']}) == 1 else 'COMPOSE')
    return check_spec(seal(body, 'spec_hash'))


def bound_rows(spec, registry_path):
    rows = registry_read(registry_path)['entries']
    result = []
    for item in spec['items']:
        pin = item['evaluator']
        matched = [r for r in rows if r['manifest']['id'] == pin['id'] and r['manifest']['version'] == pin['version']]
        require(len(matched) == 1 and ready(matched[0]), 'Evaluator unavailable: '+pin['id'])
        row = matched[0]
        require(digest(row['manifest']) == pin['manifest_hash'] and implementation_hash() == pin['implementation_hash'], 'Evaluator changed after binding')
        if row.get('bundle'):
            require(digest(load(Path(row['bundle'])/'definition.json')) == digest(item['definition']), 'Generated definition changed')
        else:
            method = next((k for k, v in BUILTIN_IDS.items() if v == row['manifest']['id']), None)
            require(method == item['definition']['method'] and METHOD_CAP[method] == item['capability'], 'Evaluator method mismatch')
        result.append(row)
    return result


def freeze(spec, registry_path):
    check_spec(spec)
    require(spec['status'] == 'DRAFT', 'Already frozen; explicit new version required')
    require(not spec['issues'] and not spec['uncovered'], 'Resolve scientific questions and unavailable evaluator capabilities first')
    bound_rows(spec, registry_path)
    body = {k: v for k, v in spec.items() if k != 'spec_hash'}
    body['status'] = 'FROZEN'
    return check_spec(seal(body, 'spec_hash'), True)


def safe_public(value):
    """Formal-test label contents/paths stay in the evaluator; metadata can be public."""
    if isinstance(value, dict):
        forbidden = {'ground_truth', 'ground_truth_path', 'test_labels', 'labels_path', 'private_labels', 'annotation_path'}
        require(not (set(value) & forbidden), 'Private labels cannot enter planning')
        for v in value.values():
            safe_public(v)
    elif isinstance(value, list):
        for v in value:
            safe_public(v)


def bind_plan(spec_path, proposed):
    spec = check_spec(load(spec_path), True)
    safe_public(proposed)
    require(proposed['task_id'] == spec['task_id'] and proposed['dataset_version'] == spec['dataset_version'], 'Task/dataset identity mismatch')
    steps, seen, outputs = proposed['steps'], set(), set()
    for step in steps:
        require(step['step_id'] not in seen and set(step['depends_on']) <= seen, 'Duplicate, cyclic or unsorted dependency')
        require(re.fullmatch(r'cellsight-[a-z0-9-]+', step['skill_id']) is not None, 'Use a full Skill ID')
        seen.add(step['step_id'])
        outputs.update(step['output_types'])
    require(set(spec['required_outputs']) <= outputs, 'Plan cannot produce required artifacts')
    require(sum(s['wall_time_seconds'] for s in steps)+spec['budget']['evaluation_reserve_seconds'] <= spec['budget']['wall_time_seconds'], 'Plan exceeds execution/evaluation budget')
    plan = {'schema_version': 'meta-plan-1.0', 'task_id': spec['task_id'], 'dataset_version': spec['dataset_version'],
            'spec_hash': spec['spec_hash'], 'spec_ref': {'path': str(Path(spec_path).resolve()), 'sha256': sha(spec_path)},
            'status': 'READY_FOR_HOST_CHECK', 'steps': steps, 'budget': spec['budget'], 'execution_performed': False}
    plan = seal(plan, 'plan_hash')
    validate(plan, PLAN)
    return plan


def evaluate(spec_path, registry_path, input_path, output=None, private_labels_path=None, judge=None):
    started = time.monotonic()
    spec = check_spec(load(spec_path), True)
    bound_rows(spec, registry_path)
    payload = load(input_path)
    evidence = [{'kind': 'evaluation_input', 'path': str(Path(input_path).resolve()), 'sha256': sha(input_path)}]
    labels, source_type, rows = None, 'user_task_evaluation', []
    try:
        validate(payload, PAYLOAD)
        require(payload['task_id'] == spec['task_id'] and payload['dataset_version'] == spec['dataset_version'], 'Evaluation input belongs to another task/dataset')
        artifact_ids = [x['artifact_id'] for x in payload['artifacts']]
        require(len(artifact_ids) == len(set(artifact_ids)), 'Duplicate artifact IDs')
        require(set(spec['required_outputs']) <= {x['type'] for x in payload['artifacts']}, 'Required output artifact missing')
        for artifact in payload['artifacts']:
            p = (Path(input_path).resolve().parent/artifact['path']).resolve()
            require(p.is_file() and sha(p) == artifact['sha256'], 'Output artifact missing or changed')
            evidence.append({'kind': 'output_artifact', 'path': str(p), 'sha256': sha(p)})
        if private_labels_path:
            labels = load(private_labels_path)
            if labels.get('role') == 'final_test':
                source_type = 'external_benchmark'
            require(labels.get('task_id') == spec['task_id'] and labels.get('dataset_version') == spec['dataset_version'], 'Private label identity mismatch')
            require(labels.get('role') in {'development', 'final_test'}, 'Label split role required')
            require(labels.get('source') and labels.get('records') is not None, 'Label source and records required')
            evidence.append({'kind': 'evaluator_private_ground_truth', 'sha256': sha(private_labels_path), 'role': labels['role'],
                             'source': labels['source'], 'path_withheld_from_planner': True})
        for item in spec['items']:
            d = item['definition']
            evaluated = score(d, payload, labels, judge, evidence)
            rows.append({'id': item['id'], 'required': item['required'], 'eval_skill_id': item['evaluator']['id'],
                         'eval_skill_version': item['evaluator']['version'], 'method': d['method'],
                         'definition_hash': digest(d), **evaluated})
    except Exception as exc:
        rows = [{'id': 'input-integrity', 'required': True, 'eval_skill_id': BUILTIN_IDS['integrity'],
                 'eval_skill_version': VERSION, 'method': 'integrity', 'definition_hash': digest(definition('input-integrity', 'integrity')),
                 'status': 'ERROR', 'reason': type(exc).__name__+': '+str(exc), 'metrics': {}}]
    status = aggregate(rows)
    missing = [r['id']+': '+r['reason'] for r in rows if r['status'] in {'NOT_EVALUABLE', 'NEEDS_REVIEW', 'ERROR'}]
    action = 'NONE' if status == 'PASS' else 'REVISE' if status == 'FAIL' else 'ESCALATE'
    if source_type == 'external_benchmark':
        action = 'NONE' if status == 'PASS' else 'ESCALATE'
    report = {'schema_version': '3.0', 'task_id': spec['task_id'], 'dataset_version': spec['dataset_version'],
              'spec_hash': spec['spec_hash'], 'source_type': source_type, 'status': status, 'items': rows,
              'input_ref': {'path': str(Path(input_path).resolve()), 'sha256': sha(input_path)}, 'evidence': evidence,
              'unverified_matters': missing,
              'evaluation_scope': 'Only declared checks on supplied artifacts/values; supervised metrics require evaluator-private labels.',
              'recommendation': {'action': action, 'reason': 'Follow fixed criteria; preserve failures. Final-test reports cannot drive automatic replanning.'},
              'limitations': ['No biological validity or real CV accuracy follows from bookkeeping or arithmetic consistency.',
                              'LLM review independence is not established. Registry/local process boundaries are not an OS sandbox.',
                              'Evidence paths and hashes verify supplied files, not an authenticated SciencePal tool execution trace.'],
              'wall_time_seconds': time.monotonic()-started}
    report = seal(report, 'report_hash')
    check_report(report, spec)
    if output:
        require(not Path(output).exists(), 'Use a new report output path; preserve previous evidence')
        write(output, report)
    return report


def check_report(report, spec):
    check_seal(report, 'report_hash')
    validate(report, REPORT)
    check_spec(spec, True)
    require(report['spec_hash'] == spec['spec_hash'] and report['task_id'] == spec['task_id']
            and report['dataset_version'] == spec['dataset_version'], 'Stale/cross-task report')
    rows = report['items']
    integrity_error = len(rows) == 1 and rows[0]['id'] == 'input-integrity' and rows[0]['status'] == 'ERROR'
    if not integrity_error:
        require(len(rows) == len(spec['items']) and {r['id'] for r in rows} == {i['id'] for i in spec['items']}, 'Report omitted or duplicated a declared check')
        for row in rows:
            item = next(i for i in spec['items'] if i['id'] == row['id'])
            require(row['required'] == item['required'] and row['method'] == item['definition']['method']
                    and row['definition_hash'] == digest(item['definition'])
                    and row['eval_skill_id'] == item['evaluator']['id']
                    and row['eval_skill_version'] == item['evaluator']['version'], 'Report criterion binding changed')
    require(aggregate(rows) == report['status'], 'Report status contradicts mandatory checks')
    require(report['status'] != 'PASS' or report['recommendation']['action'] == 'NONE', 'PASS report cannot request repair')
    return report


def feedback(report, spec):
    check_report(report, spec)
    require(report['source_type'] != 'external_benchmark', 'Final-test feedback cannot enter automatic replanning')
    return {'task_id': spec['task_id'], 'spec_hash': spec['spec_hash'],
            'recommendation': report['recommendation'], 'issues': report['unverified_matters'],
            'failed_items': [x['id'] for x in report['items'] if x['status'] != 'PASS'],
            'report_hash': report['report_hash'], 'max_replans': spec['failure_policy']['max_replans']}


def template_cases(d):
    """Arithmetic test fixtures only; these are not images or cell model predictions."""
    p = d['parameters']
    def put(payload, path, value):
        current = payload
        parts = path.split('.')
        for k in parts[:-1]:
            current = current.setdefault(k, {})
        current[parts[-1]] = value
    base = {'task_id': 'template-unit-check', 'dataset_version': 'handwritten-numeric-fixture', 'values': {}, 'artifacts': []}
    if d['method'] == 'ratio':
        good = copy.deepcopy(base)
        put(good, p['numerator_path'], 1)
        put(good, p['denominator_path'], 2)
        put(good, p['reported_path'], 0.5)
        bad = copy.deepcopy(good)
        put(bad, p['reported_path'], 0.2)
        empty = copy.deepcopy(good)
        put(empty, p['denominator_path'], 0)
        accepted = d['acceptance'].get('min', 0) <= 0.5 <= d['acceptance'].get('max', 1)
        expected = ('NEEDS_REVIEW' if d['scientific_basis']['status'] == 'needs_expert_review' else 'PASS') if accepted else 'FAIL'
        return [{'name': 'known-half', 'input': good, 'expected': expected},
                {'name': 'incorrect-reported-ratio', 'input': bad, 'expected': 'FAIL'},
                {'name': 'empty-population', 'input': empty, 'expected': 'NOT_EVALUABLE'}]
    if d['method'] == 'field_range':
        a = d['acceptance']
        require(a, 'Generated range evaluator needs at least one bound')
        good = copy.deepcopy(base)
        low, high = a.get('min'), a.get('max')
        value = (low+high)/2 if low is not None and high is not None else (low if low is not None else high)
        put(good, p['value_path'], value)
        put(good, p['unit_path'], p['unit'])
        bad = copy.deepcopy(good)
        put(bad, p['value_path'], low-1 if low is not None else high+1)
        wrong_unit = copy.deepcopy(good)
        put(wrong_unit, p['unit_path'], 'wrong-unit')
        return [{'name': 'inside-declared-range', 'input': good, 'expected': 'NEEDS_REVIEW' if d['scientific_basis']['status'] == 'needs_expert_review' else 'PASS'},
                {'name': 'outside-range', 'input': bad, 'expected': 'FAIL'},
                {'name': 'wrong-unit', 'input': wrong_unit, 'expected': 'ERROR'}]
    return [{'name': 'missing-actual-judge', 'input': base, 'expected': 'NOT_EVALUABLE'}]


def generated_test_source():
    return '''"""Template software tests. Does not validate biological rules."""
import sys
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'scripts'))
from metric_core import load, score
class EvaluatorTests(unittest.TestCase):
    def test_declared_numeric_cases(self):
        definition = load(ROOT/'definition.json')
        for case in load(ROOT/'tests/cases.json'):
            with self.subTest(case=case['name']):
                self.assertEqual(score(definition, case['input'])['status'], case['expected'])
if __name__ == '__main__':
    unittest.main(verbosity=2)
'''


def generate(sid, d, output, task='*', domain='*'):
    validate(d, DEFINITION)
    validate_definition(d)
    require(d['method'] in {'ratio', 'field_range', 'rubric'}, 'Generator supports bounded scalar/rubric templates only')
    require(re.fullmatch(r'cellsight-eval-[a-z0-9-]+', sid) is not None and len(sid) < 64, 'Use cellsight-eval-* below 64 characters')
    require(sid not in BUILTIN_IDS.values(), 'Generated package cannot shadow a built-in evaluator')
    root = Path(output).resolve()
    require(not root.exists(), 'Use a new generated Skill directory')
    m = manifest(sid, d['method'], task=task, domains=[domain])
    root.mkdir(parents=True)
    write(root/'manifest.json', m)
    write(root/'definition.json', d)
    write(root/'schemas/input.schema.json', PAYLOAD)
    # Standalone launcher has a compact report; unified Runtime returns the full 3.0 report.
    compact = copy.deepcopy(COMPACT_REPORT)
    write(root/'schemas/report.schema.json', compact)
    m['output_schema'] = compact
    write(root/'manifest.json', m)
    scripts = root/'scripts'
    scripts.mkdir()
    (scripts/'metric_core.py').write_bytes((Path(__file__).parent/'metric_core.py').read_bytes())
    (scripts/'evaluate.py').write_bytes((Path(__file__).parent/'template_evaluate.py').read_bytes())
    write(root/'tests/cases.json', template_cases(d))
    (root/'tests/test_evaluator.py').write_text(generated_test_source(), encoding='utf-8')
    (root/'SKILL.md').write_text('---\nname: '+sid+'\ndescription: 按任务已声明的'+d['method']+'规则检查输入证据，返回有范围限制的评价结果。\n---\n\n# CellSight Task-specific Evaluation\n\n'
        '先读取[规则](definition.json)、[Manifest](manifest.json)及[适用范围](references/rubric.md)。核实用户科学定义和实际输入；'
        '本包生成后处于待安装状态，不能自行授予权限。\n\n'
        '程序入口：`python scripts/evaluate.py --input INPUT.json --output NEW-report.json`。'
        '输入遵循[Schema](schemas/input.schema.json)，报告遵循[Schema](schemas/report.schema.json)。'
        '在实际资源目录执行；使用新报告路径并保留来源。未配置真实LLM Judge时Rubric返回NOT_EVALUABLE。\n\n'
        'PASS仅表示所声明检查通过；比例复算不证明细胞分类正确，领域阈值不因脚本运行而获得科学验证。'
        '共享发布须实际注册、宿主授权和科学适用性审查。\n', encoding='utf-8')
    (root/'references').mkdir()
    (root/'references/rubric.md').write_text('# 评价范围\n\n'+json_text(d)+'\n\n'
        'operational_rule表示用户声明的计算/验收规则，不代表生物学正确。needs_expert_review的通过项保留NEEDS_REVIEW。'
        '随包测试仅验证实现；特殊科学定义须由独立证据或专家确认。\n', encoding='utf-8')
    return {'skill_id': sid, 'output': str(root), 'registration_status': 'unregistered',
            'availability': 'pending_installation', 'definition_hash': digest(d)}


def json_text(value):
    import json
    return '```json\n'+json.dumps(value, ensure_ascii=False, indent=2)+'\n```'


def validate_bundle(bundle, run_tests=True):
    root = Path(bundle).resolve()
    report = {'structure': 'ERROR', 'metric_definition': 'NOT_EVALUABLE', 'executability': 'NOT_EVALUABLE',
              'scientific_validity': 'NEEDS_REVIEW', 'status': 'NEEDS_REVIEW', 'errors': [],
              'tests_executed': 0, 'scope': 'No arbitrary uploaded code is imported/executed; scientific correctness is not certified.'}
    try:
        m = load(root/'manifest.json')
        check_manifest(m)
        skill = (root/'SKILL.md').read_text(encoding='utf-8')
        require(re.search(r'^name:\s*'+re.escape(m['id'])+r'\s*$', skill, re.M), 'Manifest/SKILL name mismatch')
        report['structure'] = 'PASS'
        if not (root/'definition.json').is_file():
            report['errors'].append('Third-party implementation needs an actual host review/execution path.')
            return report
        d = load(root/'definition.json')
        validate(d, DEFINITION)
        validate_definition(d)
        require(m['type'] == 'evaluation' and m['capabilities']['methods'] == [METHOD_CAP[d['method']]], 'Manifest/definition capability mismatch')
        require(m['permissions'] == {'network': False, 'filesystem': 'host_scoped', 'subprocess': False}, 'Template permissions differ')
        require(m['entrypoint'] == {'kind': 'python', 'name': 'scripts/evaluate.py'}, 'Template entrypoint differs')
        require(m['input_schema'] == PAYLOAD and load(root/'schemas/input.schema.json') == PAYLOAD, 'Input Schema mismatch')
        require(m['output_schema'] == load(root/'schemas/report.schema.json') == COMPACT_REPORT, 'Output Schema mismatch')
        report['metric_definition'] = 'PASS'
        report['scientific_validity'] = ('NOT_EVALUABLE' if d['scientific_basis']['status'] == 'needs_expert_review' else 'NEEDS_REVIEW')
        # Compare actual source to packaged fixed templates BEFORE any subprocess.
        allowed_files = {'SKILL.md', 'manifest.json', 'definition.json', 'schemas/input.schema.json',
                         'schemas/report.schema.json', 'scripts/evaluate.py', 'scripts/metric_core.py',
                         'tests/test_evaluator.py', 'tests/cases.json', 'references/rubric.md'}
        require(not any(p.is_symlink() for p in root.rglob('*')), 'Symlinked template resources cannot be executed')
        require({p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == allowed_files,
                'Unexpected template files; import shadowing/extra code is not allowed')
        require((root/'scripts/metric_core.py').read_bytes() == (Path(__file__).parent/'metric_core.py').read_bytes(), 'Untrusted evaluator source; code not executed')
        require((root/'scripts/evaluate.py').read_bytes() == (Path(__file__).parent/'template_evaluate.py').read_bytes(), 'Untrusted launcher; code not executed')
        require((root/'tests/test_evaluator.py').read_text(encoding='utf-8') == generated_test_source(), 'Untrusted test code; code not executed')
        require(load(root/'tests/cases.json') == template_cases(d), 'Template cases changed')
        if run_tests:
            env = dict(__import__('os').environ, PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
            run = subprocess.run([sys.executable, '-B', str(root/'tests/test_evaluator.py')], capture_output=True,
                                 text=True, encoding='utf-8', timeout=20, env=env)
            require(run.returncode == 0, 'Template tests failed: '+run.stderr)
            # Actually launch the evaluator and validate each result, not just its score function.
            import tempfile
            with tempfile.TemporaryDirectory(dir=root.parent, prefix='cellsight-validate-') as temp:
                for index, case in enumerate(template_cases(d)):
                    ip = write(Path(temp)/f'input-{index}.json', case['input'])
                    op = Path(temp)/f'report-{index}.json'
                    process = subprocess.run([sys.executable, '-B', str(root/'scripts/evaluate.py'), '--input', str(ip), '--output', str(op)],
                                             capture_output=True, text=True, encoding='utf-8', timeout=20, env=env)
                    require(process.returncode == 0, 'Template CLI failed: '+process.stderr)
                    out = load(op)
                    validate(out, m['output_schema'])
                    check_seal(out, 'report_hash')
                    require(out['status'] == case['expected'], 'Template CLI wrong result')
                    report['tests_executed'] += 1
            report['launcher_trial'] = 'PASS'
            if d['method'] == 'rubric':
                # A NOT_EVALUABLE response proves the launcher works, not an actual judge.
                report['executability'] = 'NOT_EVALUABLE'
                report['evaluation_trial'] = 'NOT_EVALUABLE'
                report['errors'].append('Only the missing-Judge branch was tested; an actual host Judge trial is required.')
            else:
                report['executability'] = 'PASS'
                report['evaluation_trial'] = 'PASS'
        report['status'] = 'NEEDS_REVIEW'  # Technical verification never certifies domain science.
        report['bundle_hash'] = bundle_identity(root)
    except Exception as exc:
        report['status'] = 'ERROR'
        report['errors'].append(type(exc).__name__+': '+str(exc))
    return report


def activate_template(registry_path, sid, version=None):
    r = registry_read(registry_path)
    matched = [row for row in r['entries'] if row['manifest']['id'] == sid and (version is None or row['manifest']['version'] == version)]
    require(len(matched) == 1 and matched[0].get('bundle'), 'Select a unique registered package')
    row = matched[0]
    report = validate_bundle(row['bundle'])
    require(report['structure'] == report['metric_definition'] == report['executability'] == 'PASS', 'Template not executable: '+str(report['errors']))
    original = load(Path(row['bundle'])/'manifest.json')
    require(original['id'] == row['manifest']['id'] and original['version'] == row['manifest']['version'], 'Registered package identity changed')
    require(row['declared_manifest_sha256'] == sha(Path(row['bundle'])/'manifest.json'), 'Manifest changed after registration')
    row['manifest'].update(availability='ready', validation_status='template_verified')
    row['readiness'] = {'scope': 'local_fixed_template_only', 'bundle_hash': report['bundle_hash'],
                        'implementation_hash': implementation_hash(), 'scientific_validity': report['scientific_validity']}
    registry_save(registry_path, r)
    return {'skill_id': sid, 'availability': 'ready', 'scope': 'local_fixed_template_only',
            'host_skill_mounted': False, 'scientific_validity': report['scientific_validity']}
