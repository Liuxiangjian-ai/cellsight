"""Project State/Orchestration adapter over the existing persisted event ledger."""
from pathlib import Path
import copy
import importlib.util
import json
import subprocess
import sys
import time
from cs_common import ROOT,CORE,load,write,sha,digest,require,ref,check_ref,now,check_seal,no_truth,validate,schema,finite
import cs_plan as planner
import cs_eval as evaluation
import cs_registry as registry

spec=importlib.util.spec_from_file_location('cellsight_legacy_coordination',ROOT/'scripts/coordinate.py')
LEDGER=importlib.util.module_from_spec(spec); spec.loader.exec_module(LEDGER)

def read(project):
    directory,state=LEDGER.read_state(project)
    require(state.get('orchestration_mode')=='eval_first_v2','Use the legacy CLI to resume a legacy project; migrate explicitly, never reinterpret role records.')
    return directory,state

def start(brief_path,project):
    LEDGER.start(brief_path,project)
    project=Path(project).resolve()
    with LEDGER.exclusive(project):
        _,state=LEDGER.read_state(project)
        state.update(orchestration_mode='eval_first_v2',pending_job=None,eval_skills={},eval_bindings={},phase='awaiting_contract_and_plan')
        return LEDGER.commit(project,state,'enable_eval_first',{'planner_scope':'intent_routing_plan_bounded_replan','role_reviews_required':False})

def inspect(state):
    _,plan,contract=planner.read(state['plan']['directory'])
    require(plan['plan_hash']==state['plan']['plan_hash'] and contract['contract_hash']==state['plan']['contract_hash'],'Active plan changed; explicit revision required.')
    return plan,contract

def verify(state):
    if not state['plan']: return
    plan,contract=inspect(state); planner.verify_runtime_registry(plan)
    catalog=registry.read(plan['registry_ref']['path'])
    for item in contract['items']:
        m=registry.get(catalog,item['evaluator']['id'],item['evaluator']['version'])
        require(registry.ready(m) and registry.identity(m)==item['evaluator']['manifest_hash'],'Frozen Eval Skill changed or became unavailable.')
    for row in contract['input_refs']: check_ref(row)
    for row in state['results'].values():
        p=check_ref(row); payload=load(p)
        for artifact in payload.get('artifacts',[]):
            check_ref({'path':str(CORE.resolve(artifact['path'],p.parent)),'sha256':artifact['sha256']})
        for evidence in row.get('execution_evidence',[]): check_ref(evidence)
    for row in state['evaluations'].values():
        report=load(check_ref(row)); check_seal(report,'report_hash')
        for item in report['items']:
            for evidence in item['evidence']: check_ref(evidence)
    if state['delivery']:
        for row in state['delivery']['files']: check_ref(row)

def attach(project,plan_dir):
    project=Path(project).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); require(state['phase']!='cancelled','Stopped project cannot accept a plan.')
        require(state['plan'] is None,'Initial plan already attached; use explicit revision.')
        _,plan,contract=planner.read(plan_dir); _bind(state,plan_dir,plan,contract)
        return LEDGER.commit(project,state,'attach_eval_first_plan',{'plan_hash':plan['plan_hash'],'contract_hash':contract['contract_hash']})

def _bind(state,directory,plan,contract):
    require(plan['experiment_id']==state['experiment_id'] and plan['dataset_version']==state['dataset_version'],'Plan experiment/dataset mismatch.')
    require(plan['goal']==state['goal'],'Plan changed the original scientific goal.')
    require(plan['budget']['device']==state['budget'].get('device'),'Device resource boundary differs.')
    require(plan['budget']['wall_time_seconds']<=state['budget']['wall_time_seconds']-state['spent_seconds'],'Plan exceeds remaining recorded budget.')
    planner.verify_runtime_registry(plan)
    state['plan']={'directory':str(Path(directory).resolve()),'plan_hash':plan['plan_hash'],'contract_hash':contract['contract_hash']}
    state['max_revisions']=min(state['max_revisions'],contract['failure_policy']['max_replans'])
    state['phase']='preflight_pending'

def next_action(state):
    if state['phase']=='cancelled': return {'action':'STOPPED','reason':state.get('stop_reason')}
    verify(state)
    if state['pending_job']: return {'action':'RECONCILE_JOB',**state['pending_job'],'automatic_resubmission':False}
    if state['spent_seconds']>=state['budget']['wall_time_seconds']: return {'action':'BUDGET_EXHAUSTED','recommendation':'ESCALATE'}
    if not state['plan']: return {'action':'BUILD_CONTRACT_THEN_PLAN'}
    if state['phase']=='completed': return {'action':'COMPLETED','delivery':state['delivery']}
    plan,contract=inspect(state)
    for row in state['evaluations'].values():
        if row['status']!='PASS':
            report=load(row['path']); action=report['recommendation']['action']
            if state['revision']>=state['max_revisions']: action='ESCALATE'
            return {'action':action,'evaluation_status':row['status'],'report_ref':row['path'],'revision':state['revision'],'max_revisions':state['max_revisions']}
    if 'preflight' not in state['evaluations']: return {'action':'EVALUATE','stage':'preflight'}
    for step in plan['steps']:
        sid=step['step_id']; result=state['results'].get(sid)
        if result and result['status']!='succeeded': return {'action':'ESCALATE','reason':'Execution failure requires diagnosis and explicit repair.','result_ref':result['path'],'affected':planner.affected(plan,[sid])}
        if result:
            if 'stage:'+sid not in state['evaluations']: return {'action':'EVALUATE','stage':'stage','step_id':sid}
            continue
        return {'action':'EXECUTE','step_id':sid,'skill_id':step['skill_id'],'implementation_id':step['proposed_implementation_id']}
    if 'final' not in state['evaluations']: return {'action':'EVALUATE','stage':'final'}
    return {'action':'DELIVER','evaluated_results_hash':evaluation.result_set_hash({k:r['path'] for k,r in state['results'].items()})}

def status(project):
    _,state=read(project)
    return {'experiment_id':state['experiment_id'],'goal':state['goal'],'phase':state['phase'],'revision':state['revision'],
      'spent_seconds':state['spent_seconds'],'remaining_seconds':max(0,state['budget']['wall_time_seconds']-state['spent_seconds']),
      'results':{k:r['status'] for k,r in state['results'].items()},'evaluations':{k:r['status'] for k,r in state['evaluations'].items()},'next':next_action(state)}

def record_eval(project,report_path):
    project=Path(project).resolve(); path=Path(report_path).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); report=load(path); check_seal(report,'report_hash'); validate(report,schema('evaluation-report'))
        key='stage:'+report['step_id'] if report['stage']=='stage' else report['stage']
        if key in state['evaluations']:
            require(state['evaluations'][key]['sha256']==sha(path),'Evaluation cannot be overwritten; explicit revision required.'); return state
        action=next_action(state)
        require(action['action']=='EVALUATE' and action['stage']==report['stage'] and action.get('step_id')==report.get('step_id'),'Evaluation out of order.')
        plan,contract=inspect(state)
        require(report['source_type']=='operational_evaluation','External Benchmark must not feed the operational replanner.')
        require(report['experiment_id']==state['experiment_id'] and report['dataset_version']==state['dataset_version'],'Evaluation experiment/dataset mismatch.')
        require(report['plan_hash']==plan['plan_hash'] and report['contract_hash']==contract['contract_hash'],'Stale evaluation plan/Contract.')
        require(report['evaluation_scope']==contract['evaluation_scope'],'Evaluation scope was silently changed.')
        expected={k:r['path'] for k,r in state['results'].items()}
        require(report['evaluated_results_hash']==evaluation.result_set_hash(expected),'Evaluation used a different result set.')
        require(set(report.get('result_refs',{}))==set(expected),'Evaluation omitted a result reference.')
        for sid,row in report['result_refs'].items(): require(row['sha256']==sha(Path(expected[sid])),'Evaluation result hash differs.')
        if report['status']=='PASS':
            require(all(i['status']=='PASS' for i in report['items']) and all(v=='PASS' for v in report['public_checks'].values()),'Failed/unresolved checks cannot be averaged into PASS.')
            expected_ids={'public-integrity'} if report['stage']=='preflight' else {i['id'] for i in contract['items'] if report['stage'] in i['stages']}
            require(expected_ids<={i['id'] for i in report['items']},'PASS report omitted a required Contract item.')
        for item in report['items']:
            for evidence in item['evidence']: check_ref(evidence)
        state['evaluations'][key]={**ref(path),'status':report['status']}
        state['spent_seconds']+=report['wall_time_seconds']; state['phase']='evaluated' if report['status']=='PASS' else 'needs_revision'
        return LEDGER.commit(project,state,'record_eval_v2',{'stage':report['stage'],'step_id':report.get('step_id'),'status':report['status'],'report_sha256':sha(path)})

def evaluate_next(project,output,judge=None):
    _,state=read(project); action=next_action(state); require(action['action']=='EVALUATE','No evaluation is due.')
    report=evaluation.evaluate(state['plan']['directory'],{k:r['path'] for k,r in state['results'].items()},action['stage'],output,action.get('step_id'),judge)
    record_eval(project,output); return report

def record_result(project,step_id,result_path):
    project=Path(project).resolve(); path=Path(result_path).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project)
        if step_id in state['results']:
            require(state['results'][step_id]['sha256']==sha(path),'Execution result cannot be overwritten.'); return state
        job=state.get('pending_job'); require(job and job['step_id']==step_id,'Result must match a reserved execution job.')
        require(path==Path(job['output_dir'])/'result.json','Result path differs from the reserved job.')
        plan,contract=inspect(state); result=load(path); step=next(s for s in plan['steps'] if s['step_id']==step_id)
        catalog=planner.verify_runtime_registry(plan)
        manifest=registry.get(catalog,step['skill_id'],plan['execution_manifests'][step['skill_id']]['version'])
        validate(result,manifest['output_schema'])
        require(result['experiment_id']==state['experiment_id'] and result['dataset_version']==state['dataset_version'],'Execution identity mismatch.')
        for key,expected in [('request_id',state['experiment_id']+'-'+step_id),('implementation_id',step['proposed_implementation_id']),('task',step['task']),('mode',step['mode']),('eval_contract_sha256',plan['execution_contract_ref']['sha256'])]:
            require(result.get(key)==expected,'Execution result does not bind '+key)
        require(result.get('original_request_hash')==job['request_hash'],'Execution did not use the reserved request.')
        require(sha(Path(job['request_path']))==job['request_sha256'],'Reserved request changed while job was running.')
        require(result['status'] in {'succeeded','blocked','failed','budget_exhausted','cancelled'},'Only terminal execution results can be recorded.')
        require(finite(result.get('wall_time_seconds')) and result['wall_time_seconds']>=0,'Actual execution duration required.')
        evidence=[]
        for name in ['request.json','environment.json','eval-contract.snapshot.json']:
            p=path.parent/name
            if p.exists(): evidence.append(ref(p))
        if result['status']=='succeeded':
            require(result.get('artifacts'),'Successful execution omitted artifacts.')
            for artifact in result['artifacts']: check_ref({'path':str(CORE.resolve(artifact['path'],path.parent)),'sha256':artifact['sha256']})
        effective='budget_exhausted' if result['wall_time_seconds']>step['wall_time_seconds'] else result['status']
        state['results'][step_id]={**ref(path),'status':effective,'source_status':result['status'],'execution_evidence':evidence}
        state['spent_seconds']+=result['wall_time_seconds']; state['pending_job']=None; state['phase']='evaluation_pending' if effective=='succeeded' else 'needs_revision'
        return LEDGER.commit(project,state,'record_execution_v2',{'step_id':step_id,'status':effective,'result_sha256':sha(path)})

def execute_next(project,output_dir):
    project=Path(project).resolve(); output_dir=Path(output_dir).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); action=next_action(state); require(action['action']=='EXECUTE','Execution is gated or another job needs reconciliation.')
        plan,contract=inspect(state); sid=action['step_id']; catalog=planner.verify_runtime_registry(plan)
        m=registry.get(catalog,action['skill_id'],plan['execution_manifests'][action['skill_id']]['version'])
        require(m['entrypoint']=={'kind':'builtin','name':'threshold-boxes'},'No safe local host adapter for third-party Skill; remain pending.')
        request_path=project/(f'request-r{state["revision"]}-{sid}.json')
        request=planner.materialize(state['plan']['directory'],sid,request_path,{k:r['path'] for k,r in state['results'].items()})
        validate(request,m['input_schema'])
        no_truth(request); require(not output_dir.exists(),'Use a new execution output directory.')
        state['pending_job']={'job_id':state['experiment_id']+'-r'+str(state['revision'])+'-'+sid,'step_id':sid,'request_path':str(request_path),'request_sha256':sha(request_path),'request_hash':digest(request),'output_dir':str(output_dir)}
        LEDGER.commit(project,state,'reserve_execution',state['pending_job'])
    started=time.monotonic()
    script=registry.builtin_script(action['skill_id'])
    command=[sys.executable,'-B',str(script),'run','--request',str(request_path),'--output',str(output_dir)]
    try:
        run=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',timeout=request['budget']['wall_time_seconds'],cwd=project)
        if not (output_dir/'result.json').is_file(): raise RuntimeError((run.stderr or run.stdout or 'Runner failed before producing evidence.')[-4000:])
    except Exception as exc:
        output_dir.mkdir(parents=True,exist_ok=True)
        status='budget_exhausted' if isinstance(exc,subprocess.TimeoutExpired) else 'failed'
        if not (output_dir/'result.json').exists():
            write(output_dir/'result.json',{'schema_version':'1.0',**{k:request[k] for k in ['experiment_id','dataset_version','request_id','implementation_id','task','mode']},
              'status':status,'original_request_hash':digest(request),'eval_contract_sha256':sha(Path(request['eval_contract_ref'])),'artifacts':[],'wall_time_seconds':time.monotonic()-started,
              'error':{'type':type(exc).__name__,'message':str(exc)},'provenance':[]})
    record_result(project,sid,output_dir/'result.json'); return load(output_dir/'result.json')

def reconcile(project):
    _,state=read(project); job=state['pending_job']; require(job,'No pending job.')
    path=Path(job['output_dir'])/'result.json'
    require(path.is_file(),'No terminal result available; inspect the existing job. Do not resubmit automatically.')
    return record_result(project,job['step_id'],path)

def revise(project,report_path,outdir):
    project=Path(project).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); verify(state); action=next_action(state)
        require(action['action'] in {'REVISE','REPLAN'},'No authorized operational repair or revision limit reached.')
        require(Path(action['report_ref']).resolve()==Path(report_path).resolve(),'Use the recorded current Evaluation Report.')
        require(state['revision']<state['max_revisions'],'Revision limit reached.')
        remaining=state['budget']['wall_time_seconds']-state['spent_seconds']; require(remaining>0,'Budget exhausted.')
        old=copy.deepcopy(state['plan']); new,scope=planner.replan(old['directory'],report_path,outdir,remaining)
        _,_,contract=planner.read(outdir); require(new['contract_hash']==old['contract_hash'],'Repair must retain the frozen acceptance standard.')
        state['history'].append({'plan':old,'results':state['results'],'evaluations':state['evaluations'],'reason_report':ref(report_path),'reuse_proposal':scope})
        _bind(state,outdir,new,contract); state['revision']+=1; state['results']={}; state['evaluations']={}; state['delivery']=None
        return LEDGER.commit(project,state,'replan_from_evaluation',{'report_sha256':sha(Path(report_path)),'new_plan_hash':new['plan_hash'],'reuse_proposal':scope})

def deliver(project,report_path,artifact_paths):
    project=Path(project).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); require(next_action(state)['action']=='DELIVER','Required execution/Eval gates are incomplete.')
        files=[ref(report_path)]+[ref(p) for p in artifact_paths]; require(len(files)>1,'A readable analysis and actual artifacts are required.')
        state['delivery']={'files':files,'plan_hash':state['plan']['plan_hash'],'contract_hash':state['plan']['contract_hash'],'scope':'declared_contract_scope_only'}
        state['phase']='completed'; return LEDGER.commit(project,state,'deliver_v2',state['delivery'])

def record_cost(project,seconds,reason):
    require(finite(seconds) and seconds>=0 and reason,'Nonnegative actual cost and reason required.')
    project=Path(project).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); state['spent_seconds']+=seconds
        return LEDGER.commit(project,state,'record_cost_v2',{'seconds':seconds,'reason':reason})

def stop(project,reason):
    require(reason,'Stop reason required.'); project=Path(project).resolve()
    with LEDGER.exclusive(project):
        _,state=read(project); state['phase']='cancelled'; state['stop_reason']=reason
        return LEDGER.commit(project,state,'stop_v2',{'reason':reason,'external_job_cancelled':False})
