"""Unified declarations with conservative readiness and a fixed local builtin allowlist."""
from pathlib import Path
import copy
import importlib.util
import os
import subprocess
import sys
from contextlib import contextmanager
from cs_common import ROOT,load,write,sha,digest,require,validate,schema,ref,check_ref,now,sealed,check_seal,atomic_replace

BUILTINS={
 'cellsight-detection-threshold-boxes':('execution','threshold-boxes'),
 'cellsight-eval-basic':('evaluation','deterministic'),
 'cellsight-eval-detection-consistency':('evaluation','scientific_consistency'),
 'cellsight-eval-llm-rubric':('evaluation','llm_rubric'),
}

def builtin_script(identifier):
    if identifier=='cellsight-detection-threshold-boxes': return ROOT/'assets/expert-runtime/cellsight-detection-threshold-boxes/scripts/run.py'
    return ROOT/'scripts/cs_eval.py'

def builtin_manifest(identifier):
    require(identifier in BUILTINS,'Not a packaged builtin.')
    return load(ROOT/'assets/manifests'/(identifier+'.json'))

@contextmanager
def lock(path):
    p=Path(str(path)+'.lock')
    try: fd=os.open(p,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise ValueError('Registry busy or stale lock; inspect before retrying.')
    try: os.close(fd); yield
    finally: p.unlink(missing_ok=True)

def read(path):
    value=load(path); check_seal(value,'registry_hash'); require(value['schema_version']=='2.0','Unsupported registry.'); return value

def init(path): return write(path,sealed({'schema_version':'2.0','skills':[]},'registry_hash'))

def register(path,manifest_path):
    manifest_path=Path(manifest_path).resolve(); incoming=load(manifest_path)
    validate(incoming,schema('skill-manifest'))
    for side in ['input_schema','output_schema']:
        import jsonschema
        jsonschema.Draft202012Validator.check_schema(incoming[side])
    with lock(path):
        value=read(path); require(not any(m['id']==incoming['id'] and m['version']==incoming['version'] for m in value['skills']),'Skill ID/version already registered; create a new version.')
        manifest=copy.deepcopy(incoming)
        manifest['availability']={'status':'pending_installation','observed_at':None,'evidence':[],'reason':'Registration is not installation or execution authorization.'}
        manifest['registration']={'declared_manifest_sha256':sha(manifest_path),'manifest_path':str(manifest_path),'registered_at':now(),'trust':'declared_unverified'}
        value['skills'].append(manifest); value.pop('registry_hash'); atomic_replace(path,sealed(value,'registry_hash'))
    return manifest

def get(value,identifier,version=None):
    rows=[m for m in value['skills'] if m['id']==identifier and (version is None or m['version']==version)]
    require(len(rows)==1,'Specify a unique registered Skill ID/version: '+identifier); return rows[0]

def identity(manifest):
    return digest({k:v for k,v in manifest.items() if k not in {'availability','registration'}})

def ready(manifest):
    if manifest['availability']['status']!='ready': return False
    if manifest['id'] not in BUILTINS: return False  # Host adapter intentionally not implemented.
    expected=builtin_manifest(manifest['id'])
    require(identity(manifest)==identity(expected),'Packaged builtin manifest changed.')
    require(manifest['registration']['trust']=='local_builtin_verified','Builtin has not been verified by this host.')
    evidence=manifest['availability']['evidence']; require(evidence,'Readiness evidence missing.')
    for row in evidence: check_ref(row)
    require(manifest['availability']['entrypoint_sha256']==sha(builtin_script(manifest['id'])),'Builtin code changed after activation.')
    return True

def activate_builtin(path,identifier,evidence_output):
    require(identifier in BUILTINS,'Third-party code remains pending_installation; use an actual host installer/sandbox.')
    with lock(path):
        value=read(path); m=get(value,identifier)
        require(identity(m)==identity(builtin_manifest(identifier)),'Cannot activate a substituted builtin declaration.')
        for dep in m['runtime']['dependencies']:
            require(importlib.util.find_spec(dep) is not None,'Missing dependency: '+dep)
        if identifier=='cellsight-detection-threshold-boxes':
            command=[sys.executable,'-B',str(builtin_script(identifier)),'probe','--implementation','threshold-boxes']
            run=subprocess.run(command,capture_output=True,text=True,encoding='utf-8',timeout=20)
            require(run.returncode==0,'Builtin probe failed: '+run.stderr); probe=__import__('json').loads(run.stdout)
        else: probe={'entrypoint':'fixed_builtin_dispatch','method':BUILTINS[identifier][1],'llm_provider_configured':False}
        evidence=write(evidence_output,{'observed_at':now(),'probe':probe,'scope':'local_callable_not_scientific_validation','code_sha256':sha(builtin_script(identifier))})
        m['availability']={'status':'ready','observed_at':now(),'evidence':[ref(evidence)],'entrypoint_sha256':sha(builtin_script(identifier))}
        m['registration']['trust']='local_builtin_verified'
        value.pop('registry_hash'); atomic_replace(path,sealed(value,'registry_hash'))
    return m

def query(value,kind,task,domain):
    rows=[]
    for m in value['skills']:
        if m['type']!=kind or task not in m['capabilities']['tasks']: continue
        if domain not in m['domain_scope']['domains'] and '*' not in m['domain_scope']['domains']: continue
        if ready(m): rows.append(m)
    return sorted(rows,key=lambda m:(m['id'],m['version']))

def import_execution_catalog(path,catalog_path):
    """Migrate capabilities without claiming any of the 71 implementations are installed."""
    old=load(catalog_path); added=[]
    for row in old['implementations']:
        target=Path(path).parent/'imported-manifests'/(row['skill_id']+'.json')
        manifest={
          'schema_version':'2.0','id':row['skill_id'],'version':old['library_version'],'type':'execution',
          'capabilities':{'tasks':row['tasks'],'methods':[row['id']],'modes':row['documented_modes']},
          'input_schema':{'type':'object','required':['inputs','task']},'output_schema':{'type':'object','required':['status','artifacts']},
          'domain_scope':{'domains':['*'],'limitations':[row.get('capability_notes','Domain applicability requires separate validation.')],'scientific_validation':'not_established'},
          'runtime':{'dependencies':row['dependencies'],'devices':['cpu','cuda','mps'],'requires_weights':row['requires_weights']},
          'availability':{'status':'unverified','observed_at':None,'evidence':[]},
          'entrypoint':{'kind':'host_skill','name':row['skill_id']},
          'permissions':{'network':False,'filesystem':'host_scoped','subprocess':False},
          'source':{'origin':'legacy_catalog','reference':str(Path(catalog_path).resolve()),'publisher':'CellSight','trusted':False},
        }
        # The builtin has an exact executable declaration of its own; do not shadow it.
        if row['skill_id'] in BUILTINS: continue
        write(target,manifest); register(path,target); added.append(manifest['id'])
    return {'imported':added,'status':'pending_installation','automatic_mounting':False}
