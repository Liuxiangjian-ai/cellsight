"""CLI for structured specifications and bounded Eval Skill generation."""
import argparse
import json
from pathlib import Path
import cs_meta as meta
from metric_core import load, write, require


def main():
    parser = argparse.ArgumentParser(description='CellSight Evaluation Meta-Skill 0.5.1; no automatic SciencePal installation or CV execution.')
    sub = parser.add_subparsers(dest='command', required=True)
    p = sub.add_parser('init-registry'); p.add_argument('--output', required=True)
    p = sub.add_parser('discover'); p.add_argument('--registry', required=True); p.add_argument('--kind', required=True, choices=['execution', 'evaluation']); p.add_argument('--task', required=True); p.add_argument('--domain', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('validate-spec'); p.add_argument('--spec', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('build-spec'); p.add_argument('--brief', required=True); p.add_argument('--registry', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('resolve'); p.add_argument('--spec', required=True); p.add_argument('--registry', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('freeze'); p.add_argument('--spec', required=True); p.add_argument('--registry', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('generate'); p.add_argument('--definition', required=True); p.add_argument('--skill-id', required=True); p.add_argument('--output', required=True); p.add_argument('--task', default='*'); p.add_argument('--domain', default='*')
    p = sub.add_parser('validate-skill'); p.add_argument('--skill', required=True); p.add_argument('--output', required=True); p.add_argument('--static-only', action='store_true')
    p = sub.add_parser('register'); p.add_argument('--skill', required=True); p.add_argument('--registry', required=True)
    p = sub.add_parser('activate-template'); p.add_argument('--skill-id', required=True); p.add_argument('--version'); p.add_argument('--registry', required=True)
    p = sub.add_parser('bind-plan'); p.add_argument('--spec', required=True); p.add_argument('--plan', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('evaluate'); p.add_argument('--spec', required=True); p.add_argument('--registry', required=True); p.add_argument('--input', required=True); p.add_argument('--private-labels'); p.add_argument('--output', required=True)
    p = sub.add_parser('feedback'); p.add_argument('--spec', required=True); p.add_argument('--report', required=True); p.add_argument('--output', required=True)
    p = sub.add_parser('attach-state'); p.add_argument('--project', required=True); p.add_argument('--spec', required=True)
    p = sub.add_parser('record-report'); p.add_argument('--project', required=True); p.add_argument('--report', required=True)
    p = sub.add_parser('reserve-revision'); p.add_argument('--project', required=True); p.add_argument('--report', required=True)
    p = sub.add_parser('state-status'); p.add_argument('--project', required=True)
    a = parser.parse_args()
    if hasattr(a, 'output'):
        require(not Path(a.output).exists(), 'Use a new output path; do not overwrite prior evidence')
    if a.command == 'init-registry':
        result = {'registry': str(meta.registry_init(a.output)), 'scope': 'local fixed handlers; not host Skills'}
    elif a.command == 'discover':
        result = meta.discover(a.registry, a.kind, a.task, a.domain); write(a.output, result)
    elif a.command == 'validate-spec':
        result = meta.validate_specification(load(a.spec)); write(a.output, result)
    elif a.command == 'build-spec':
        result = meta.build_spec(load(a.brief), a.registry); write(a.output, result)
    elif a.command in {'resolve', 'freeze'}:
        result = getattr(meta, a.command)(load(a.spec), a.registry); write(a.output, result)
    elif a.command == 'generate':
        result = meta.generate(a.skill_id, load(a.definition), a.output, a.task, a.domain)
    elif a.command == 'validate-skill':
        result = meta.validate_bundle(a.skill, not a.static_only); write(a.output, result)
    elif a.command == 'register':
        result = meta.register(a.registry, a.skill)
    elif a.command == 'activate-template':
        result = meta.activate_template(a.registry, a.skill_id, a.version)
    elif a.command == 'bind-plan':
        result = meta.bind_plan(a.spec, load(a.plan)); write(a.output, result)
    elif a.command == 'evaluate':
        result = meta.evaluate(a.spec, a.registry, a.input, a.output, a.private_labels)
    elif a.command == 'feedback':
        result = meta.feedback(load(a.report), load(a.spec)); write(a.output, result)
    else:
        import meta_state
        if a.command == 'attach-state': result = meta_state.attach(a.project, a.spec)
        elif a.command == 'record-report': result = meta_state.record(a.project, a.report)
        elif a.command == 'reserve-revision': result = meta_state.reserve_revision(a.project, a.report)
        else: result = meta_state.status(a.project)
    # Small result summary; detailed evidence is in the output file.
    print(json.dumps({k: v for k, v in result.items() if k not in {'items', 'requirements', 'manifest', 'entries'}}, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
