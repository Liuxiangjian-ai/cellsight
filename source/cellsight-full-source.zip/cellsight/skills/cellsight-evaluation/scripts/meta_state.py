"""Meta evaluation evidence in the existing project ledger; no replacement scheduler."""
from pathlib import Path
from metric_core import load, sha, require, check_seal
import cs_state
import cs_meta

LEDGER = cs_state.LEDGER


def attach(project, spec_path):
    project, spec_path = Path(project).resolve(), Path(spec_path).resolve()
    spec = cs_meta.check_spec(load(spec_path), True)
    with LEDGER.exclusive(project):
        _, state = LEDGER.read_state(project)
        require(state['phase'] != 'cancelled', 'Project is stopped')
        require(state['plan'] is None, 'Do not reinterpret a legacy active plan as a Meta plan')
        require(state['experiment_id'] == spec['task_id'] and state['dataset_version'] == spec['dataset_version']
                and state['goal'] == spec['goal'], 'Project/Specification identity mismatch')
        require(not state.get('meta_evaluation'), 'Meta specification already attached; explicit new project/version required')
        require(spec['budget']['wall_time_seconds'] <= state['budget']['wall_time_seconds']-state['spent_seconds'], 'Insufficient recorded budget')
        state['meta_evaluation'] = {'spec_ref': {'path': str(spec_path), 'sha256': sha(spec_path)},
                                    'spec_hash': spec['spec_hash'], 'reports': [], 'revisions': 0,
                                    'max_replans': min(state['max_revisions'], spec['failure_policy']['max_replans'])}
        return LEDGER.commit(project, state, 'attach_meta_specification', {'spec_hash': spec['spec_hash']})


def checked(state):
    meta = state.get('meta_evaluation')
    require(meta is not None, 'No Meta specification attached')
    ref = meta['spec_ref']
    require(sha(ref['path']) == ref['sha256'], 'Attached Specification changed')
    spec = cs_meta.check_spec(load(ref['path']), True)
    require(spec['spec_hash'] == meta['spec_hash'], 'Specification binding mismatch')
    for row in meta['reports']:
        require(sha(row['path']) == row['sha256'], 'Recorded report changed')
        report = load(row['path'])
        check_seal(report, 'report_hash')
        require(sha(report['input_ref']['path']) == report['input_ref']['sha256'], 'Evaluated input changed')
        for evidence in report['evidence']:
            if evidence.get('path'):
                require(sha(evidence['path']) == evidence['sha256'], 'Recorded evidence changed')
    return meta, spec


def record(project, report_path):
    project, report_path = Path(project).resolve(), Path(report_path).resolve()
    report = load(report_path)
    cs_meta.validate(report, cs_meta.REPORT)
    check_seal(report, 'report_hash')
    with LEDGER.exclusive(project):
        _, state = LEDGER.read_state(project)
        require(state['phase'] != 'cancelled', 'Project is stopped')
        meta, spec = checked(state)
        require(report['spec_hash'] == spec['spec_hash'] and report['task_id'] == spec['task_id']
                and report['dataset_version'] == spec['dataset_version'], 'Stale/cross-task report')
        cs_meta.check_report(report, spec)
        require(report['source_type'] != 'external_benchmark', 'Final-test reports stay outside the operational ledger/replanner')
        if any(r['sha256'] == sha(report_path) for r in meta['reports']):
            return state  # Resume without duplicate accounting.
        require(sha(report['input_ref']['path']) == report['input_ref']['sha256'], 'Input evidence changed')
        for evidence in report['evidence']:
            if evidence.get('path'):
                require(sha(evidence['path']) == evidence['sha256'], 'Output evidence changed')
        meta['reports'].append({'path': str(report_path), 'sha256': sha(report_path), 'status': report['status'],
                                'report_hash': report['report_hash']})
        state['spent_seconds'] += report['wall_time_seconds']
        return LEDGER.commit(project, state, 'record_meta_evaluation', {'report_hash': report['report_hash'], 'status': report['status']})


def reserve_revision(project, report_path):
    project = Path(project).resolve()
    with LEDGER.exclusive(project):
        _, state = LEDGER.read_state(project)
        require(state['phase'] != 'cancelled', 'Project is stopped')
        meta, spec = checked(state)
        report = load(report_path)
        feedback = cs_meta.feedback(report, spec)
        require(report['status'] == 'FAIL' and feedback['recommendation']['action'] in {'REVISE', 'REPLAN'}, 'No repair is authorized by the report')
        require(any(r['sha256'] == sha(report_path) for r in meta['reports']), 'Record actual report before repair')
        require(meta['revisions'] < meta['max_replans'], 'Revision limit reached')
        require(state['budget']['wall_time_seconds']-state['spent_seconds'] > spec['budget']['evaluation_reserve_seconds'], 'Insufficient remaining recorded budget')
        used = meta.setdefault('used_revision_reports', [])
        require(report['report_hash'] not in used, 'Revision already reserved for this report')
        used.append(report['report_hash'])
        meta['revisions'] += 1
        return LEDGER.commit(project, state, 'reserve_meta_revision', {'report_hash': report['report_hash'], 'revision': meta['revisions']})


def status(project):
    _, state = LEDGER.read_state(project)
    meta, spec = checked(state)
    action = 'AWAIT_HOST_EXECUTION_OR_EVALUATION'
    if meta['reports']:
        report = load(meta['reports'][-1]['path'])
        action = report['recommendation']['action']
        if action in {'REVISE', 'REPLAN'} and meta['revisions'] >= meta['max_replans']:
            action = 'ESCALATE'
    if state['spent_seconds'] >= state['budget']['wall_time_seconds']:
        action = 'BUDGET_EXHAUSTED'
    if state['phase'] == 'cancelled':
        action = 'STOPPED'
    return {'task_id': spec['task_id'], 'spec_hash': spec['spec_hash'], 'next_action': action,
            'spent_seconds': state['spent_seconds'], 'revisions': meta['revisions'],
            'max_replans': meta['max_replans'], 'reports': meta['reports'],
            'automatic_cv_execution': False, 'scheduler_scope': 'existing ledger with host-driven Meta workflow'}
