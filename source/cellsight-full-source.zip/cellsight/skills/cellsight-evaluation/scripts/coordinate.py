"""CellSight project coordination ledger. Records handoffs; does not invoke skills or certify science."""
from __future__ import annotations
import argparse
from contextlib import contextmanager
import copy
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location("cellsight_plan_core",ROOT/"scripts/plan.py")
CORE=importlib.util.module_from_spec(spec); spec.loader.exec_module(CORE)
VERSION="0.3.0"
STAGES={"preflight","stage","final"}
PUBLIC_IDS={p["id"] for p in CORE.PUBLIC_CHECKS}


def require(ok,message):
    if not ok: raise ValueError(message)


def load(path): return CORE.load(path)
def digest(data): return CORE.digest(data)
def file_hash(path): return CORE.file_hash(path)
def resolve(path,base): return CORE.resolve(path,base)
def now(): return datetime.now(timezone.utc).isoformat()


def nonnegative(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>=0


def checked_file(path,base):
    p=resolve(path,base); require(p.is_file(),"Evidence or artifact file missing: "+str(p)); return p


@contextmanager
def exclusive(project):
    lock=project/".writer.lock"
    try: fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY)
    except FileExistsError: raise ValueError("Project ledger has an active/stale writer lock. Inspect it before retrying; do not silently overwrite.")
    try:
        os.write(fd,str(os.getpid()).encode()); os.close(fd); yield
    finally:
        lock.unlink(missing_ok=True)


def read_state(project):
    p=Path(project).resolve(); state=load(p/"project.json")
    expected=state.get("state_hash"); unhashed=dict(state); unhashed.pop("state_hash",None)
    require(digest(unhashed)==expected,"Project snapshot was edited outside the ledger.")
    event=p/"events"/(f"{state['sequence']:06d}.json")
    require(event.is_file() and load(event).get("state_hash")==expected,"Project snapshot/event mismatch; inspect the ledger before resuming.")
    require(file_hash(p/"mission.snapshot.json")==state["mission_sha256"],"Mission snapshot changed outside explicit coordination.")
    return p,state


def commit(project,state,action,details):
    previous=state.get("state_hash")
    state=copy.deepcopy(state); state.pop("state_hash",None)
    state["sequence"]=state.get("sequence",-1)+1; state["updated_at_utc"]=now()
    state["previous_state_hash"]=previous; state["last_action"]=action
    state["state_hash"]=digest(state)
    event={"schema_version":"1.0","sequence":state["sequence"],"action":action,"details":details,"previous_state_hash":previous,"state_hash":state["state_hash"],"snapshot":state}
    CORE.write(project/"events"/(f"{state['sequence']:06d}.json"),event)
    tmp=project/"project.next.json"; CORE.write(tmp,state); os.replace(tmp,project/"project.json")
    return state


def start(brief_path,project):
    brief_path=Path(brief_path).resolve(); brief=load(brief_path)
    require(brief.get("schema_version")=="1.0","Unsupported mission schema.")
    for key in ["experiment_id","dataset_version","goal"]: require(isinstance(brief.get(key),str) and brief[key].strip(),"Mission requires "+key)
    require(CORE.positive(brief.get("budget",{}).get("wall_time_seconds")),"Positive global budget required.")
    if "device" in brief["budget"]: require(brief["budget"]["device"] in {"cpu","cuda","mps"},"Unsupported mission device.")
    limits=brief.get("limits",{}); revisions=limits.get("max_revisions",2)
    require(type(revisions) is int and 0<=revisions<=10,"max_revisions must be an integer in [0,10].")
    required=brief.get("required_eval_stages",["preflight","stage","final"])
    require(isinstance(required,list) and set(required)<=STAGES and {"preflight","final"}<=set(required),"Preflight and final evaluation are mandatory; stage evaluation can be declared explicitly.")
    project=Path(project).resolve(); require(not project.exists(),"Use a new project directory.")
    project.mkdir(parents=True); (project/"events").mkdir()
    CORE.write(project/"mission.snapshot.json",brief)
    state={"schema_version":"1.0","coordinator_version":VERSION,"experiment_id":brief["experiment_id"],"dataset_version":brief["dataset_version"],"goal":brief["goal"],
           "mission_sha256":file_hash(project/"mission.snapshot.json"),"budget":brief["budget"],"spent_seconds":0.,"budget_scope":"recorded_execution_evaluation_and_explicit_costs_not_hard_timeout",
           "max_revisions":revisions,"revision":0,"required_eval_stages":required,"phase":"planning","plan":None,
           "eval_skills":{},"eval_bindings":{},"results":{},"evaluations":{},"delivery":None,"history":[],"sequence":-1,
           "evidence_recording_only":True,"independent_agents_created":False}
    return commit(project,state,"start",{"mission_sha256":state["mission_sha256"]})


def inspect_plan(state):
    require(state["plan"] is not None,"No active plan attached.")
    directory,plan,contract=CORE.read_plan(state["plan"]["directory"])
    require(plan["plan_hash"]==state["plan"]["plan_hash"],"Attached plan changed; revise explicitly.")
    ap=directory/"agreement.json"; cp=directory/"eval-contract.agreed.json"
    if not ap.is_file() or not cp.is_file(): return directory,plan,contract,None
    agreement=load(ap)
    require(agreement.get("status")=="agreed" and agreement.get("plan_hash")==plan["plan_hash"],"Agreement does not bind active plan.")
    require(file_hash(cp)==agreement.get("agreed_contract_sha256"),"Agreed contract changed.")
    if state["plan"].get("agreed_contract_sha256"):
        require(file_hash(cp)==state["plan"]["agreed_contract_sha256"],"Contract differs from the recorded coordination context.")
    agreed=load(cp)
    require(agreed.get("status")=="agreed","Contract is not agreed.")
    require(set(agreement.get("roles",{}))=={"planner","executor","evaluator"},"Agreement is missing role reviews.")
    for row in agreement["roles"].values():
        p=Path(row["path"]); require(p.is_file() and file_hash(p)==row["sha256"],"Role review changed after agreement.")
    for row in agreed.get("ground_truth_refs",[])+agreed.get("review_evidence",[]):
        p=Path(row["path"]); require(p.is_file() and file_hash(p)==row["sha256"],"Plan review evidence or ground truth changed.")
    return directory,plan,agreed,agreement


def bind_plan_to_state(state,directory):
    directory,plan,_=CORE.read_plan(directory)
    require(plan["experiment_id"]==state["experiment_id"] and plan["dataset_version"]==state["dataset_version"],"Plan experiment/dataset differs from mission.")
    require(plan["budget"]["wall_time_seconds"]<=state["budget"]["wall_time_seconds"]-state["spent_seconds"],"Plan exceeds remaining recorded global budget.")
    if state["budget"].get("device"): require(plan["budget"]["device"]==state["budget"]["device"],"Plan device differs from mission resource boundary.")
    registry=load(ROOT/"assets/execution-registry.json")
    peers={r["skill_id"] for r in registry["skills"]}
    for step in plan["steps"]:
        if step["skill_id"] is not None: require(step["skill_id"] in peers,"Plan targets an expert outside the current registry; update the planner registry explicitly.")
    state["plan"]={"directory":str(directory),"plan_hash":plan["plan_hash"],"goal":plan["goal"],"agreed_contract_sha256":None}
    state["phase"]="negotiating"
    return plan


def evaluation_key(stage,step=None): return "stage:"+step if stage=="stage" else stage


def context_hash(state): return digest({k:r["sha256"] for k,r in sorted(state["results"].items())})


def eval_problem(state,key):
    row=state["evaluations"].get(key)
    if not row: return None
    return None if row["status"]=="pass" else row["status"]


def evaluation_ready(state,key): return state["evaluations"].get(key,{}).get("status")=="pass"


def verify_recorded_evidence(state):
    for row in state["results"].values():
        p=Path(row["path"]); require(p.is_file() and file_hash(p)==row["sha256"],"Recorded execution result changed.")
        payload=load(p)
        if row["status"]=="succeeded":
            for a in payload["artifacts"]:
                q=checked_file(a["path"],p.parent); require(file_hash(q)==a["sha256"],"Recorded execution artifact changed.")
    for row in state["evaluations"].values():
        p=Path(row["path"]); require(p.is_file() and file_hash(p)==row["sha256"],"Recorded evaluation report changed.")
        for e in row["evidence"]:
            q=Path(e["path"]); require(q.is_file() and file_hash(q)==e["sha256"],"Recorded evaluation evidence changed.")
    for sid in set(state["eval_bindings"].values()): validate_eval_source(state,sid)
    if state["delivery"]:
        d=state["delivery"]; p=Path(d["manifest_path"])
        require(p.is_file() and file_hash(p)==d["manifest_sha256"],"Delivery manifest changed.")
        for row in d["files"]:
            q=Path(row["path"]); require(q.is_file() and file_hash(q)==row["sha256"],"Delivered artifact changed.")


def next_action(state):
    if state["phase"]=="cancelled": return {"action":"stopped","reason":state.get("stop_reason")}
    if state["spent_seconds"]>=state["budget"]["wall_time_seconds"]: return {"action":"budget_exhausted","remaining_seconds":0}
    if not state["plan"]: return {"action":"formulate_plan","coordinator_skill":"cellsight-planner","needs":["goal_and_data_roles","actual_expert_availability","evaluation_requirements","budget"]}
    verify_recorded_evidence(state)
    directory,plan,contract,agreement=inspect_plan(state)
    if agreement is None or plan["open_issues"]:
        return {"action":"coordinate_reviews","plan_hash":plan["plan_hash"],"open_issues":plan["open_issues"],"required_roles":["planner","executor","evaluator"],"note":"Gather actual feasibility and rubric evidence; do not invent independent reviewers or acceptance."}
    missing=[s for s in state["required_eval_stages"] if s not in state["eval_bindings"]]
    if missing: return {"action":"register_and_bind_evaluation_skills","missing_stages":missing,"execution_allowed":False}
    if state["delivery"]: return {"action":"completed","delivery":state["delivery"]}
    for key,row in state["evaluations"].items():
        if row["status"]!="pass":
            return {"action":"resolve_evaluation","evaluation":key,"status":row["status"],"revision":state["revision"],"max_revisions":state["max_revisions"],"execution_allowed":False}
    if not evaluation_ready(state,"preflight"):
        return {"action":"evaluate","stage":"preflight","target_skill":state["eval_bindings"]["preflight"],"plan_hash":plan["plan_hash"],"execution_allowed":False}
    for step in plan["steps"]:
        sid=step["step_id"]
        result=state["results"].get(sid)
        if result:
            if result["status"]!="succeeded":
                return {"action":"diagnose_execution","step_id":sid,"status":result["status"],"affected":CORE.affected(directory,[sid]),"execution_allowed":False}
            if "stage" in state["required_eval_stages"] and not evaluation_ready(state,"stage:"+sid):
                return {"action":"evaluate","stage":"stage","step_id":sid,"target_skill":state["eval_bindings"]["stage"],"result_ref":result["path"],"result_sha256":result["sha256"]}
            continue
        dependencies=step["depends_on"]
        require(all(d in state["results"] and state["results"][d]["status"]=="succeeded" for d in dependencies),"Dependency ledger is incomplete.")
        if "stage" in state["required_eval_stages"]:
            require(all(evaluation_ready(state,"stage:"+d) for d in dependencies),"Dependency stage evaluation is incomplete.")
        return {"action":"execute","step_id":sid,"target_skill":step["skill_id"],"implementation_id":step["proposed_implementation_id"],"mode":step["mode"],
                "plan_dir":str(directory),"upstream_results":{d:state["results"][d]["path"] for d in dependencies},
                "allocated_seconds":step["wall_time_seconds"],"remaining_global_seconds":state["budget"]["wall_time_seconds"]-state["spent_seconds"],
                "note":"Use plan.py materialize, then load the named peer expert through the host. No skill has been invoked by this action."}
    if not evaluation_ready(state,"final"):
        return {"action":"evaluate","stage":"final","target_skill":state["eval_bindings"]["final"],"evaluation_scope":contract["evaluation_scope"],"results_hash":context_hash(state),"result_refs":{k:v["path"] for k,v in state["results"].items()}}
    return {"action":"assemble_delivery","required":["user_goal_answer","artifacts_and_hashes","methods_and_versions","evaluation_scope_and_limitations","recorded_costs"]}


def attach(project,plan_dir):
    project,state=read_state(project)
    with exclusive(project):
        require(not state["results"] and not state["evaluations"],"Use revise once execution/evaluation evidence exists.")
        if state["plan"]: require(CORE.read_plan(plan_dir)[1]["plan_hash"]==state["plan"]["plan_hash"],"Different draft requires explicit revision.")
        plan=bind_plan_to_state(state,plan_dir)
        return commit(project,state,"attach_plan",{"plan_hash":plan["plan_hash"]})


def register_eval(project,descriptor_path):
    project,state=read_state(project); source=Path(descriptor_path).resolve(); d=load(source)
    require(d.get("schema_version")=="1.0","Unsupported Eval descriptor.")
    require(isinstance(d.get("skill_id"),str) and d["skill_id"].startswith("cellsight-"),"Explicit Eval skill name required.")
    require(isinstance(d.get("rubric_version"),str) and d["rubric_version"],"rubric_version required.")
    require(d.get("available") is True,"Eval availability must have been actually observed, not assumed.")
    require(isinstance(d.get("stages"),list) and d["stages"] and set(d["stages"])<=STAGES,"Supported stages required.")
    require(isinstance(d.get("tasks"),list) and d["tasks"],"Explicit task scope required.")
    require(isinstance(d.get("evaluation_scopes"),list) and d["evaluation_scopes"] and set(d["evaluation_scopes"])<={"integrity_only","supervised_outcomes"},"Explicit evaluation_scopes required.")
    require(d.get("observed_at"),"Availability observation time required.")
    refs=[]
    for value in d.get("evidence_refs",[]):
        path=checked_file(value,source.parent); refs.append({"path":str(path),"sha256":file_hash(path)})
    require(refs,"Actual capability/availability evidence references required.")
    with exclusive(project):
        sid=d["skill_id"]; require(sid not in state["eval_skills"],"Eval skill already registered; do not silently replace its rubric/version.")
        state["eval_skills"][sid]={"descriptor":d,"descriptor_path":str(source),"descriptor_sha256":file_hash(source),"evidence":refs}
        return commit(project,state,"register_eval",{"skill_id":sid,"rubric_version":d["rubric_version"]})


def bind_evals(project,path):
    project,state=read_state(project); source=Path(path).resolve(); bindings=load(source)
    _,plan,contract,agreement=inspect_plan(state); require(agreement is not None,"Agree plan before binding evaluators.")
    require(not state["results"] and not state["evaluations"],"Evaluation bindings freeze before the first evaluation/execution; revise to change them.")
    require(isinstance(bindings,dict) and set(bindings)==set(state["required_eval_stages"]),"Bindings must cover exactly the declared evaluation stages.")
    tasks={s["task"] for s in plan["steps"]}
    for stage,sid in bindings.items():
        require(sid in state["eval_skills"],"Eval skill is not registered.")
        d=state["eval_skills"][sid]["descriptor"]
        require(stage in d["stages"] and tasks<=set(d["tasks"]),"Eval skill does not cover required stages/tasks.")
        expected_scope=contract["evaluation_scope"] if stage=="final" else "integrity_only"
        require(expected_scope in d["evaluation_scopes"],"Eval skill cannot support the required evaluation scope.")
    with exclusive(project):
        state["eval_bindings"]=bindings; state["plan"]["agreed_contract_sha256"]=file_hash(Path(state["plan"]["directory"])/"eval-contract.agreed.json")
        state["phase"]="preflight_pending"
        return commit(project,state,"bind_evals",{"bindings":bindings,"source_sha256":file_hash(source)})


def validate_eval_source(state,skill_id):
    item=state["eval_skills"][skill_id]
    p=Path(item["descriptor_path"]); require(p.is_file() and file_hash(p)==item["descriptor_sha256"],"Eval descriptor changed after registration.")
    for ref in item["evidence"]:
        p=Path(ref["path"]); require(p.is_file() and file_hash(p)==ref["sha256"],"Eval availability/capability evidence changed.")
    return item["descriptor"]


def record_eval(project,report_path):
    project,state=read_state(project); path=Path(report_path).resolve(); report=load(path); sha=file_hash(path)
    stage=report.get("stage"); step=report.get("step_id"); require(stage in STAGES,"Unknown evaluation stage.")
    require(stage!="stage" or isinstance(step,str) and step,"stage evaluation needs step_id.")
    key=evaluation_key(stage,step)
    if key in state["evaluations"]:
        require(state["evaluations"][key]["sha256"]==sha,"Evaluation already recorded; use a new plan revision, not replacement grading.")
        return state
    action=next_action(state)
    require(action.get("action")=="evaluate" and action["stage"]==stage and action.get("step_id")==step,"Evaluation is out of order or targets a different step.")
    _,plan,contract,_=inspect_plan(state)
    require(report.get("schema_version")=="1.0" and report.get("experiment_id")==state["experiment_id"] and report.get("dataset_version")==state["dataset_version"],"Eval report scope mismatch.")
    require(report.get("plan_hash")==plan["plan_hash"] and report.get("eval_contract_sha256")==state["plan"]["agreed_contract_sha256"],"Eval report uses different plan/contract.")
    sid=state["eval_bindings"][stage]; d=validate_eval_source(state,sid)
    require(report.get("rubric_skill_id")==sid and report.get("rubric_version")==d["rubric_version"],"Eval report rubric differs from frozen binding.")
    expected_scope=contract["evaluation_scope"] if stage=="final" else "integrity_only"
    require(report.get("evaluation_scope")==expected_scope,"Eval report silently changed evaluation scope.")
    status=report.get("status"); require(status in {"pass","fail","needs_review","not_evaluable","error"},"Unknown evaluation status.")
    require(nonnegative(report.get("wall_time_seconds")),"Actual evaluation duration required.")
    if stage=="stage": require(report.get("evaluated_result_sha256")==state["results"][step]["sha256"],"Eval report evaluated a different result.")
    if stage=="final": require(report.get("evaluated_results_hash")==context_hash(state),"Final evaluation refers to a different result set.")
    checks=report.get("public_checks",{})
    require(isinstance(checks,dict) and PUBLIC_IDS<=set(checks),"Eval report omitted mandatory public checks.")
    require(all(v in {"pass","fail","needs_review","not_applicable"} for v in checks.values()),"Unknown public-check status.")
    for name,value in checks.items():
        if value=="not_applicable": require(report.get("not_applicable_reasons",{}).get(name),"Explicit reason needed for each not_applicable public check.")
    if status=="pass": require(all(v in {"pass","not_applicable"} for v in checks.values()),"A failed/unresolved public check cannot be offset by a passing score.")
    refs=[]
    for value in report.get("evidence_refs",[]):
        evidence=checked_file(value,path.parent); refs.append({"path":str(evidence),"sha256":file_hash(evidence)})
    require(refs,"Evaluation needs real evidence files.")
    with exclusive(project):
        state["evaluations"][key]={"path":str(path),"sha256":sha,"status":status,"evidence":refs,"rubric_skill_id":sid,"rubric_version":d["rubric_version"]}
        state["spent_seconds"]+=report["wall_time_seconds"]
        state["phase"]="needs_revision" if status!="pass" else ("executing" if stage!="final" else "delivery_pending")
        return commit(project,state,"record_evaluation",{"stage":stage,"step_id":step,"status":status,"report_sha256":sha})


def record_result(project,step_id,result_path):
    project,state=read_state(project); path=Path(result_path).resolve(); result=load(path); sha=file_hash(path)
    if step_id in state["results"]:
        require(state["results"][step_id]["sha256"]==sha,"Result already recorded; use explicit revision for a different execution.")
        return state
    action=next_action(state)
    require(action.get("action")=="execute" and action["step_id"]==step_id,"Execution result is out of order or preflight/dependency gates are incomplete.")
    _,plan,_,_=inspect_plan(state); step=next(s for s in plan["steps"] if s["step_id"]==step_id)
    require(result.get("schema_version")=="1.0" and result.get("experiment_id")==state["experiment_id"] and result.get("dataset_version")==state["dataset_version"],"Execution result scope mismatch.")
    require(result.get("request_id")==state["experiment_id"]+"-"+step_id and result.get("implementation_id")==step["proposed_implementation_id"] and result.get("task")==step["task"] and result.get("mode")==step["mode"],"Execution result does not bind the planned step.")
    require(result.get("eval_contract_sha256")==state["plan"]["agreed_contract_sha256"],"Execution used another contract.")
    require(result.get("status") in {"succeeded","blocked","failed","budget_exhausted","cancelled"},"Only terminal execution results are recorded here; poll existing jobs instead of resubmitting.")
    require(nonnegative(result.get("wall_time_seconds")),"Actual execution duration required.")
    if result["status"]=="succeeded":
        require(isinstance(result.get("artifacts"),list) and result["artifacts"],"Successful execution requires artifacts.")
        for row in result["artifacts"]:
            p=checked_file(row["path"],path.parent); require(file_hash(p)==row.get("sha256"),"Execution artifact hash mismatch.")
    with exclusive(project):
        effective_status="budget_exhausted" if result["status"]=="succeeded" and result["wall_time_seconds"]>step["wall_time_seconds"] else result["status"]
        state["results"][step_id]={"path":str(path),"sha256":sha,"status":effective_status,"source_status":result["status"],"wall_time_seconds":result["wall_time_seconds"]}
        state["spent_seconds"]+=result["wall_time_seconds"]
        state["phase"]="evaluation_pending" if effective_status=="succeeded" else "needs_revision"
        return commit(project,state,"record_result",{"step_id":step_id,"status":result["status"],"result_sha256":sha})


def record_cost(project,seconds,reason):
    require(nonnegative(seconds) and reason,"Nonnegative actual cost and reason required.")
    project,state=read_state(project)
    with exclusive(project):
        state["spent_seconds"]+=seconds
        return commit(project,state,"record_cost",{"seconds":seconds,"reason":reason})


def revise(project,new_plan_dir,reason,changed,dataset_changed=False):
    project,state=read_state(project)
    require(reason,"Revision reason required.")
    require(state["revision"]<state["max_revisions"],"Revision limit reached; present the unresolved tradeoff to the user.")
    require(state["spent_seconds"]<state["budget"]["wall_time_seconds"],"Recorded budget exhausted; do not launch another plan without an explicit user budget decision.")
    require(state["plan"] is not None,"Attach the initial plan first.")
    old=copy.deepcopy(state["plan"])
    scope=CORE.affected(old["directory"],changed,dataset_changed)
    require(changed or dataset_changed,"Specify changed steps or dataset_changed.")
    if dataset_changed:
        next_plan=CORE.read_plan(new_plan_dir)[1]
        require(next_plan["experiment_id"]==state["experiment_id"],"Revision changed the experiment identity.")
        state["dataset_version"]=next_plan["dataset_version"]
    with exclusive(project):
        plan=bind_plan_to_state(state,new_plan_dir)
        require(plan["plan_hash"]!=old["plan_hash"],"Revision must use a distinct immutable plan.")
        state["history"].append({"plan":old,"results":state["results"],"evaluations":state["evaluations"],"reason":reason,"reuse_proposal":scope})
        state["results"]={}; state["evaluations"]={}; state["eval_bindings"]={}; state["delivery"]=None
        state["revision"]+=1
        return commit(project,state,"revise",{"reason":reason,"new_plan_hash":plan["plan_hash"],"reuse_proposal":scope,"note":"Old results retain old contract hashes. Reuse immutable artifacts as explicit inputs to the new plan; do not relabel them as new executions."})


def deliver(project,manifest_path):
    project,state=read_state(project); require(next_action(state).get("action")=="assemble_delivery","All required execution/evaluation gates must pass before delivery.")
    path=Path(manifest_path).resolve(); manifest=load(path)
    require(manifest.get("experiment_id")==state["experiment_id"] and manifest.get("dataset_version")==state["dataset_version"],"Delivery identity mismatch.")
    require(manifest.get("plan_hash")==state["plan"]["plan_hash"] and manifest.get("evaluated_results_hash")==context_hash(state),"Delivery references an outdated plan/result set.")
    refs=[]
    report=checked_file(manifest.get("report_ref"),path.parent); refs.append({"path":str(report),"sha256":file_hash(report)})
    for value in manifest.get("artifact_refs",[]):
        p=checked_file(value,path.parent); refs.append({"path":str(p),"sha256":file_hash(p)})
    require(len(refs)>1,"Delivery requires a report and actual artifacts.")
    with exclusive(project):
        state["delivery"]={"manifest_path":str(path),"manifest_sha256":file_hash(path),"files":refs,"scope":"subject_to_recorded_eval_scope_and_limitations"}
        state["phase"]="completed"
        return commit(project,state,"deliver",{"manifest_sha256":file_hash(path)})


def stop(project,reason):
    require(reason,"Explicit stop reason required.")
    project,state=read_state(project)
    with exclusive(project):
        state["phase"]="cancelled"; state["stop_reason"]=reason
        return commit(project,state,"stop",{"reason":reason,"note":"No external running job has been cancelled by this ledger; use its native cancellation interface if applicable."})


def status(project):
    _,state=read_state(project)
    return {"experiment_id":state["experiment_id"],"dataset_version":state["dataset_version"],"goal":state["goal"],"phase":state["phase"],"revision":state["revision"],
            "spent_seconds":state["spent_seconds"],"remaining_recorded_seconds":max(0,state["budget"]["wall_time_seconds"]-state["spent_seconds"]),
            "registered_eval_skills":list(state["eval_skills"]),"results":{k:v["status"] for k,v in state["results"].items()},"evaluations":{k:v["status"] for k,v in state["evaluations"].items()},"next":next_action(state),"evidence_recording_only":True}


def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="command",required=True)
    q=sub.add_parser("start"); q.add_argument("--brief",required=True); q.add_argument("--output",required=True)
    q=sub.add_parser("attach-plan"); q.add_argument("--project",required=True); q.add_argument("--plan-dir",required=True)
    q=sub.add_parser("register-eval"); q.add_argument("--project",required=True); q.add_argument("--descriptor",required=True)
    q=sub.add_parser("bind-evals"); q.add_argument("--project",required=True); q.add_argument("--bindings",required=True)
    q=sub.add_parser("record-result"); q.add_argument("--project",required=True); q.add_argument("--step",required=True); q.add_argument("--result",required=True)
    q=sub.add_parser("record-eval"); q.add_argument("--project",required=True); q.add_argument("--report",required=True)
    q=sub.add_parser("record-cost"); q.add_argument("--project",required=True); q.add_argument("--seconds",required=True,type=float); q.add_argument("--reason",required=True)
    q=sub.add_parser("revise"); q.add_argument("--project",required=True); q.add_argument("--plan-dir",required=True); q.add_argument("--reason",required=True); q.add_argument("--changed",action="append",default=[]); q.add_argument("--dataset-changed",action="store_true")
    q=sub.add_parser("deliver"); q.add_argument("--project",required=True); q.add_argument("--manifest",required=True)
    q=sub.add_parser("stop"); q.add_argument("--project",required=True); q.add_argument("--reason",required=True)
    q=sub.add_parser("status"); q.add_argument("--project",required=True)
    q=sub.add_parser("next"); q.add_argument("--project",required=True)
    args=p.parse_args()
    try:
        if args.command=="start": value=start(args.brief,args.output)
        elif args.command=="attach-plan": value=attach(args.project,args.plan_dir)
        elif args.command=="register-eval": value=register_eval(args.project,args.descriptor)
        elif args.command=="bind-evals": value=bind_evals(args.project,args.bindings)
        elif args.command=="record-result": value=record_result(args.project,args.step,args.result)
        elif args.command=="record-eval": value=record_eval(args.project,args.report)
        elif args.command=="record-cost": value=record_cost(args.project,args.seconds,args.reason)
        elif args.command=="revise": value=revise(args.project,args.plan_dir,args.reason,args.changed,args.dataset_changed)
        elif args.command=="deliver": value=deliver(args.project,args.manifest)
        elif args.command=="stop": value=stop(args.project,args.reason)
        elif args.command=="status": value=status(args.project)
        else: value=next_action(read_state(args.project)[1])
        print(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)); return 0
    except Exception as exc:
        print(json.dumps({"status":"blocked","skills_invoked":False,"error":{"type":type(exc).__name__,"message":str(exc)}},ensure_ascii=False),file=sys.stderr); return 2


if __name__=="__main__": raise SystemExit(main())
