"""CellSight Planner: draft, negotiate, and materialize CV requests, without executing models."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
VERSION="0.3.0"
IO={
 "detect":({"image"},{"detections"}),
 "instance_segment":({"image"},{"instance_masks"}),
 "semantic_segment":({"image"},{"semantic_masks"}),
 "prompt_segment":({"image"},{"prompt_masks"}),
 "classify":({"image"},{"classifications"}),
 "track":({"detections"},{"tracks"}),
 "process":({"image"},{"image"}),
 "register":({"image"},{"image","transform"}),
 "restore":({"image"},{"image"}),
 "image_text_match":({"image"},{"similarities"}),
 "embedding":({"image"},{"embeddings"}),
 "describe":({"image"},{"claims"}),
 "morphology":({"instance_masks"},{"measurements","table"}),
 "fluorescence":({"image","instance_masks"},{"measurements","table"}),
 "spatial_statistics":({"instance_masks"},{"measurements","table"}),
 "anomaly_detect":({"image"},{"anomaly_map","scores"}),
 "pose":({"image"},{"keypoints","detections"}),
 "ocr":({"image"},{"text_regions"}),
 "depth":({"image"},{"depth_map"})
}
PUBLIC_CHECKS=[
 {"id":"data-provenance","scope":"data","required_evidence":["dataset_version","input_hashes","sample_roles_and_annotation_provenance"]},
 {"id":"artifact-integrity","scope":"process","required_evidence":["effective_request","environment_versions","output_artifacts_and_hashes"]},
 {"id":"spatial-and-unit-integrity","scope":"process","required_evidence":["axes_space_id_and_transforms","measurement_units_or_explicitly_unknown"]},
 {"id":"evaluation-boundaries","scope":"process","required_evidence":["evaluation_scope","ground_truth_status","validation_test_separation_if_applicable"]}
]


class Invalid(ValueError): pass


def require(condition,message):
    if not condition: raise Invalid(message)


def load(path):
    with Path(path).open(encoding="utf-8-sig") as f: return json.load(f)


def write(path,data):
    with Path(path).open("x",encoding="utf-8") as f:
        json.dump(data,f,ensure_ascii=False,indent=2,allow_nan=False); f.write("\n")


def digest(data):
    return hashlib.sha256(json.dumps(data,sort_keys=True,ensure_ascii=False,allow_nan=False).encode()).hexdigest()


def file_hash(path):
    h=hashlib.sha256()
    with Path(path).open("rb") as f:
        for b in iter(lambda:f.read(1024*1024),b""): h.update(b)
    return h.hexdigest()


def resolve(value,base):
    require(isinstance(value,str) and bool(value),"Nonempty local path required.")
    require(not value.startswith(("http://","https://","s3://")),"Resolve remote resources through the host before planning.")
    p=Path(value).expanduser()
    return (p if p.is_absolute() else Path(base)/p).resolve()


def positive(value):
    return isinstance(value,(int,float)) and not isinstance(value,bool) and math.isfinite(value) and value>0


def output_types(task,implementation):
    if task=="instance_segment" and implementation in {"yolo-seg","maskrcnn"}:
        return {"instance_mask_stack","detections"}
    if task=="pose" and implementation=="yolo-pose": return {"detections"}
    return IO[task][1]


def topological(steps):
    ids=[s.get("step_id") for s in steps]
    require(all(isinstance(i,str) and i and all(c.isalnum() or c in "-_" for c in i) for i in ids),"step_id must use letters/digits/hyphen/underscore.")
    require(len(set(ids))==len(ids),"Duplicate step_id.")
    pending={s["step_id"]:s for s in steps}; ordered=[]; done=set()
    while pending:
        ready=[s for s in pending.values() if set(s["depends_on"])<=done]
        require(ready,"Dependency cycle or unknown dependency.")
        for s in ready:
            ordered.append(s); done.add(s["step_id"]); pending.pop(s["step_id"])
    return ordered


def readiness(item,model,mode,base):
    if not item: return "unknown",["No current environment evidence."]
    required=["skill_available","dependencies_imported","device_compatible","smoke_test_passed"]
    if model["requires_weights"]: required.append("weights_available")
    if model.get("adapter") is None or mode not in model.get("adapter_modes",[]): required.append("native_workflow_ready")
    if any(item.get(k) is False for k in required): return "blocked",[k for k in required if item.get(k) is False]
    if not all(item.get(k) is True for k in required): return "unknown",[k for k in required if item.get(k) is not True]
    ref=item.get("smoke_test_ref")
    if not ref or not resolve(ref,base).is_file(): return "unknown",["smoke_test_ref does not resolve to evidence."]
    if not isinstance(item.get("observed_at"),str) or not item["observed_at"]: return "unknown",["observed_at missing."]
    return "ready",[]


def create(intent_path,outdir,registry_path=None,availability_path=None,normalization_only=False):
    intent_path=Path(intent_path).resolve(); base=intent_path.parent
    intent=load(intent_path)
    require(intent.get("schema_version")=="1.0","Unsupported intent schema_version.")
    for k in ["experiment_id","dataset_version","goal"]:
        require(isinstance(intent.get(k),str) and intent[k].strip(),f"Missing {k}.")
    budget=intent.get("budget",{})
    require(positive(budget.get("wall_time_seconds")),"Positive total wall-time budget required.")
    require(budget.get("device") in {"cpu","cuda","mps"},"Explicit device required.")
    max_rounds=intent.get("max_negotiation_rounds",2)
    require(type(max_rounds) is int and 1<=max_rounds<=5,"Negotiation rounds must be an integer in [1,5].")
    reserve=budget.get("evaluation_reserve_seconds",budget["wall_time_seconds"]*.2)
    require(isinstance(reserve,(int,float)) and not isinstance(reserve,bool) and 0<=reserve<budget["wall_time_seconds"],"Invalid evaluation reserve.")
    registry=load(registry_path or ROOT/"assets"/"execution-registry.json")
    require(registry.get("schema_version")=="1.0","Unsupported registry schema.")
    models=registry.get("implementations",[])
    require(len({m["id"] for m in models})==len(models),"Registry implementation IDs are not unique.")
    skill_ids={s["skill_id"] for s in registry["skills"]}
    category_skills={}
    for registered_skill in registry["skills"]:
        category_skills.setdefault(registered_skill["category"],[]).append(registered_skill["skill_id"])
    def expert_skill(model):
        explicit=model.get("skill_id")
        if explicit:
            require(explicit in skill_ids,"Implementation points to an unregistered expert skill.")
            return explicit
        legacy=category_skills.get(model["category"],[])
        require(len(legacy)==1,"Ambiguous category: each implementation must specify its own skill_id.")
        return legacy[0]
    availability=load(availability_path) if availability_path else {"schema_version":"1.0","implementations":[]}
    require(availability.get("schema_version")=="1.0","Unsupported availability schema.")
    facts={r["implementation_id"]:r for r in availability.get("implementations",[])}
    fact_base=Path(availability_path).resolve().parent if availability_path else base
    inputs=intent.get("inputs")
    require(isinstance(inputs,list) and inputs,"At least one declared input required.")
    named={}; issues=[]
    for row in inputs:
        row=dict(row); iid=row.get("artifact_id")
        require(isinstance(iid,str) and iid and iid not in named,"Unique input artifact_id required.")
        require(row.get("type") in {"image","instance_masks","detections","points","table"},"Unsupported external input type.")
        p=resolve(row.get("path"),base); require(p.is_file(),f"Input file missing: {p}")
        actual_hash=file_hash(p)
        if "sha256" in row: require(row["sha256"]==actual_hash,"Declared input content hash does not match actual file.")
        row["path"]=str(p); row["sha256"]=actual_hash
        if row["type"] in {"image","instance_masks"}:
            require(row.get("axes") in {"YX","YXC","ZYX","ZYXC","TZYX","TYXC"},"Explicit image axes required.")
            require(isinstance(row.get("space_id"),str) and row["space_id"],"space_id required.")
        named[iid]=row
    steps=intent.get("steps")
    require(isinstance(steps,list) and steps,"Agent must translate the goal into explicit steps before calling create.")
    require(len(steps)<=intent.get("max_steps",12),"Plan exceeds max_steps.")
    normalized=[]
    for original in steps:
        s=dict(original); require(s.get("task") in IO,"Unknown task type.")
        require(s.get("mode","predict") in {"predict","train"},"Unknown mode.")
        refs=s.get("inputs"); require(isinstance(refs,list) and refs,"Step inputs must be explicit.")
        deps=set(s.get("depends_on",[]))
        for ref in refs:
            require(isinstance(ref,dict),"Input binding must be an object.")
            require(("artifact_id" in ref) != ("from_step" in ref),"Binding must reference either an external artifact or an upstream step.")
            if "artifact_id" in ref: require(ref["artifact_id"] in named,"Unknown external artifact.")
            else:
                require(isinstance(ref.get("artifact_type"),str),"Upstream artifact_type required.")
                deps.add(ref["from_step"])
        s["depends_on"]=sorted(deps); normalized.append(s)
    ordered=topological(normalized)
    allocations=[s.get("wall_time_seconds") for s in ordered]
    explicit=sum(v for v in allocations if v is not None and positive(v))
    require(all(v is None or positive(v) for v in allocations),"Step budgets must be positive.")
    remaining=budget["wall_time_seconds"]-reserve-explicit
    unallocated=sum(v is None for v in allocations)
    require(remaining>=0 and (not unallocated or remaining>0),"Step budgets plus evaluation reserve exceed total budget.")
    known_steps={}; result_steps=[]; runtime_checks=[]
    for s in ordered:
        sid=s["step_id"]; task=s["task"]; mode=s.get("mode","predict")
        candidates=[]
        for m in models:
            if task not in m["tasks"] or mode not in m["documented_modes"]: continue
            status,reasons=readiness(facts.get(m["id"]),m,mode,fact_base)
            candidates.append({"implementation_id":m["id"],"skill_id":expert_skill(m),"readiness":status,
                               "missing_conditions":reasons,"adapter_available":m["adapter"] is not None and mode in m["adapter_modes"],
                               "scientific_validation":m.get("scientific_validation","not_established")})
        require(candidates,f"No implementation supports task/mode for {sid}.")
        preferred=s.get("preferred_implementations",[])
        require(isinstance(preferred,list) and all(isinstance(x,str) for x in preferred),"preferred_implementations must be a list of IDs.")
        valid_ids={m["implementation_id"] for m in candidates}
        require(set(preferred)<=valid_ids,f"Preferred implementation incompatible with task/mode: {sid}.")
        ranks={"ready":0,"unknown":1,"blocked":2}
        candidates.sort(key=lambda m:(preferred.index(m["implementation_id"]) if m["implementation_id"] in preferred else len(preferred),ranks[m["readiness"]],m["implementation_id"]))
        chosen=preferred[0] if preferred else next((m["implementation_id"] for m in candidates if m["readiness"]=="ready"),None)
        if chosen is None: issues.append({"step_id":sid,"code":"candidate_not_selected","message":"No ready candidate and no explicit preferred implementation."})
        selected=next((m for m in candidates if m["implementation_id"]==chosen),None)
        if selected and selected["readiness"]!="ready": issues.append({"step_id":sid,"code":"environment_not_verified","message":selected["missing_conditions"]})
        outputs={"model_weights","training_log"} if mode=="train" else output_types(task,chosen)
        supplied=set()
        for ref in s["inputs"]:
            if "artifact_id" in ref:
                row=named[ref["artifact_id"]]; supplied.add(row["type"])
                if task=="fluorescence" and row["type"]=="image":
                    require(row.get("intensity_role") in {"raw","validated_corrected"},"Fluorescence must measure raw/validated-corrected intensity.")
                    require(not any(h.get("operation") in {"clahe","percentile","median","gaussian","care","n2v","restormer"} for h in row.get("processing_history",[])),"Unvalidated intensity processing in measurement source.")
            else:
                parent=known_steps[ref["from_step"]]
                require(ref["artifact_type"] in parent["output_types"],f"Upstream output type mismatch for {sid}; add an explicit conversion step.")
                supplied.add(ref["artifact_type"])
        require(IO[task][0]<=supplied,f"Missing required input types for {sid}: {sorted(IO[task][0]-supplied)}")
        params=s.get("params",{}); require(isinstance(params,dict),"params must be an object.")
        if task=="fluorescence":
            require(params.get("background_method") in {"none","constant","global_background_median"},"Explicit fluorescence background method required.")
            for ref in s["inputs"]:
                if "from_step" in ref and ref["artifact_type"]=="image":
                    parent=known_steps[ref["from_step"]]
                    require(parent["task"]=="process" and parent["proposed_implementation_id"] in {"identity","crop","flatfield"},"Upstream image processing is not established as quantitative; use original intensity image.")
                    runtime_checks.append({"step_id":sid,"code":"intensity_lineage","requirement":"Verify materialized intensity role, processing history, shape and coordinate space."})
        model=dict(s.get("model",{}))
        if chosen and next(m for m in models if m["id"]==chosen)["requires_weights"]:
            if not model.get("weights_path"): issues.append({"step_id":sid,"code":"weights_path_missing","message":"Local checkpoint/model directory must be specified."})
            else:
                p=resolve(model["weights_path"],base); model["weights_path"]=str(p)
                if not p.exists(): issues.append({"step_id":sid,"code":"weights_missing","message":"Local checkpoint/model directory does not exist."})
                elif p.is_file(): model["weights_sha256"]=file_hash(p)
                elif p.is_dir(): model["weights_manifest"]={f.relative_to(p).as_posix():file_hash(f) for f in sorted(p.rglob("*")) if f.is_file()}
        step={"step_id":sid,"task":task,"mode":mode,"inputs":s["inputs"],"depends_on":s["depends_on"],
              "output_types":sorted(outputs),"proposed_implementation_id":chosen,"skill_id":selected["skill_id"] if selected else None,
              "candidates":candidates,"selection_reason":"explicit_preference" if preferred else "first_ready_not_performance_ranked",
              "params":params,"model":model,
              "wall_time_seconds":s.get("wall_time_seconds",remaining/unallocated if unallocated else 0)}
        if mode=="train":
            path=s.get("training_manifest_ref")
            if not path: issues.append({"step_id":sid,"code":"training_manifest_missing","message":"Human-reviewed sample-level training manifest required."})
            else:
                p=resolve(path,base); step["training_manifest_ref"]=str(p)
                if not p.is_file(): issues.append({"step_id":sid,"code":"training_manifest_missing","message":"Training manifest file not found."})
        known_steps[sid]=step; result_steps.append(step)
    evaluation=intent.get("evaluation",{})
    require(evaluation.get("scope") in {"integrity_only","supervised_outcomes"},"Explicit evaluation scope required.")
    require(evaluation.get("ground_truth_status") in {"available","unavailable","pending_review"},"Explicit ground_truth_status required.")
    rubrics=evaluation.get("rubric_requirements",[])
    require(isinstance(rubrics,list) and all(isinstance(r,dict) and r.get("id") and r.get("protocol") and r.get("acceptance") for r in rubrics),"Each rubric requirement needs id, protocol, acceptance.")
    truth_refs=[]
    if evaluation["scope"]=="supervised_outcomes":
        require(evaluation["ground_truth_status"]=="available","Supervised evaluation cannot be promised without confirmed ground truth.")
        require(bool(evaluation.get("rubric_requirements")),"Specify supervised metric/protocol and acceptance conditions, rather than inventing them.")
        for value in evaluation.get("ground_truth_refs",[]):
            p=resolve(value,base); require(p.is_file(),"Ground truth file reference missing."); truth_refs.append({"path":str(p),"sha256":file_hash(p)})
        require(truth_refs,"Supervised evaluation needs existing ground_truth_refs; file presence does not prove label quality.")
    contract={"schema_version":"1.0","experiment_id":intent["experiment_id"],"dataset_version":intent["dataset_version"],
              "tasks":sorted({s["task"] for s in result_steps}),"status":"draft","evaluation_scope":evaluation["scope"],
              "ground_truth_status":evaluation["ground_truth_status"],"ground_truth_refs":truth_refs,"public_checks":PUBLIC_CHECKS,
              "rubric_requirements":evaluation.get("rubric_requirements",[]),
              "required_evidence":sorted({x for p in PUBLIC_CHECKS for x in p["required_evidence"]}|set(evaluation.get("required_evidence",[]))),
              "independence":"logical_role_separation_not_identity_authenticated","intent_hash":digest(intent)}
    plan={"schema_version":"1.0","planner_version":VERSION,"experiment_id":intent["experiment_id"],"dataset_version":intent["dataset_version"],
          "goal":intent["goal"],"status":"draft","created_at_utc":datetime.now(timezone.utc).isoformat(),
          "intent_hash":digest(intent),"registry_hash":digest(registry),"availability_hash":digest(availability),
          "contract_draft_hash":digest(contract),"budget":{**budget,"evaluation_reserve_seconds":reserve},
          "max_negotiation_rounds":max_rounds,"inputs":list(named.values()),"steps":result_steps,"open_issues":issues,"runtime_checks":runtime_checks,
          "execution_performed":False,"readiness_is_declared_evidence_not_certified":True}
    plan["plan_hash"]=digest(plan)
    if normalization_only: return plan
    outdir=Path(outdir).resolve(); require(not outdir.exists(),"Use a new plan directory; do not overwrite previous negotiations.")
    outdir.mkdir(parents=True)
    write(outdir/"plan.json",plan); write(outdir/"intent.snapshot.json",intent); write(outdir/"eval-contract.draft.json",contract)
    write(outdir/"availability.snapshot.json",availability)
    write(outdir/"negotiation.json",{"schema_version":"1.0","plan_hash":plan["plan_hash"],"round":1,"max_rounds":max_rounds,
             "roles":{"planner":"pending","executor":"pending","evaluator":"pending"},"open_issues":issues,
             "next":"Collect explicit feasibility and rubric reviews; create a new draft version for any plan/contract changes."})
    return plan


def read_plan(directory):
    directory=Path(directory).resolve(); p=load(directory/"plan.json")
    value=dict(p); recorded=value.pop("plan_hash")
    require(digest(value)==recorded,"Plan was modified after hashing; create a new draft.")
    contract=load(directory/"eval-contract.draft.json")
    require(digest(contract)==p["contract_draft_hash"],"Contract draft changed after planning.")
    return directory,p,contract


def agree(directory,review_paths):
    directory,plan,contract=read_plan(directory)
    require(not plan["open_issues"],"Resolve open plan issues and create a new draft before agreement.")
    require(len(review_paths)==3,"Exactly one planner, executor and evaluator review required.")
    reviews={}; evidence=[]
    for path in review_paths:
        path=Path(path).resolve(); r=load(path); role=r.get("role")
        require(r.get("schema_version")=="1.0","Unsupported role review schema_version.")
        require(role in {"planner","executor","evaluator"} and role not in reviews,"Duplicate or invalid review role.")
        require(r.get("plan_hash")==plan["plan_hash"] and r.get("contract_draft_hash")==plan["contract_draft_hash"],"Review does not bind the current plan and contract.")
        require(r.get("decision")=="accept","All role reviews must explicitly accept; a revise decision does not expire into acceptance.")
        require(isinstance(r.get("reviewer_ref"),str) and r["reviewer_ref"],"Reviewer reference required.")
        require(isinstance(r.get("evidence_refs"),list) and r["evidence_refs"],"Review evidence references required.")
        for ref in r["evidence_refs"]:
            p=resolve(ref,path.parent); require(p.is_file(),"Review evidence file missing.")
            evidence.append({"role":role,"path":str(p),"sha256":file_hash(p)})
        reviews[role]={"path":str(path),"sha256":file_hash(path),"reviewer_ref":r["reviewer_ref"]}
    require(set(reviews)=={"planner","executor","evaluator"},"Missing role review.")
    agreed={**contract,"status":"agreed","plan_hash":plan["plan_hash"],"reviewed_contract_draft_hash":plan["contract_draft_hash"],"reviews":reviews,"review_evidence":evidence,
            "agreement_note":"Recorded role decisions; not a cryptographic identity check or scientific result approval."}
    cp=directory/"eval-contract.agreed.json"; ap=directory/"agreement.json"
    require(not cp.exists() and not ap.exists(),"Agreement already exists; do not overwrite.")
    write(cp,agreed)
    agreement={"schema_version":"1.0","plan_hash":plan["plan_hash"],"agreed_contract_sha256":file_hash(cp),"roles":reviews,"status":"agreed"}
    write(ap,agreement)
    return agreement


def materialize(directory,step_id,output,result_refs):
    directory,plan,_=read_plan(directory)
    agreement=load(directory/"agreement.json"); contract_path=directory/"eval-contract.agreed.json"
    require(agreement.get("status")=="agreed" and agreement["plan_hash"]==plan["plan_hash"],"Current agreement required.")
    require(file_hash(contract_path)==agreement["agreed_contract_sha256"],"Agreed contract has changed.")
    agreed=load(contract_path)
    for evidence in agreed.get("ground_truth_refs",[])+agreed.get("review_evidence",[]):
        p=Path(evidence["path"]); require(p.is_file() and file_hash(p)==evidence["sha256"],"Ground truth or review evidence changed after agreement.")
    for review in agreement.get("roles",{}).values():
        p=Path(review["path"]); require(p.is_file() and file_hash(p)==review["sha256"],"Role review changed after agreement.")
    return materialize_bound(plan,contract_path,agreement["agreed_contract_sha256"],step_id,output,result_refs)


def materialize_bound(plan,contract_path,contract_sha256,step_id,output,result_refs):
    """Bind immutable inputs; authorization belongs to the caller, not simulated roles."""
    step=next((s for s in plan["steps"] if s["step_id"]==step_id),None); require(step is not None,"Unknown step_id.")
    roots={r["artifact_id"]:r for r in plan["inputs"]}; results={}
    for source,value in result_refs.items():
        path=Path(value).resolve(); r=load(path)
        require(r.get("status")=="succeeded","Only successful upstream results can be bound.")
        require(r.get("experiment_id")==plan["experiment_id"] and r.get("dataset_version")==plan["dataset_version"],"Upstream experiment/dataset mismatch.")
        parent=next((s for s in plan["steps"] if s["step_id"]==source),None); require(parent is not None,"Unknown upstream step.")
        require(r.get("implementation_id")==parent["proposed_implementation_id"] and r.get("task")==parent["task"],"Upstream implementation or task does not match plan.")
        require(r.get("mode")==parent["mode"],"Upstream mode does not match planned train/predict stage.")
        require(r.get("eval_contract_sha256")==contract_sha256,"Upstream execution used a different contract.")
        require(r.get("request_id")==plan["experiment_id"]+"-"+source,"Upstream request_id does not bind the planned step.")
        results[source]=(path,r)
    require(set(step["depends_on"])<=set(results),"Missing upstream result for a dependency.")
    bound=[]
    for ref in step["inputs"]:
        if "artifact_id" in ref: row=dict(roots[ref["artifact_id"]])
        else:
            source_path,data=results[ref["from_step"]]
            matches=[a for a in data.get("artifacts",[]) if a.get("type")==ref["artifact_type"] and (not ref.get("artifact_id_select") or a.get("artifact_id")==ref["artifact_id_select"])]
            require(len(matches)==1,"Artifact binding is missing or ambiguous; choose artifact_id_select.")
            row=dict(matches[0]); row["path"]=str(resolve(row["path"],source_path.parent))
        p=Path(row["path"]); require(p.is_file() and file_hash(p)==row["sha256"],"Bound artifact missing or changed.")
        bound.append(row)
    if step["task"]=="fluorescence":
        image=next((i for i in bound if i["type"]=="image"),None)
        require(image and image.get("intensity_role") in {"raw","validated_corrected"},"Bound intensity image is not quantitative.")
        require(not any(h.get("operation") in {"clahe","percentile","median","gaussian","care","n2v","restormer"} for h in image.get("processing_history",[])),"Bound image has unvalidated intensity-changing history.")
        mask=next((i for i in bound if i["type"]=="instance_masks"),None)
        require(mask and mask.get("space_id")==image.get("space_id"),"Bound intensity image and instance mask have different coordinate spaces.")
    if step["model"].get("weights_path"):
        wp=Path(step["model"]["weights_path"])
        if "weights_sha256" in step["model"]: require(wp.is_file() and file_hash(wp)==step["model"]["weights_sha256"],"Model weights changed after planning.")
        if "weights_manifest" in step["model"]:
            require(wp.is_dir(),"Model directory disappeared.")
            current={f.relative_to(wp).as_posix():file_hash(f) for f in sorted(wp.rglob("*")) if f.is_file()}
            require(current==step["model"]["weights_manifest"],"Model directory changed after planning.")
    request={"schema_version":"1.0","experiment_id":plan["experiment_id"],"request_id":plan["experiment_id"]+"-"+step_id,
             "dataset_version":plan["dataset_version"],"implementation_id":step["proposed_implementation_id"],"task":step["task"],"mode":step["mode"],
             "inputs":bound,"params":step["params"],"model":step["model"],"allow_download":False,
             "eval_contract_ref":str(contract_path),"budget":{"wall_time_seconds":step["wall_time_seconds"],"device":plan["budget"]["device"]}}
    if "training_manifest_ref" in step: request["training_manifest_ref"]=step["training_manifest_ref"]
    write(output,request)
    return request


def affected(directory,changed,dataset_changed=False):
    _,plan,_=read_plan(directory)
    ids={s["step_id"] for s in plan["steps"]}
    require(set(changed)<=ids,"Unknown changed step.")
    invalid=set(ids) if dataset_changed else set(changed)
    for s in plan["steps"]:
        if set(s["depends_on"])&invalid: invalid.add(s["step_id"])
    return {"plan_hash":plan["plan_hash"],"invalidated_steps":[s["step_id"] for s in plan["steps"] if s["step_id"] in invalid],
            "reusable_steps":[s["step_id"] for s in plan["steps"] if s["step_id"] not in invalid],"execution_performed":False,
            "note":"Dependency-based reuse proposal; validate data/weights/config provenance before actual cache reuse."}


def main():
    p=argparse.ArgumentParser(description=__doc__); sub=p.add_subparsers(dest="command",required=True)
    q=sub.add_parser("create"); q.add_argument("--intent",required=True); q.add_argument("--registry"); q.add_argument("--availability"); q.add_argument("--output",required=True)
    q=sub.add_parser("agree"); q.add_argument("--plan-dir",required=True); q.add_argument("--review",action="append",required=True)
    q=sub.add_parser("materialize"); q.add_argument("--plan-dir",required=True); q.add_argument("--step",required=True); q.add_argument("--output",required=True); q.add_argument("--result",action="append",default=[])
    q=sub.add_parser("affected"); q.add_argument("--plan-dir",required=True); q.add_argument("--changed",action="append",default=[]); q.add_argument("--dataset-changed",action="store_true")
    args=p.parse_args()
    try:
        if args.command=="create": value=create(args.intent,args.output,args.registry,args.availability)
        elif args.command=="agree": value=agree(args.plan_dir,args.review)
        elif args.command=="affected": value=affected(args.plan_dir,args.changed,args.dataset_changed)
        else:
            refs={}
            for entry in args.result:
                key,sep,path=entry.partition("="); require(sep and key and path and key not in refs,"Use unique --result step_id=path entries."); refs[key]=path
            value=materialize(args.plan_dir,args.step,args.output,refs)
        print(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)); return 0
    except Exception as exc:
        print(json.dumps({"status":"blocked","execution_performed":False,"error":{"type":type(exc).__name__,"message":str(exc)}},ensure_ascii=False),file=sys.stderr); return 2


if __name__=="__main__": raise SystemExit(main())
