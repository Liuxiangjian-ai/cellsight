"""CellSight Eval-first CLI. Commands use local files and packaged builtins only."""
import argparse
import json
import sys
import cs_registry as registry
import cs_contract as contract
import cs_plan as planner
import cs_state as state
import cs_eval as evaluation
import cs_benchmark as benchmark

def main():
    parser=argparse.ArgumentParser(description=__doc__); sub=parser.add_subparsers(dest='command',required=True)
    def command(name,arguments):
        item=sub.add_parser(name)
        for argument in arguments: item.add_argument('--'+argument,required=True)
        return item
    command('registry-init',['registry'])
    command('register',['registry','manifest'])
    command('activate-builtin',['registry','id','evidence'])
    command('import-catalog',['registry','catalog'])
    command('build-contract',['intent','registry','output'])
    command('freeze-contract',['draft','registry','output'])
    command('plan',['intent','contract','registry','output'])
    command('start',['brief','project'])
    command('attach',['project','plan'])
    command('status',['project'])
    command('execute',['project','output'])
    command('evaluate',['project','output'])
    command('record-eval',['project','report'])
    command('reconcile',['project'])
    command('replan',['project','report','output'])
    command('cost',['project','seconds','reason'])
    command('stop',['project','reason'])
    item=command('deliver',['project','report']); item.add_argument('--artifact',action='append',required=True)
    command('benchmark',['protocol','result','private-truth','output'])
    args=parser.parse_args()
    try:
        name=args.command
        if name=='registry-init': value={'path':str(registry.init(args.registry))}
        elif name=='register': value=registry.register(args.registry,args.manifest)
        elif name=='activate-builtin': value=registry.activate_builtin(args.registry,args.id,args.evidence)
        elif name=='import-catalog': value=registry.import_execution_catalog(args.registry,args.catalog)
        elif name=='build-contract': value=contract.build(args.intent,args.registry,args.output)
        elif name=='freeze-contract': value=contract.freeze(args.draft,args.registry,args.output)
        elif name=='plan': value=planner.create(args.intent,args.contract,args.registry,args.output)
        elif name=='start': value=state.start(args.brief,args.project)
        elif name=='attach': value=state.attach(args.project,args.plan)
        elif name=='status': value=state.status(args.project)
        elif name=='execute': value=state.execute_next(args.project,args.output)
        elif name=='evaluate': value=state.evaluate_next(args.project,args.output)
        elif name=='record-eval': value=state.record_eval(args.project,args.report)
        elif name=='reconcile': value=state.reconcile(args.project)
        elif name=='replan': value=state.revise(args.project,args.report,args.output)
        elif name=='deliver': value=state.deliver(args.project,args.report,args.artifact)
        elif name=='cost': value=state.record_cost(args.project,float(args.seconds),args.reason)
        elif name=='stop': value=state.stop(args.project,args.reason)
        else: value=benchmark.run(args.protocol,args.result,args.private_truth,args.output)
        print(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)); return 0
    except Exception as exc:
        print(json.dumps({'status':'ERROR','error_type':type(exc).__name__,'message':str(exc)},ensure_ascii=False),file=sys.stderr); return 2

if __name__=='__main__': raise SystemExit(main())
