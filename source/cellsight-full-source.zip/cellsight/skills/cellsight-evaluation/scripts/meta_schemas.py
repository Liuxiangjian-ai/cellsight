"""Schemas for the additive Meta-Skill protocol; legacy 2.0 schemas stay unchanged."""
S = {'type': 'string', 'minLength': 1}
STRINGS = {'type': 'array', 'items': S, 'uniqueItems': True}
HASH = {'type': 'string', 'pattern': '^[0-9a-f]{64}$'}
VERSION = {'type': 'string', 'pattern': r'^\d+\.\d+\.\d+$'}
STAT = {'enum': ['PASS', 'FAIL', 'NEEDS_REVIEW', 'NOT_EVALUABLE', 'ERROR']}


def obj(properties, required=None, extra=False):
    return {'type': 'object', 'properties': properties,
            'required': list(properties) if required is None else required, 'additionalProperties': extra}


DEFINITION = obj({
    'id': S, 'method': {'enum': ['integrity', 'classification', 'count_consistency', 'ratio', 'field_range', 'rubric']},
    'parameters': {'type': 'object'}, 'acceptance': {'type': 'object'},
    'threshold_source': obj({'kind': {'enum': ['user_requirement', 'protocol', 'dataset_specification', 'pilot_calibration']}, 'reference': S}),
    'scientific_basis': obj({'status': {'enum': ['operational_rule', 'needs_expert_review', 'externally_reviewed']},
                             'reference': S, 'reviewer': S, 'evidence_sha256': HASH}, ['status', 'reference']),
    'limitations': STRINGS,
}, ['id', 'method', 'parameters', 'acceptance', 'scientific_basis', 'limitations'])

MANIFEST = obj({
    'schema_version': {'const': '3.0'}, 'id': {'type': 'string', 'pattern': '^cellsight-[a-z0-9-]+$'},
    'version': VERSION, 'type': {'enum': ['execution', 'evaluation']},
    'capabilities': obj({'tasks': {**STRINGS, 'minItems': 1}, 'methods': {**STRINGS, 'minItems': 1}, 'modes': {**STRINGS, 'minItems': 1}}),
    'input_schema': {'type': 'object'}, 'output_schema': {'type': 'object'},
    'domain_scope': obj({'domains': {**STRINGS, 'minItems': 1}, 'limitations': STRINGS, 'scientific_validation': S}),
    'runtime': obj({'dependencies': STRINGS, 'devices': {**STRINGS, 'minItems': 1}, 'requires_weights': {'type': 'boolean'}}),
    'entrypoint': obj({'kind': {'enum': ['builtin', 'host_skill', 'python', 'service']}, 'name': S}),
    'permissions': obj({'network': {'type': 'boolean'}, 'filesystem': {'enum': ['host_scoped', 'read_only', 'none']}, 'subprocess': {'type': 'boolean'}}),
    'source': obj({'origin': {'enum': ['built-in', 'uploaded', 'generated']}, 'publisher': S, 'reference': S}),
    'required_evidence': STRINGS,
    'validation_status': {'enum': ['unverified', 'structure_checked', 'template_verified', 'needs_review']},
    'registration_status': {'enum': ['unregistered', 'registered']},
    'availability': {'enum': ['unverified', 'pending_installation', 'ready', 'unavailable', 'disabled']},
})

PAYLOAD = obj({
    'task_id': S, 'dataset_version': S, 'values': {'type': 'object'}, 'metadata': {'type': 'object'},
    'predictions': {'type': 'array', 'items': {'type': 'object'}},
    'artifacts': {'type': 'array', 'items': obj({'artifact_id': S, 'type': S, 'path': S, 'sha256': HASH})},
}, ['task_id', 'dataset_version', 'values', 'artifacts'])

REQUIREMENT = obj({'id': S, 'capability': S, 'required': {'type': 'boolean'}, 'definition': DEFINITION})
ITEM = obj({'id': S, 'capability': S, 'required': {'type': 'boolean'}, 'definition': DEFINITION,
            'evaluator': obj({'id': S, 'version': VERSION, 'manifest_hash': HASH, 'implementation_hash': HASH})})

SPEC = obj({
    'schema_version': {'const': '1.0'}, 'task_id': S, 'dataset_version': S, 'goal': S, 'task_type': S, 'domain': S,
    'profile_id': S, 'version': VERSION, 'status': {'enum': ['DRAFT', 'FROZEN']},
    'evaluation_object': {'enum': ['user_task']}, 'required_outputs': STRINGS,
    'requirements': {'type': 'array', 'minItems': 1, 'items': REQUIREMENT},
    'items': {'type': 'array', 'items': ITEM},
    'decision': {'enum': ['REUSE', 'COMPOSE', 'GENERATE', 'UNAVAILABLE']},
    'uncovered': STRINGS, 'issues': STRINGS,
    'evidence_policy': obj({'supervised_metrics_require_private_labels': {'const': True},
                            'final_test_feedback_for_replanning': {'const': False}}),
    'failure_policy': obj({'max_replans': {'type': 'integer', 'minimum': 0},
                           'allow_threshold_relaxation': {'const': False}}),
    'budget': obj({'wall_time_seconds': {'type': 'number', 'exclusiveMinimum': 0},
                   'evaluation_reserve_seconds': {'type': 'number', 'exclusiveMinimum': 0}}),
    'spec_hash': HASH,
})

REPORT = obj({
    'schema_version': {'const': '3.0'}, 'task_id': S, 'dataset_version': S, 'spec_hash': HASH,
    'source_type': {'enum': ['user_task_evaluation', 'external_benchmark']}, 'status': STAT,
    'items': {'type': 'array', 'minItems': 1, 'items': obj({
        'id': S, 'required': {'type': 'boolean'}, 'eval_skill_id': S, 'eval_skill_version': VERSION,
        'method': S, 'definition_hash': HASH, 'status': STAT, 'reason': S, 'metrics': {'type': 'object'},
        'judge': {'type': 'object'}, 'independence': S, 'not_supervised_accuracy': {'type': 'boolean'},
    }, ['id', 'required', 'eval_skill_id', 'eval_skill_version', 'method', 'definition_hash', 'status', 'reason', 'metrics'])},
    'input_ref': obj({'path': S, 'sha256': HASH}),
    'evidence': {'type': 'array', 'items': {'type': 'object'}},
    'unverified_matters': STRINGS, 'evaluation_scope': S,
    'recommendation': obj({'action': {'enum': ['NONE', 'REVISE', 'REPLAN', 'ESCALATE']}, 'reason': S}),
    'limitations': STRINGS, 'wall_time_seconds': {'type': 'number', 'minimum': 0}, 'report_hash': HASH,
})

PLAN = obj({
    'schema_version': {'const': 'meta-plan-1.0'}, 'task_id': S, 'dataset_version': S,
    'spec_hash': HASH, 'spec_ref': obj({'path': S, 'sha256': HASH}),
    'status': {'enum': ['DRAFT', 'READY_FOR_HOST_CHECK']},
    'steps': {'type': 'array', 'minItems': 1, 'items': obj({
        'step_id': S, 'skill_id': S, 'version': VERSION, 'task': S, 'mode': S,
        'depends_on': STRINGS, 'inputs': STRINGS, 'output_types': STRINGS,
        'wall_time_seconds': {'type': 'number', 'exclusiveMinimum': 0},
    })},
    'budget': obj({'wall_time_seconds': {'type': 'number', 'exclusiveMinimum': 0},
                   'evaluation_reserve_seconds': {'type': 'number', 'exclusiveMinimum': 0}}),
    'execution_performed': {'const': False}, 'plan_hash': HASH,
})

COMPACT_REPORT = {'type': 'object', 'required': ['status', 'metrics', 'definition_hash', 'input_sha256', 'report_hash'],
                  'properties': {'status': STAT, 'metrics': {'type': 'object'}}}

SCHEMAS = {'evaluation-specification': SPEC, 'meta-skill-manifest': MANIFEST,
           'eval-definition': DEFINITION, 'meta-evaluation-input': PAYLOAD,
           'meta-evaluation-report': REPORT, 'meta-execution-plan': PLAN}
