"""Planner adapter: Intent + frozen Contract + ready Registry -> immutable Execution Plan."""
from pathlib import Path
import copy
from cs_common import CORE,load,write,sha,digest,require,ref,check_ref,now,sealed,check_seal,no_truth
import cs_contract as contracts
import cs_registry as registry

def create(intent_path,contract_path,registry_path,outdir):
    task=contracts.intent(intent_path); contract=contracts.read(contract_path); catalog=registry.read(registry_path)
    require(contract['intent_hash']==digest(task),'Contract binds another Task Intent; regenerate acceptance before changing the task.')
    return build(task,contract,contract_path,registry_path,outdir,intent_path,None)

def build(task,contract,contract_path,registry_path,outdir,intent_path,revision_of):
    no_truth(task); catalog=registry.read(registry_path); outdir=Path(outdir).resolve()
    require(not outdir.exists(),'Use a new immutable plan directory.')
    # Convert ready unified manifests to the existing, tested normalization interface.
    legacy=load(Path(__file__).resolve().parents[1]/'assets/execution-registry.json')
    ready=[]
    for step in task['steps']:
        candidates=registry.query(catalog,'execution',step['task'],task['domain'])
        require(candidates,'No verified ready Execution Skill for task/domain '+step['task']+'/'+task['domain'])
        ready.extend(candidates)
    selected={m['id']:m for m in ready}
    ids={method for m in selected.values() for method in m['capabilities']['methods']}
    legacy['implementations']=[m for m in legacy['implementations'] if m['id'] in ids and m['skill_id'] in selected]
    legacy['skills']=[m for m in legacy['skills'] if m['skill_id'] in selected]
    require(legacy['implementations'],'No implemented wire adapter for the selected manifests; host adapter required.')
    normalized=copy.deepcopy(task); normalized['schema_version']='1.0'
    normalized['evaluation']={'scope':'integrity_only','ground_truth_status':'unavailable','rubric_requirements':[]}
    for row in normalized['inputs']: row['path']=str(CORE.resolve(row['path'],Path(intent_path).resolve().parent))
    outdir.mkdir(parents=True)
    # Artifacts used by the old normalizer are transparent projections, not fake reviews.
    normalizer_intent=outdir/'normalizer-intent.json'; reg=outdir/'execution-registry.projection.json'; availability=outdir/'availability.projection.json'
    write(normalizer_intent,normalized); write(reg,legacy)
    rows=[]
    for model in legacy['implementations']:
        m=selected[model['skill_id']]; evidence=m['availability']['evidence'][0]['path']
        rows.append({'implementation_id':model['id'],'skill_available':True,'dependencies_imported':True,'device_compatible':True,'smoke_test_passed':True,
          'weights_available':not model['requires_weights'],'smoke_test_ref':evidence,'observed_at':m['availability']['observed_at'],
          'readiness_scope':'legacy_flag_projection_of_verified_callable_not_scientific_validation'})
    write(availability,{'schema_version':'1.0','implementations':rows})
    plan=CORE.create(normalizer_intent,None,reg,availability,normalization_only=True)
    require(not plan['open_issues'],'Resolve unavailable implementations/weights before execution: '+str(plan['open_issues']))
    for key in ['plan_hash','contract_draft_hash','max_negotiation_rounds','created_at_utc','intent_hash']: plan.pop(key,None)
    plan.update(schema_version='2.0',planner_version='0.4.0',status='READY',created_at=now(),intent_hash=digest(task),
      acceptance_intent_hash=contract['intent_hash'],contract_ref=ref(contract_path),contract_hash=contract['contract_hash'],
      registry_ref=ref(registry_path),registry_hash=catalog['registry_hash'],revision_of=revision_of,
      execution_manifests={m['id']:{'version':m['version'],'manifest_hash':registry.identity(m)} for m in selected.values()},
      expected_artifacts=contract['required_outputs'],execution_contract_ref=ref(write(outdir/'execution-contract.json',contracts.execution_view(contract))))
    write(outdir/'intent.snapshot.json',task); write(outdir/'plan.json',sealed(plan,'plan_hash'))
    return load(outdir/'plan.json')

def read(directory):
    directory=Path(directory).resolve(); value=load(directory/'plan.json'); check_seal(value,'plan_hash')
    check_ref(value['contract_ref']); contract=contracts.read(value['contract_ref']['path'])
    require(contract['contract_hash']==value['contract_hash'],'Plan/contract binding mismatch.')
    check_ref(value['execution_contract_ref']); require(load(value['execution_contract_ref']['path'])==contracts.execution_view(contract),'Execution view does not match frozen Contract.')
    return directory,value,contract

def verify_runtime_registry(plan):
    # Unrelated new registrations do not invalidate an existing plan; selected entries do.
    catalog=registry.read(plan['registry_ref']['path'])
    for sid,pin in plan['execution_manifests'].items():
        m=registry.get(catalog,sid,pin['version'])
        require(registry.ready(m) and registry.identity(m)==pin['manifest_hash'],'Selected Skill is unavailable or changed.')
    return catalog

def materialize(directory,step_id,output,result_refs):
    _,plan,contract=read(directory); verify_runtime_registry(plan)
    for row in contract['input_refs']: check_ref(row)
    request=CORE.materialize_bound(plan,Path(plan['execution_contract_ref']['path']),plan['execution_contract_ref']['sha256'],step_id,output,result_refs)
    no_truth(request); return request

def affected(plan,changed):
    ids={s['step_id'] for s in plan['steps']}; require(set(changed)<=ids,'Unknown changed step.')
    invalid=set(changed)
    for step in plan['steps']:
        if set(step['depends_on'])&invalid: invalid.add(step['step_id'])
    return {'invalidated_steps':sorted(invalid),'reusable_steps':sorted(ids-invalid),'reuse_is_explicit_artifact_reference_only':True}

def replan(directory,report_path,outdir,remaining_seconds):
    directory,old,contract=read(directory); report=load(report_path)
    check_seal(report,'report_hash')
    require(report['source_type']=='operational_evaluation','External Benchmark feedback is not available to replanning.')
    require(report['plan_hash']==old['plan_hash'] and report['contract_hash']==old['contract_hash'],'Stale report cannot replan the active task.')
    require(report['status']!='PASS' and report['recommendation']['action'] in {'REVISE','REPLAN'},'Report does not authorize a computable plan revision.')
    task=load(directory/'intent.snapshot.json'); suggestions=report['recommendation'].get('parameter_changes',{})
    require(suggestions,'No implemented automatic repair; ESCALATE with the evidence.')
    changed=[]
    for step in task['steps']:
        patch=suggestions.get(step['step_id'])
        if not patch: continue
        require(set(patch)=={'min_area_px'},'Only declared area filtering can be automatically revised in this version.')
        criteria=[i for i in contract['items'] if i['method']=='bbox-area-range']
        require(criteria and patch['min_area_px']==criteria[0]['acceptance']['min_area_px'],'Repair would change the predeclared success standard.')
        step.setdefault('params',{}).update(patch); changed.append(step['step_id'])
    require(changed,'Repair did not target any step.')
    task['budget']['wall_time_seconds']=min(task['budget']['wall_time_seconds'],remaining_seconds)
    reserve=task['budget'].get('evaluation_reserve_seconds',0)
    require(task['budget']['wall_time_seconds']>reserve,'Insufficient remaining budget for another execution and evaluation.')
    for step in task['steps']: step.pop('wall_time_seconds',None)
    new=build(task,contract,old['contract_ref']['path'],old['registry_ref']['path'],outdir,directory/'intent.snapshot.json',old['plan_hash'])
    return new,affected(old,changed)
