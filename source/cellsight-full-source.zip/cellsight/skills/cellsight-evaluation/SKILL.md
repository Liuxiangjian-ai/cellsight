---
name: cellsight-evaluation
description: CellSight评价总领Skill，将科研需求转为Evaluation Specification，优先复用、其次组合、最后按需生成Eval Skill，验证结构与运行条件并对真实产物输出有证据和范围限制的评价报告。
---

# CellSight Evaluation Meta-Skill

## 加载与报告纪律

科研工作流须实际读取本Skill完整说明。已有脚本算出指标不等于已加载本Skill。执行前形成并保存评价规范，执行后按规范核验真实产物。若规范只能事后建立，明确标记回顾性评价，不能称为预先冻结或证明历史流程合规。

报告除科研指标外，还检查计数、逐图清单、汇总与说明是否一致；未经核验的自编脚本列为待核验实现，不预设为正确。宿主加载记录不可见时说明观测限制。


你负责用户科研任务的评价能力配置与运行。采用 **Reuse → Compose → Generate**。内部Agent Eval用于开发回归，独立CV Benchmark用于性能比较，二者的答案与标签不进入当前任务的规划上下文。默认不模拟独立子智能体。

## 1. 理解评价需求

接收Planner的Task Intent，明确对象/表型、科学问题、任务与模态、数据版本、交付物、用户约束及可用证据。区分科学测量、模型性能、执行质量。损伤不自动等同于死亡、凋亡或形态异常；比例要明确分子、有效分母、排除规则及不确定对象的处理。只追问会改变含义、算法或验收条件的缺口。无数据时保留草案，不生成替代细胞图像。

将自然语言理解结果写成[结构化brief](assets/examples/brief-ratio.json)，参见[接口与职责](references/meta-interfaces.md)。语义提取由宿主LLM完成；Python辅助程序处理结构化输入，没有内置远程LLM或通用自然语言解析服务。

## 2. Specification与能力路由

Evaluation Specification是默认产物；标准任务使用Eval Profile快速配置，复杂任务才展开专属规范。草案阶段与Planner共同发现能力及运行条件；不因模型限制降低用户标准，冻结后再形成正式Plan。按[Spec Schema](assets/schemas/evaluation-specification.schema.json)声明目标、评价对象、输出、逐项定义、计算协议、证据、阈值来源、领域边界、预算与失败策略。基础Profile只检查必要输出与来源，不自动增加F1或生物学阈值。只报告指标可以使用空acceptance；PASS仅表示已执行声明检查。

查询Registry声明与实际可用证据：任务、领域、输入输出、证据、方法、模式和实际入口必须覆盖需求。相同名词不保证协议相同。

- **Reuse**：配置已有能力，参数和科学定义写在本任务Spec中。
- **Compose**：组合多个能力，保持项目间数据依赖与必需/可选标记。必需项失败、缺证据或需审查时，其他项目不能抵消。
- **Generate**：记录无法覆盖的项目，才生成最小新增能力；不能因为新领域名称重复生成标准指标。

当前本地Runtime内置完整性、单标签分类指标、计数一致性、比例复算、LLM Rubric五类处理器。它们是内部ID，不是新增顶层上传Skill。调用入口仍为本Skill或宿主实际挂载的外部Eval。第三方处理器在本地没有通用执行桥，不能仅凭注册进入可执行候选。

## 3. 按需生成与验证

按[生成器说明](references/generator-validator.md)输出独立Skill包，含SKILL.md、manifest.json、定义、Schema、脚本及适用的测试。v0.5.1确定性生成仅支持比例、数值范围和Rubric的固定模板；任意代码、未知公式和科学定义保留待实现/待审查。宿主LLM可以起草新方法，不能将草稿标为已验证。

先区分规范校验与评价器就绪：validate-spec只校验Spec结构/声明协议，不检查实际挂载或证明科学有效性；Evaluator另行试跑，不能因SKILL.md或脚本存在标记ready。

执行四项独立验证：Schema、指标语义、实际可执行性、科学有效性。已知正例、失败例和边界例验证软件实现；通用Validator不能证明任意表型定义或阈值科学正确。自生成测试只能证明部分程序一致性；由同一LLM生成再审阅不构成独立专家验证。新专业Rubric缺少外部依据时保留科学待验证状态。Rubric启动器返回缺Judge，只证明缺失分支可运行，不证明已完成真实评价，不得据此启用为ready。

上传代码与生成代码均遵守宿主权限。辅助Validator仅对与本包固定源码完全一致的模板执行测试；其他代码只静态检查，不import、不自动安装。科学依据不足时保留NEEDS_REVIEW。注册、验证、可用性独立记录。生成ZIP不代表SciencePal已安装；本地activate-template只启用受限模板，不能描述为宿主动态挂载。

## 4. 执行前保存规范

问题明确、必要能力可用后保存Spec版本/hash快照，简单Profile也采用同样的轻量记录，无需每次让用户确认复杂Contract。数据未到位可先完成规范设计；实际执行前由Planner检查真实输入。未解决的科学问题、未知公式或必要评价能力缺失保留DRAFT。

把冻结规范交给Planner，再由Planner选择实际可用的Execution Skills。缺少标签时，已满足输入条件的预测可以继续；Spec保留准确率要求，监督项目返回NOT_EVALUABLE，不能以QA通过声称达标。缺标签本身不作为scientific_questions中的执行阻塞项，除非用户明确要求先具备监督验证条件。科学定义缺失等真正影响执行的问题仍阻塞冻结。执行后不修改公式、分母、阈值、必需项目或评价器以求PASS；修改要求须新版本并保存理由与旧结果。

## 5. Evaluation Runtime

按[运行接口](references/meta-runtime.md)读取冻结Spec和真实产物。方法包括确定性计算、科学一致性和Rubric；Ground Truth是证据条件，不是与确定性方法互斥的第四类。

科学测量由执行流程产生。Eval可独立复算比例、检查计数、单位或范围，但不能由此证明细胞识别或表型分类正确。监督分类指标必须读取评价器私有标签，按sample_id严格一一匹配；不静默丢样本。开发标签与最终测试标签明确区分。正式测试报告不作为自动修订反馈。

LLM需真实judge回调，缺失返回NOT_EVALUABLE；原生宿主可按Rubric审阅可见证据，说明同模型评审局限。不要把模型置信度、一致性、LLM分数等同于监督准确率。

输出[Report](assets/schemas/meta-evaluation-report.schema.json)，保留Eval ID/版本、Spec/hash、输入/产物引用、指标、来源、无法验证事项、局限及建议。状态为PASS、FAIL、NEEDS_REVIEW、NOT_EVALUABLE、ERROR；反馈为REVISE、REPLAN、ESCALATE或无需动作。PASS只涵盖实际执行且满足规范的必需检查。程序/数据绑定错误为ERROR；没有标签为NOT_EVALUABLE；科学假设待审查为NEEDS_REVIEW。

## 6. 状态、开放接口与兼容

使用[Project State](references/project-state.md)保留预算、版本、事件、恢复与失败证据。新模块复用原账本锁与提交原语；原调度器仍服务旧Contract项目，新Spec项目由宿主驱动，不能宣称已经自动调度71个CV模型。见[Planner接口](references/meta-interfaces.md)。

统一[Manifest 3.0](assets/schemas/meta-skill-manifest.schema.json)支持execution/evaluation。用户上传和系统生成均先登记待安装；宿主实际可用的外部能力由宿主机制运行，不虚构API或沙箱。新旧Registry是同一逻辑能力体系的不同本地协议版本，3.0目前没有旧记录自动迁移或任意第三方运行桥。

原2.0 Contract/Runtime、plan.py、coordinate.py和cs_state.py保留原样兼容旧项目。新版默认使用eval_meta.py，旧CLI不是新版Spec的执行器。完整范围见[版本边界](references/release-scope.md)。
