"""Software interface checks only: no image generation, CV execution or metric calculation."""
from pathlib import Path
import copy
import json
import sys
import tempfile
import unittest

OUT=Path(__file__).resolve().parents[1]
SKILL=OUT/'skills/cellsight-planner'
sys.path.insert(0,str(SKILL/'scripts'))
from cs_common import load,write,schema,validate
import cs_contract as contracts
import cs_registry as registry
import cs_state as state

class InterfaceTests(unittest.TestCase):
    def setUp(self):
        scratch=Path.cwd()/'work';scratch.mkdir(exist_ok=True)
        self.tmp=tempfile.TemporaryDirectory(dir=scratch,prefix='cellsight-v041-interface-');self.addCleanup(self.tmp.cleanup)
        self.work=Path(self.tmp.name)

    def project(self):
        brief={'schema_version':'1.0','experiment_id':'interface-check','dataset_version':'no-data-supplied','goal':'Verify project bookkeeping only.',
          'budget':{'wall_time_seconds':60,'device':'cpu'},'limits':{'max_revisions':1},'required_eval_stages':['preflight','final']}
        path=write(self.work/'brief.json',brief);project=self.work/'project';state.start(path,project);return project

    def test_missing_data_blocks_contract_without_creating_output(self):
        output=self.work/'contract.json';catalog=self.work/'registry.json';registry.init(catalog)
        with self.assertRaisesRegex(ValueError,'Evidence missing'):
            contracts.build(SKILL/'assets/task-intent.example.json',catalog,output)
        self.assertFalse(output.exists())

    def test_contract_format_example_cannot_be_used_as_frozen_contract(self):
        value=load(SKILL/'assets/evaluation-contract.example.json');validate(value,schema('evaluation-contract'))
        self.assertEqual(value['status'],'DRAFT')
        with self.assertRaises(ValueError):contracts.read(SKILL/'assets/evaluation-contract.example.json')

    def test_custom_execution_registration_stays_pending(self):
        catalog=self.work/'registry.json';registry.init(catalog)
        value=registry.register(catalog,SKILL/'assets/manifests/custom-execution.example.json')
        self.assertEqual(value['availability']['status'],'pending_installation');self.assertFalse(registry.ready(value))

    def test_custom_evaluation_registration_stays_pending(self):
        manifest=load(SKILL/'assets/manifests/custom-execution.example.json')
        manifest.update(id='cellsight-custom-evaluation',type='evaluation')
        manifest['entrypoint']['name']='cellsight-custom-evaluation'
        manifest['capabilities']['methods']=['custom-rubric'];manifest['capabilities']['modes']=['preflight','stage','final']
        path=write(self.work/'custom-eval.json',manifest);catalog=self.work/'registry.json';registry.init(catalog)
        value=registry.register(catalog,path)
        self.assertEqual(value['availability']['status'],'pending_installation');self.assertFalse(registry.ready(value))

    def test_project_persists_without_fabricating_execution(self):
        project=self.project();status=state.status(project)
        self.assertEqual(status['next']['action'],'BUILD_CONTRACT_THEN_PLAN')
        self.assertFalse(status['results']);self.assertFalse(status['evaluations']);self.assertTrue((project/'events/000001.json').is_file())

    def test_recorded_budget_exhaustion_is_preserved(self):
        project=self.project();state.record_cost(project,61,'Bookkeeping-only budget check')
        status=state.status(project);self.assertEqual(status['spent_seconds'],61)
        self.assertEqual(status['next']['action'],'BUDGET_EXHAUSTED')

    def test_stop_does_not_invent_external_cancellation(self):
        project=self.project();state.stop(project,'Interface test stop')
        self.assertEqual(state.status(project)['next']['action'],'STOPPED')
        _,saved=state.read(project);event=load(project/'events'/f'{saved["sequence"]:06d}.json')
        self.assertFalse(event['details']['external_job_cancelled'])

    def test_modified_state_is_detected(self):
        project=self.project();path=project/'project.json';value=load(path);value['goal']='tampered'
        path.write_text(json.dumps(value),encoding='utf-8')
        with self.assertRaisesRegex(ValueError,'edited outside'):state.status(project)

if __name__=='__main__':unittest.main(verbosity=2)
