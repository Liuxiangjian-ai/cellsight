"""Observable execution and scientific data-contract regression checks."""
from pathlib import Path
import copy
import importlib.util
import json
import shutil
import subprocess
import sys
import tempfile
import unittest
import numpy as np

ROOT=Path(__file__).resolve().parents[1]


ACTIVE={}
DEFAULTS={"segmentation":"threshold-cc","quantification":"morphology","processing":"identity","tracking":"iou-tracker","classification":"resnet","detection":"threshold-boxes"}


def runtime(category,root=ROOT):
    implementation=ACTIVE.get(category,DEFAULTS.get(category))
    path=root/"skills"/("cellsight-"+category+"-"+implementation)/"scripts"/"run.py"
    spec=importlib.util.spec_from_file_location("lv_"+category.replace("-","_"),path)
    mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
    return mod


class ExecutionTests(unittest.TestCase):
    def setUp(self):
        ACTIVE.clear()
        self.temp=tempfile.TemporaryDirectory(); self.addCleanup(self.temp.cleanup)
        self.work=Path(self.temp.name)
        self.raw=np.full((12,14),10,dtype=np.uint16); self.labels=np.zeros(self.raw.shape,np.int32)
        self.labels[1:3,2:5]=2; self.labels[7:10,8:12]=9
        self.raw[self.labels==2]=110; self.raw[self.labels==9]=210
        np.save(self.work/"raw.npy",self.raw); np.save(self.work/"labels.npy",self.labels)
        self.contract={"schema_version":"1.0","experiment_id":"exp-test","dataset_version":"v1","status":"agreed",
                       "tasks":["instance_segment","morphology","fluorescence","process","restore","track","detect","classify"],
                       "required_evidence":["predictions"]}
        self.save("contract.json",self.contract)
        self.image={"artifact_id":"raw","path":"raw.npy","type":"image","axes":"YX","space_id":"raw-space","intensity_role":"raw","processing_history":[]}
        self.mask={"artifact_id":"mask","path":"labels.npy","type":"instance_masks","axes":"YX","space_id":"raw-space"}
        self.base={"schema_version":"1.0","experiment_id":"exp-test","request_id":"test-001","dataset_version":"v1","mode":"predict",
                   "eval_contract_ref":"contract.json","budget":{"wall_time_seconds":60,"device":"cpu"},"allow_download":False,"params":{}}

    def save(self,name,value):
        p=self.work/name; p.write_text(json.dumps(value),encoding="utf-8"); return p

    def run_req(self,category,req,out="output"):
        ACTIVE[category]=req["implementation_id"]
        return runtime(category).run(self.save("request.json",req),self.work/out)

    def req(self,task,implementation,inputs=None,params=None):
        return {**copy.deepcopy(self.base),"task":task,"implementation_id":implementation,
                "inputs":copy.deepcopy(inputs if inputs is not None else [self.image]),"params":params or {}}

    def test_segmentation_has_real_masks_and_hashes(self):
        r=self.run_req("segmentation",self.req("instance_segment","threshold-cc"))
        self.assertEqual(r["status"],"succeeded"); self.assertEqual(r["summary"]["count"],2)
        a=next(a for a in r["artifacts"] if a["type"]=="instance_masks")
        labels=np.load(a["path"]); self.assertEqual(set(np.unique(labels)),{0,1,2})
        self.assertEqual(sorted([(labels==i).sum() for i in (1,2)]),[6,12])
        for art in r["artifacts"]: self.assertEqual(runtime("segmentation").sha_file(art["path"]),art["sha256"])
        self.assertEqual(r["evaluation_status"],"not_evaluated")

    def test_noncontiguous_ids_and_physical_area(self):
        r=self.run_req("quantification",self.req("morphology","morphology",[self.mask],{"pixel_size_um":[2,.5]}))
        rows=json.loads(Path(r["artifacts"][0]["path"]).read_text())["records"]
        self.assertEqual([x["instance_id"] for x in rows],[2,9]); self.assertEqual([x["area_um2"] for x in rows],[6.,12.])

    def test_exact_intensity_and_negative_background_values(self):
        r=self.run_req("quantification",self.req("fluorescence","fluorescence",[self.image,self.mask],{"background_method":"constant","background_value":150}))
        rows=json.loads(Path(r["artifacts"][0]["path"]).read_text())["records"]
        self.assertEqual([x["mean_background_corrected"] for x in rows],[-40.,60.])
        self.assertEqual([x["integrated_background_corrected"] for x in rows],[-240.,720.])

    def test_global_background(self):
        r=self.run_req("quantification",self.req("fluorescence","fluorescence",[self.image,self.mask],{"background_method":"global_background_median"}))
        rows=json.loads(Path(r["artifacts"][0]["path"]).read_text())["records"]
        self.assertEqual([x["background"] for x in rows],[10.,10.])

    def test_missing_scale_never_fabricates_um(self):
        r=self.run_req("quantification",self.req("morphology","morphology",[self.mask]))
        data=json.loads(Path(r["artifacts"][0]["path"]).read_text())
        self.assertIsNone(data["records"][0]["area_um2"]); self.assertTrue(r["warnings"])

    def test_enhanced_intensity_blocked(self):
        image={**self.image,"intensity_role":"model_input_only"}
        r=self.run_req("quantification",self.req("fluorescence","fluorescence",[image,self.mask]))
        self.assertEqual(r["status"],"blocked")

    def test_false_raw_declaration_caught_by_history(self):
        image={**self.image,"processing_history":[{"operation":"clahe"}]}
        r=self.run_req("quantification",self.req("fluorescence","fluorescence",[image,self.mask]))
        self.assertEqual(r["status"],"blocked")

    def test_coordinate_mismatch_blocked(self):
        mask={**self.mask,"space_id":"cropped"}
        r=self.run_req("quantification",self.req("fluorescence","fluorescence",[self.image,mask]))
        self.assertEqual(r["status"],"blocked")

    def test_mask_must_have_integer_ids(self):
        np.save(self.work/"labels.npy",self.labels.astype(float))
        r=self.run_req("quantification",self.req("morphology","morphology",[self.mask]))
        self.assertEqual(r["status"],"blocked")

    def test_empty_image_and_empty_masks(self):
        np.save(self.work/"raw.npy",np.full((12,14),10))
        r=self.run_req("segmentation",self.req("instance_segment","threshold-cc"))
        self.assertEqual(r["summary"]["count"],0)
        np.save(self.work/"labels.npy",np.zeros((12,14),np.int32))
        r=self.run_req("quantification",self.req("morphology","morphology",[self.mask]),"quant")
        self.assertEqual(r["summary"]["instance_count"],0)

    def test_hash_mismatch_blocked_before_run(self):
        image={**self.image,"sha256":"0"*64}
        with self.assertRaises(ValueError): self.run_req("segmentation",self.req("instance_segment","threshold-cc",[image]))

    def test_eval_contract_required_and_cannot_be_draft(self):
        self.contract["status"]="draft"; self.save("contract.json",self.contract)
        with self.assertRaises(ValueError): self.run_req("segmentation",self.req("instance_segment","threshold-cc"))

    def test_eval_contract_dataset_mismatch(self):
        self.contract["dataset_version"]="v2"; self.save("contract.json",self.contract)
        with self.assertRaises(ValueError): self.run_req("segmentation",self.req("instance_segment","threshold-cc"))

    def test_eval_contract_requires_evidence_list(self):
        self.contract.pop("required_evidence"); self.save("contract.json",self.contract)
        with self.assertRaises(ValueError): self.run_req("segmentation",self.req("instance_segment","threshold-cc"))

    def test_fluorescence_requires_explicit_background_choice(self):
        r=self.run_req("quantification",self.req("fluorescence","fluorescence",[self.image,self.mask]))
        self.assertEqual(r["status"],"blocked")

    def test_explicit_sensor_saturation(self):
        self.raw[self.labels==2]=4095; np.save(self.work/"raw.npy",self.raw)
        req=self.req("fluorescence","fluorescence",[self.image,self.mask],{"background_method":"none","saturation_value":4095})
        r=self.run_req("quantification",req)
        rows=json.loads(Path(r["artifacts"][0]["path"]).read_text())["records"]
        self.assertEqual(rows[0]["saturated_pixels"],6)
        self.assertTrue(any("saturated" in w for w in r["warnings"]))

    def test_wrong_task_rejected(self):
        with self.assertRaises(ValueError): self.run_req("segmentation",self.req("classify","threshold-cc"))

    def test_download_not_implicitly_allowed(self):
        req=self.req("instance_segment","threshold-cc"); req["allow_download"]=True
        with self.assertRaises(ValueError): self.run_req("segmentation",req)

    def test_existing_output_not_overwritten(self):
        req=self.req("instance_segment","threshold-cc"); self.run_req("segmentation",req)
        before=(self.work/"output"/"result.json").read_bytes()
        with self.assertRaises(ValueError): self.run_req("segmentation",req)
        self.assertEqual(before,(self.work/"output"/"result.json").read_bytes())

    def test_native_recipe_does_not_pretend_to_execute(self):
        req=self.req("prompt_segment","sam3"); self.contract["tasks"].append("prompt_segment"); self.save("contract.json",self.contract)
        with self.assertRaisesRegex(ValueError,"No built-in adapter"): self.run_req("segmentation",req)

    def test_processing_default_matches_selected_algorithm(self):
        r=self.run_req("processing",self.req("process","percentile-normalize"))
        arr=np.load(r["artifacts"][0]["path"])
        self.assertGreaterEqual(float(arr.min()),0); self.assertLessEqual(float(arr.max()),1)
        self.assertEqual(r["artifacts"][0]["intensity_role"],"model_input_only")

    def test_implementation_cannot_silently_change_operation(self):
        with self.assertRaises(ValueError): self.run_req("processing",self.req("process","clahe",params={"operation":"identity"}))

    def test_crop_transform_and_pixels(self):
        r=self.run_req("processing",self.req("process","crop",params={"bbox_xyxy":[2,1,5,3]}))
        a=r["artifacts"][0]
        self.assertEqual(a["transform_to_parent"],{"type":"translation","x":2,"y":1})
        self.assertNotEqual(a["space_id"],self.image["space_id"])
        np.testing.assert_array_equal(np.load(a["path"]),self.raw[1:3,2:5])

    def test_opencv_constant_image_filters_preserve_constant(self):
        try: import cv2
        except ImportError: self.skipTest("opencv not installed")
        np.save(self.work/"raw.npy",np.full((12,14),10,dtype=np.uint16))
        for implementation in ["gaussian","median-filter","morph-opening","morph-closing"]:
            r=self.run_req("processing",self.req("process",implementation),implementation)
            self.assertEqual(r["status"],"succeeded")
            np.testing.assert_allclose(np.load(r["artifacts"][0]["path"]),10)
            self.assertEqual(r["artifacts"][0]["intensity_role"],"model_input_only")

    def test_flatfield_reference_and_shape(self):
        np.save(self.work/"flat.npy",np.full(self.raw.shape,100,dtype=np.uint16))
        flat={**self.image,"artifact_id":"flat","path":"flat.npy"}
        req=self.req("process","flatfield",[self.image,flat],{"image_artifact_id":"raw","flat_artifact_id":"flat","calibration_ref":"calibration-01"})
        r=self.run_req("processing",req)
        self.assertEqual(r["status"],"succeeded")
        np.testing.assert_allclose(np.load(r["artifacts"][0]["path"]),self.raw)

    def test_axes_disagreement_is_not_guessed(self):
        np.save(self.work/"raw.npy",np.zeros((3,12,14)))
        r=self.run_req("segmentation",self.req("instance_segment","threshold-cc"))
        self.assertEqual(r["status"],"blocked")

    def test_tracker_keeps_identity(self):
        self.save("detections.json",{"frames":[{"frame_index":0,"detections":[{"bbox_xyxy":[0,0,10,10],"category_id":0}]},{"frame_index":1,"detections":[{"bbox_xyxy":[1,0,11,10],"category_id":0}]}]})
        inp={"artifact_id":"detections","path":"detections.json","type":"detections"}
        r=self.run_req("tracking",self.req("track","iou-tracker",[inp]))
        data=json.loads(Path(r["artifacts"][0]["path"]).read_text())
        self.assertEqual([x["track_id"] for x in data["records"]],[1,1])
        self.assertFalse(data["handles_division"])

    def test_registry_and_standalone_skill(self):
        source=ROOT/"skills"/"cellsight-segmentation-threshold-cc"
        isolated=self.work/"skills"/"cellsight-segmentation-threshold-cc"
        shutil.copytree(source,isolated)
        mod=runtime("segmentation",self.work)
        self.assertEqual(mod.lookup("threshold-cc")["adapter"],"threshold")
        result=mod.probe("threshold-cc")
        self.assertFalse(result["implementations"][0]["ready"])
        # It must work after copying only this one skill, with no sibling library.
        req=self.req("instance_segment","threshold-cc")
        r=mod.run(self.save("standalone.json",req),self.work/"standalone")
        self.assertEqual(r["status"],"succeeded")

    def test_json_schemas_on_real_outputs(self):
        try: import jsonschema
        except ImportError: self.skipTest("jsonschema not installed")
        req=self.req("instance_segment","threshold-cc")
        jsonschema.validate(req,json.loads((ROOT/"schemas"/"request.schema.json").read_text()))
        r=self.run_req("segmentation",req)
        jsonschema.validate(r,json.loads((ROOT/"schemas"/"result.schema.json").read_text()))

    def test_real_torchvision_classification_adapter_without_download(self):
        try:
            import torch
            import torchvision
            from PIL import Image
        except ImportError: self.skipTest("torch/torchvision not installed")
        torch.set_num_threads(1)
        Image.fromarray(np.repeat((self.raw/210*255).astype(np.uint8)[...,None],3,axis=-1)).save(self.work/"rgb.png")
        torch.manual_seed(7)
        net=torchvision.models.resnet18(weights=None,num_classes=2)
        torch.save(net.state_dict(),self.work/"random-state.pt")
        inp={**self.image,"path":"rgb.png","axes":"YXC","intensity_role":"model_input_only"}
        req=self.req("classify","resnet",[inp]); req["model"]={"weights_path":"random-state.pt","architecture":"resnet18","classes":["a","b"],"input_size":64,"mean":[0,0,0],"std":[1,1,1]}
        r=self.run_req("classification",req)
        self.assertEqual(r["status"],"succeeded")
        records=json.loads(Path(r["artifacts"][0]["path"]).read_text())["records"]
        self.assertAlmostEqual(sum(x["score"] for x in records),1,places=5)
        self.assertEqual(r["scientific_validation"],"not_established")


if __name__=="__main__": unittest.main(verbosity=2)
