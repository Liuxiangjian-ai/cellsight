"""Software checks with hand-written scalar/label fixtures. No image/CV/LLM runs."""
from pathlib import Path
import copy
import json
import subprocess
import sys
import tempfile
import unittest

OUT = Path(__file__).resolve().parents[1]
SKILL = OUT/'skills/cellsight-evaluation'
sys.path.insert(0, str(SKILL/'scripts'))
import cs_meta as meta
import meta_state
import cs_state
from metric_core import load, write, sha, seal, digest, score, aggregate


class MetaTests(unittest.TestCase):
    def setUp(self):
        scratch = Path.cwd()/'work'
        scratch.mkdir(exist_ok=True)
        self.tmp = tempfile.TemporaryDirectory(dir=scratch, prefix='cellsight-meta-test-')
        self.addCleanup(self.tmp.cleanup)
        self.w = Path(self.tmp.name)
        self.registry = self.w/'registry.json'
        meta.registry_init(self.registry)
        self.brief = load(SKILL/'assets/examples/brief-ratio.json')
        self.values = load(SKILL/'assets/examples/ratio-values.json')

    def save(self, name, value):
        return write(self.w/name, value)

    def freeze(self, brief=None):
        s = meta.build_spec(brief or self.brief, self.registry)
        return self.save('frozen.json', meta.freeze(s, self.registry))

    def classify(self):
        b = copy.deepcopy(self.brief)
        b.update(task_type='classification', requirements=[{'id': 'classify', 'capability': 'classification_metrics', 'required': True,
            'definition': meta.definition('classify', 'classification', {'classes': ['A', 'B'], 'positive_class': 'B', 'zero_division': 0})}])
        payload = {**self.values, 'values': {}, 'predictions': [
            {'sample_id': '1', 'label': 'A'}, {'sample_id': '2', 'label': 'A'}, {'sample_id': '3', 'label': 'B'}]}
        labels = {'task_id': b['task_id'], 'dataset_version': b['dataset_version'], 'role': 'development',
                  'source': 'handwritten unit-test labels, not cell data', 'records': [
                      {'sample_id': '1', 'label': 'A'}, {'sample_id': '2', 'label': 'B'}, {'sample_id': '3', 'label': 'B'}]}
        return b, payload, labels

    def generated(self):
        d = load(SKILL/'assets/examples/custom-range-definition.json')
        root = self.w/'custom'
        meta.generate('cellsight-eval-test-range', d, root)
        return d, root

    def project(self, spec_path):
        s = load(spec_path)
        b = {'schema_version': '1.0', 'experiment_id': s['task_id'], 'dataset_version': s['dataset_version'], 'goal': s['goal'],
             'budget': {'wall_time_seconds': 60, 'device': 'cpu'}, 'limits': {'max_revisions': 1}, 'required_eval_stages': ['preflight', 'final']}
        p = self.w/'project'
        cs_state.start(self.save('project-brief.json', b), p)
        meta_state.attach(p, spec_path)
        return p

    def test_case1_standard_detection_reuses_without_generating(self):
        b = {**self.brief, 'task_type': 'detection', 'requirements': []}
        s = meta.build_spec(b, self.registry)
        self.assertEqual(s['decision'], 'REUSE')
        self.assertEqual(len(s['items']), 1)
        self.assertFalse(list(self.w.glob('**/SKILL.md')))

    def test_case2_classification_known_hand_calculated_metrics(self):
        b, p, labels = self.classify()
        report = meta.evaluate(self.freeze(b), self.registry, self.save('pred.json', p), private_labels_path=self.save('labels.json', labels))
        self.assertEqual(report['status'], 'PASS')
        metrics = report['items'][1]['metrics']
        self.assertAlmostEqual(metrics['accuracy'], 2/3)
        self.assertAlmostEqual(metrics['macro_f1'], 2/3)
        self.assertEqual(metrics['precision'], 1)
        self.assertEqual(metrics['recall'], 0.5)

    def test_case3_ambiguous_damage_definition_stays_draft(self):
        b = {**self.brief, 'scientific_questions': ['损伤的生物学定义是什么？', '分母和排除规则是什么？']}
        s = meta.build_spec(b, self.registry)
        self.assertEqual(s['status'], 'DRAFT')
        with self.assertRaisesRegex(ValueError, 'scientific questions'):
            meta.freeze(s, self.registry)

    def test_case3_ratio_composes_and_detects_wrong_report(self):
        path = self.freeze()
        p = copy.deepcopy(self.values)
        p['values']['reported_ratio'] = 0.8
        report = meta.evaluate(path, self.registry, self.save('wrong.json', p))
        self.assertEqual(load(path)['decision'], 'COMPOSE')
        self.assertEqual(report['status'], 'FAIL')
        self.assertEqual(report['items'][1]['metrics']['ratio'], 0.5)
        self.assertEqual(report['recommendation']['action'], 'REVISE')

    def test_case4_generate_validate_activate_and_review_range(self):
        d, root = self.generated()
        b = {**self.brief, 'requirements': [{'id': d['id'], 'capability': 'field_range', 'required': True, 'definition': d}]}
        draft = meta.build_spec(b, self.registry)
        self.assertEqual(draft['decision'], 'GENERATE')
        validation = meta.validate_bundle(root)
        self.assertEqual(validation['structure'], 'PASS')
        self.assertEqual(validation['metric_definition'], 'PASS')
        self.assertEqual(validation['executability'], 'PASS')
        self.assertEqual(validation['tests_executed'], 3)
        self.assertEqual(validation['scientific_validity'], 'NOT_EVALUABLE')
        meta.register(self.registry, root)
        meta.activate_template(self.registry, 'cellsight-eval-test-range')
        resolved = meta.resolve(draft, self.registry)
        path = self.save('generated-frozen.json', meta.freeze(resolved, self.registry))
        p = {**self.values, 'values': {'intensity': 15, 'unit': 'a.u.'}}
        report = meta.evaluate(path, self.registry, self.save('range.json', p))
        self.assertEqual(report['status'], 'NEEDS_REVIEW')

    def test_case5_wrong_denominator_is_rejected(self):
        d = copy.deepcopy(self.brief['requirements'][0]['definition'])
        d['parameters']['denominator_path'] = d['parameters']['numerator_path']
        with self.assertRaisesRegex(ValueError, 'distinct'):
            meta.generate('cellsight-eval-invalid-ratio', d, self.w/'bad')
        self.assertFalse((self.w/'bad').exists())

    def test_case5_missing_class_definition_rejected(self):
        with self.assertRaisesRegex(ValueError, 'class names'):
            meta.definition('c', 'classification', {'zero_division': 0})

    def test_case6_uploaded_self_ready_still_pending(self):
        _, root = self.generated()
        m = load(root/'manifest.json')
        m['source']['origin'] = 'uploaded'
        m.update(availability='ready', validation_status='template_verified')
        write(root/'manifest.json', m)
        registered = meta.register(self.registry, root)
        self.assertEqual(registered['manifest']['availability'], 'pending_installation')
        self.assertEqual(registered['manifest']['validation_status'], 'unverified')
        self.assertFalse(meta.ready(registered))

    def test_case7_missing_gt_is_not_accuracy(self):
        b, p, _ = self.classify()
        report = meta.evaluate(self.freeze(b), self.registry, self.save('unlabelled.json', p))
        self.assertEqual(report['status'], 'NOT_EVALUABLE')
        self.assertEqual(report['items'][1]['metrics'], {})

    def test_ratio_empty_population_is_not_evaluable(self):
        p = copy.deepcopy(self.values)
        p['values'].update(positive_count=0, eligible_count=0, reported_ratio=0)
        report = meta.evaluate(self.freeze(), self.registry, self.save('empty.json', p))
        self.assertEqual(report['status'], 'NOT_EVALUABLE')

    def test_negative_or_excessive_subset_is_error(self):
        d = self.brief['requirements'][0]['definition']
        for n in (-1, 3, True):
            p = copy.deepcopy(self.values)
            p['values']['positive_count'] = n
            self.assertEqual(score(d, p)['status'], 'ERROR')

    def test_no_threshold_source_is_rejected(self):
        d = load(SKILL/'assets/examples/custom-range-definition.json')
        d.pop('threshold_source')
        with self.assertRaisesRegex(ValueError, 'traceable'):
            meta.generate('cellsight-eval-no-source', d, self.w/'bad')

    def test_unknown_python_expression_is_not_generated(self):
        d = copy.deepcopy(self.brief['requirements'][0]['definition'])
        d['parameters']['expression'] = '__import__("os").system("example")'
        with self.assertRaises(ValueError):
            meta.generate('cellsight-eval-no-exec', d, self.w/'bad')

    def test_third_party_script_never_executed(self):
        _, root = self.generated()
        marker = self.w/'must-not-exist'
        (root/'scripts/evaluate.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').touch()\n', encoding='utf-8')
        report = meta.validate_bundle(root)
        self.assertEqual(report['status'], 'ERROR')
        self.assertEqual(report['tests_executed'], 0)
        self.assertFalse(marker.exists())

    def test_extra_python_module_cannot_shadow_imports(self):
        _, root = self.generated()
        marker = self.w/'shadow-import-must-not-run'
        (root/'scripts/json.py').write_text('from pathlib import Path\nPath('+repr(str(marker))+').touch()\n', encoding='utf-8')
        report = meta.validate_bundle(root)
        self.assertEqual(report['status'], 'ERROR')
        self.assertEqual(report['tests_executed'], 0)
        self.assertFalse(marker.exists())

    def test_template_mutation_invalidates_readiness(self):
        _, root = self.generated()
        meta.register(self.registry, root)
        meta.activate_template(self.registry, 'cellsight-eval-test-range')
        row = meta.registry_read(self.registry)['entries'][-1]
        self.assertTrue(meta.ready(row))
        (root/'references/rubric.md').write_text('changed documentary note', encoding='utf-8')
        # Semantics/code unchanged; definition/source mutation must invalidate readiness.
        d = load(root/'definition.json')
        d['acceptance']['max'] = 100
        write(root/'definition.json', d)
        self.assertFalse(meta.ready(row))

    def test_duplicate_registration_rejected(self):
        _, root = self.generated()
        meta.register(self.registry, root)
        with self.assertRaisesRegex(ValueError, 'Duplicate'):
            meta.register(self.registry, root)

    def test_draft_cannot_evaluate(self):
        s = meta.build_spec(self.brief, self.registry)
        with self.assertRaisesRegex(ValueError, 'frozen'):
            meta.evaluate(self.save('draft.json', s), self.registry, self.save('in.json', self.values))

    def test_frozen_spec_tamper_rejected(self):
        path = self.freeze()
        s = load(path)
        s['requirements'][1]['definition']['parameters']['denominator_definition'] = 'changed'
        write(path, s)
        with self.assertRaisesRegex(ValueError, 'mismatch'):
            meta.evaluate(path, self.registry, self.save('in.json', self.values))

    def test_missing_or_changed_artifact_is_error(self):
        b = {**self.brief, 'required_outputs': ['table']}
        path = self.freeze(b)
        report = meta.evaluate(path, self.registry, self.save('missing.json', self.values))
        self.assertEqual(report['status'], 'ERROR')
        table = self.w/'table.csv'
        table.write_text('n,value\n1,0.5\n', encoding='utf-8')
        p = copy.deepcopy(self.values)
        p['artifacts'] = [{'artifact_id': 'table', 'type': 'table', 'path': 'table.csv', 'sha256': sha(table)}]
        valid = meta.evaluate(path, self.registry, self.save('present.json', p))
        self.assertEqual(valid['status'], 'PASS')
        table.write_text('modified', encoding='utf-8')
        self.assertEqual(meta.evaluate(path, self.registry, self.w/'present.json')['status'], 'ERROR')

    def test_label_sample_mismatch_is_not_silently_dropped(self):
        b, p, labels = self.classify()
        labels['records'].pop()
        report = meta.evaluate(self.freeze(b), self.registry, self.save('pred.json', p), private_labels_path=self.save('labels.json', labels))
        self.assertEqual(report['status'], 'ERROR')

    def test_duplicate_classification_sample_rejected(self):
        b, p, labels = self.classify()
        p['predictions'].append(p['predictions'][0])
        report = meta.evaluate(self.freeze(b), self.registry, self.save('pred.json', p), private_labels_path=self.save('labels.json', labels))
        self.assertEqual(report['status'], 'ERROR')

    def test_final_test_report_never_feeds_planner(self):
        b, p, labels = self.classify()
        labels['role'] = 'final_test'
        frozen = self.freeze(b)
        report = meta.evaluate(frozen, self.registry, self.save('pred.json', p), private_labels_path=self.save('labels.json', labels))
        self.assertEqual(report['source_type'], 'external_benchmark')
        self.assertFalse(any(e.get('path') == str(self.w/'labels.json') for e in report['evidence']))
        with self.assertRaisesRegex(ValueError, 'Final-test'):
            meta.feedback(report, load(frozen))

    def test_rubric_without_provider_is_not_evaluable(self):
        d = meta.definition('rubric', 'rubric', {'rubric': ['结论引用实际证据'], 'required_evidence': ['input_sha256']})
        b = {**self.brief, 'requirements': [{'id': 'rubric', 'capability': 'scientific_reporting', 'required': True, 'definition': d}]}
        report = meta.evaluate(self.freeze(b), self.registry, self.save('input.json', self.values))
        self.assertEqual(report['status'], 'NOT_EVALUABLE')

    def test_rubric_judge_without_valid_citation_needs_review(self):
        d = meta.definition('rubric', 'rubric', {'rubric': ['引用实际证据'], 'required_evidence': ['input']})
        output = score(d, self.values, judge=lambda r: {'status': 'PASS', 'provider': 'test-stub', 'model': 'not-real-llm',
                      'rationale': 'stub', 'evidence_sha256s': ['0'*64]}, evidence=[{'kind': 'input', 'sha256': '1'*64}])
        self.assertEqual(output['status'], 'NEEDS_REVIEW')

    def test_required_missing_check_cannot_average_into_pass(self):
        self.assertEqual(aggregate([{'status': 'PASS'}, {'status': 'NOT_EVALUABLE'}]), 'NOT_EVALUABLE')
        self.assertEqual(aggregate([{'status': 'PASS'}, {'status': 'FAIL', 'required': False}]), 'PASS')
        self.assertEqual(aggregate([]), 'NOT_EVALUABLE')

    def test_report_cannot_omit_failed_criterion_or_relabel_status(self):
        path = self.freeze()
        report = meta.evaluate(path, self.registry, self.save('input.json', self.values))
        report['items'].pop()
        report.pop('report_hash')
        forged = seal(report, 'report_hash')
        with self.assertRaisesRegex(ValueError, 'omitted'):
            meta.feedback(forged, load(path))

    def test_rubric_required_evidence_is_not_optional(self):
        d = meta.definition('r', 'rubric', {'rubric': ['inspect mask'], 'required_evidence': ['instance_mask']})
        report = score(d, self.values, judge=lambda _: self.fail('Judge must not run without required evidence'),
                       evidence=[{'kind': 'evaluation_input', 'sha256': '1'*64}])
        self.assertEqual(report['status'], 'NOT_EVALUABLE')

    def test_plan_binding_checks_dependency_budget_and_output(self):
        frozen = self.freeze()
        proposal = {'task_id': self.brief['task_id'], 'dataset_version': self.brief['dataset_version'], 'steps': [
            {'step_id': 'quantify', 'skill_id': 'cellsight-quantification-morphology', 'version': '0.2.1', 'task': 'morphology',
             'mode': 'predict', 'depends_on': [], 'inputs': ['user-input'], 'output_types': ['table'], 'wall_time_seconds': 20}]}
        plan = meta.bind_plan(frozen, proposal)
        self.assertEqual(plan['status'], 'READY_FOR_HOST_CHECK')
        self.assertFalse(plan['execution_performed'])
        for mutation in ('budget', 'cycle', 'labels'):
            p = copy.deepcopy(proposal)
            if mutation == 'budget': p['steps'][0]['wall_time_seconds'] = 100
            if mutation == 'cycle': p['steps'][0]['depends_on'] = ['quantify']
            if mutation == 'labels': p['private_labels'] = '/not-allowed'
            with self.assertRaises(ValueError): meta.bind_plan(frozen, p)

    def test_state_records_recovers_and_counts_report_once(self):
        frozen = self.freeze()
        project = self.project(frozen)
        rp = self.w/'report.json'
        meta.evaluate(frozen, self.registry, self.save('values.json', self.values), rp)
        meta_state.record(project, rp)
        before = meta_state.status(project)
        meta_state.record(project, rp)
        after = meta_state.status(project)
        self.assertEqual(len(after['reports']), 1)
        self.assertEqual(before['spent_seconds'], after['spent_seconds'])
        report = load(rp)
        report['status'] = 'FAIL'
        write(rp, report)
        with self.assertRaisesRegex(ValueError, 'changed'): meta_state.status(project)

    def test_state_revision_limit_and_budget_are_preserved(self):
        frozen = self.freeze()
        project = self.project(frozen)
        p = copy.deepcopy(self.values)
        p['values']['reported_ratio'] = 0.7
        rp = self.w/'failure.json'
        meta.evaluate(frozen, self.registry, self.save('bad.json', p), rp)
        meta_state.record(project, rp)
        meta_state.reserve_revision(project, rp)
        self.assertEqual(meta_state.status(project)['revisions'], 1)
        with self.assertRaisesRegex(ValueError, 'limit'): meta_state.reserve_revision(project, rp)
        cs_state.record_cost(project, 61, 'Bookkeeping test, not a CV job')
        self.assertEqual(meta_state.status(project)['next_action'], 'BUDGET_EXHAUSTED')

    def test_meta_stop_preserves_external_cancellation_boundary(self):
        frozen = self.freeze()
        project = self.project(frozen)
        cs_state.stop(project, 'stop test')
        self.assertEqual(meta_state.status(project)['next_action'], 'STOPPED')

    def test_cli_build_freeze_evaluate_works_from_other_cwd(self):
        import os
        env = dict(os.environ, PYTHONUTF8='1', PYTHONDONTWRITEBYTECODE='1')
        cli = SKILL/'scripts/eval_meta.py'
        def run(*args):
            p = subprocess.run([sys.executable, '-B', str(cli), *map(str, args)], cwd=self.w,
                               env=env, capture_output=True, text=True, encoding='utf-8', timeout=20)
            self.assertEqual(p.returncode, 0, p.stderr)
        run('build-spec', '--brief', SKILL/'assets/examples/brief-ratio.json', '--registry', self.registry, '--output', self.w/'cli-draft.json')
        run('freeze', '--spec', self.w/'cli-draft.json', '--registry', self.registry, '--output', self.w/'cli-frozen.json')
        run('evaluate', '--spec', self.w/'cli-frozen.json', '--registry', self.registry, '--input', SKILL/'assets/examples/ratio-values.json', '--output', self.w/'cli-report.json')
        self.assertEqual(load(self.w/'cli-report.json')['status'], 'PASS')

    def test_prefreeze_discovery_does_not_change_scientific_requirements(self):
        draft = meta.build_spec(self.brief, self.registry)
        before = digest(draft)
        candidates = meta.discover(self.registry, 'evaluation', self.brief['task_type'], self.brief['domain'])
        self.assertTrue(candidates['candidates'])
        self.assertFalse(candidates['scientific_criteria_changed'])
        self.assertEqual(digest(draft), before)
        self.assertEqual(draft['status'], 'DRAFT')
        self.assertTrue(all(not c['host_mount_verified'] for c in candidates['candidates']))

    def test_discovery_includes_unavailable_execution_declarations_without_promoting_them(self):
        root = self.w/'uploaded-detector'
        root.mkdir()
        m = meta.manifest('cellsight-detection-yolo', 'ratio', origin='uploaded', task='detect')
        m.update(type='execution')
        m['capabilities'] = {'tasks': ['detect'], 'methods': ['yolo'], 'modes': ['predict']}
        m['entrypoint'] = {'kind': 'host_skill', 'name': m['id']}
        write(root/'manifest.json', m)
        (root/'SKILL.md').write_text('---\nname: '+m['id']+'\ndescription: fixture only\n---\n', encoding='utf-8')
        meta.register(self.registry, root)
        snapshot = sha(self.registry)
        result = meta.discover(self.registry, 'execution', 'detect', self.brief['domain'])
        self.assertEqual(len(result['candidates']), 1)
        self.assertEqual(result['candidates'][0]['manifest']['availability'], 'pending_installation')
        self.assertFalse(result['candidates'][0]['local_handler_ready'])
        self.assertEqual(snapshot, sha(self.registry))

    def test_valid_spec_does_not_certify_evaluator_readiness(self):
        d = load(SKILL/'assets/examples/custom-range-definition.json')
        b = {**self.brief, 'requirements': [{'id': d['id'], 'capability': 'field_range', 'required': True, 'definition': d}]}
        draft = meta.build_spec(b, self.registry)
        report = meta.validate_specification(draft)
        self.assertEqual(report['specification_validation'], 'PASS')
        self.assertFalse(report['evaluator_readiness_checked'])
        self.assertEqual(draft['decision'], 'GENERATE')
        with self.assertRaisesRegex(ValueError, 'unavailable'):
            meta.freeze(draft, self.registry)

    def test_generated_rubric_missing_judge_is_not_ready_after_launcher_trial(self):
        d = meta.definition('new-rubric', 'rubric', {'rubric': ['Check stated assay criterion'], 'required_evidence': ['evaluation_input']},
                            basis={'status': 'needs_expert_review', 'reference': 'New specialist rubric without external validation'})
        root = self.w/'new-rubric'
        meta.generate('cellsight-eval-new-rubric', d, root)
        report = meta.validate_bundle(root)
        self.assertEqual(report['structure'], 'PASS')
        self.assertEqual(report['launcher_trial'], 'PASS')
        self.assertEqual(report['evaluation_trial'], 'NOT_EVALUABLE')
        self.assertEqual(report['executability'], 'NOT_EVALUABLE')
        meta.register(self.registry, root)
        with self.assertRaisesRegex(ValueError, 'not executable'):
            meta.activate_template(self.registry, 'cellsight-eval-new-rubric')
        self.assertEqual(meta.registry_read(self.registry)['entries'][-1]['manifest']['availability'], 'pending_installation')

    def test_no_gt_allows_minimal_prediction_plan_without_weakening_accuracy_requirement(self):
        b, payload, _ = self.classify()
        b['requirements'][0]['definition']['acceptance'] = {'recall': 0.95}
        b['requirements'][0]['definition']['threshold_source'] = {'kind': 'user_requirement', 'reference': 'User requests Recall >= 0.95'}
        frozen = self.freeze(b)
        spec = load(frozen)
        proposal = {'task_id': b['task_id'], 'dataset_version': b['dataset_version'], 'steps': [
            {'step_id': 'predict', 'skill_id': 'cellsight-classification-resnet', 'version': '0.2.1', 'task': 'classify',
             'mode': 'predict', 'depends_on': [], 'inputs': ['user-input'], 'output_types': ['predictions'], 'wall_time_seconds': 20}]}
        plan = meta.bind_plan(frozen, proposal)
        self.assertEqual(len(plan['steps']), 1)
        self.assertFalse(plan['execution_performed'])
        self.assertEqual(spec['items'][1]['definition']['acceptance']['recall'], 0.95)
        report = meta.evaluate(frozen, self.registry, self.save('prediction-records.json', payload))
        self.assertEqual(report['status'], 'NOT_EVALUABLE')
        self.assertEqual(load(frozen)['spec_hash'], spec['spec_hash'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
