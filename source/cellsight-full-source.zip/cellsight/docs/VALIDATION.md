# 整理验证记录

日期：2026-11-01。此记录来自本次新整理仓库的实际本地检查，不沿用历史测试结果。

| 项目 | 本次结果 |
|---|---|
| 独立 Skill 入口与名称 | 73 / 73，通过；2 个控制 + 71 个执行 |
| 执行类别与能力目录 | 12 类；Registry、Catalog、两份控制包副本一致 |
| 独立上传包 | 73 / 73；共 1172 个资源条目与当前源码逐字节一致 |
| 继承文件来源 | 1184 个文件有相对来源与源 SHA256；仅测试/例子的目录引用有整理转换 |
| Skill 业务源码 | 73 个 Skill 全部保留选定源文件字节 |
| JSON、Python 与本地文档链接 | 全部通过仓库校验脚本 |
| 常见凭证与个人绝对路径模式 | 在发布文本文件内未发现匹配项 |
| 软件回归 | **76 项通过，0 跳过，0 失败，0 错误**；用时 29.852 秒 |
| 数值工作流示例 | 运行完成；错误比例 FAIL → 修正后 PASS，缺 GT 为 NOT_EVALUABLE |
| 原生配方与适配器区别 | 34 个执行条目带适配器，37 个为原生配方；没有将其冒称全部已运行 |

测试使用 Python 3.12.0、numpy 2.3.2、Pillow 11.3.0、jsonschema 4.26.0、torch 2.11.0、torchvision 0.26.0。OpenCV 数组滤波测试实际通过；分类适配器使用本地随机权重，不下载预训练模型。

完整命令与可机器读取结果见 [validation-results.json](validation-results.json)。源码校验命令为 `python scripts/validate_repository.py`；完整测试命令为 `python -B -m unittest discover -s tests -p 'test_*.py' -v`。

本次未实测 SciencePal 导入、真实宿主加载轨迹、全部 71 模型的依赖和权重、真实细胞科学性能、远程 GitHub 发布或 GitHub 托管 CI。生成的范围评价例仍正确保留科学 NEEDS_REVIEW，不因软件通过改变科学状态。凭证模式扫描不覆盖所有可能的敏感信息类型。

最终源码 ZIP 由 `scripts/package_repository.py` 在仓库检查通过后生成，执行 CRC 检查，并将全部归档条目与仓库发布文件逐字节比较；整体 SHA256 另附在交付 ZIP 旁。
