# 上传到 GitHub

推荐仓库名：`cellsight`。建议描述：`清灵之眼：面向科学计算机视觉的 73 个独立 Skills，包含规划、评价与 71 个执行能力。`

本交付已经准备好仓库目录和上传 ZIP，没有创建远程仓库或推送账号数据。先在 GitHub 创建空仓库，使用自己的实际远程地址；不要预先生成另一份 README。是否公开、发布到哪个账号以及采用何种许可证由作者确定。

## 用 Git 上传（适合本仓库文件数量）

在解压后的 `cellsight` 根目录打开终端。若当前目录尚未初始化：

```bash
git init -b main
```

然后执行：

```bash
python scripts/validate_repository.py
git add .
git commit -m "Add CellSight core with 73 independent skills"
git remote add origin https://github.com/YOUR_ACCOUNT/cellsight.git
git push -u origin main
```

`YOUR_ACCOUNT` 是占位符，替换为自己创建的仓库地址；已有 origin 时使用 `git remote set-url origin`。通过 Git 自己的认证机制登录，不把 token 或密码写入仓库。仓库根 `.gitignore` 会排除虚拟环境、缓存、本地工作目录、常见凭证文件和模型权重。合成的 `.npy`/`.png` 测试资源与 73 个独立 Skill ZIP 应随源码保留。

## 源码 ZIP 与独立 Skill ZIP 的区别

外层 `cellsight-github-20261101.zip` 是整个仓库的源码交付，解压后上传其中的仓库文件；不要只把外层 ZIP 上传成 GitHub 的唯一文件。仓库内 `upload-zips/` 的 73 个文件用于向 SciencePal 导入单个 Skill，也可作为后续 GitHub Release 资产。

提供的 `.sha256` 文件用于核验整个交付 ZIP；`artifact-manifest.json` 用于逐文件核验源码，`upload-zips/SHA256SUMS` 用于核验独立上传包。

源码修改后，先更新说明和验证记录，再运行 `python scripts/package_skills.py` 和 `python scripts/update_manifest.py`。完整交付可重建为新文件：`python scripts/package_repository.py --output ../cellsight-source-new.zip`。该工具会先验证仓库，再打包并逐文件核对 ZIP 字节，排除本地环境、Git 元数据和运行工作目录。
