# 安装与宿主接入

## 宿主配置

本仓库是 Skill 资源集合与本地参考工具，不是独立聊天服务。宿主须提供实际的 Skill 加载、文件访问和执行能力。使用 `system-prompt/CellSight-System-Prompt.txt`；将两个控制 Skill 与 71 个执行 Skill 分别导入。不要额外导入旧版 `cellsight-orchestration` 或历史分类父 Skill，否则不再是本仓库的 73 项布局。

静态检索索引是 `system-prompt/CellSight-Skill-Catalog.json`，执行目录是 `registry/expert-registry.json`。控制 Skill 各自保留相同的 `assets/execution-registry.json` 以支持独立分发。目录中 `skills/...` 与 `upload-zips/...` 是集合根目录的逻辑路径，不意味着宿主会在单包中自动安装其他能力。

先核实每个所需 Skill 的实际加载接口、依赖、输入轴/通道、坐标、权重、设备、预算和权限。没有实际入口时保留结构化交接，不把计划当作执行。仓库打包检查不能替代宿主导入测试。

## 本地运行

基础依赖为 `requirements.txt`，用于 Meta Runtime 和轻量工具；完整软件回归使用 `requirements-test.txt`。这两份文件没有安装 71 个专家的全部模型依赖。每个专家的安装与原生 API 说明见其 `references/model-guide.md` 和 `assets/implementations.json`。在独立环境按实际需求安装对应框架，权重由使用者按来源与许可配置。

```bash
python skills/cellsight-evaluation/scripts/eval_meta.py --help
python skills/cellsight-detection-yolo/scripts/run.py list
python skills/cellsight-detection-yolo/scripts/run.py probe --implementation yolo
```

`probe` 只发现模块，不能证明设备、权重或科研性能可用。示例请求中的路径是占位或合成样例，应替换为真实输入；不同专家的请求字段以各自 Schema 为准。

## 规范与协议

新默认入口为 Evaluation Specification 和 `eval_meta.py`；旧版 2.0 Contract、`plan.py`、`coordinate.py`、`cs_state.py` 为兼容而保留，不能将旧 CLI 当作新版 Spec 自动执行器。参见两个控制 Skill 的 `references/meta-runtime.md`、`runtime.md` 和 `release-scope.md`。

正式执行前保存规范，正式计划随后生成；无 GT 时可执行满足条件的预测，监督指标保留 NOT_EVALUABLE。不能用 QA、模型置信度或同一 LLM 的自评代替准确率。宿主加载门槛为指令约束，没有新增 OS 沙箱或强制门禁。
