# 来源、版本与范围

本集合整理于 2026-11-01，建议仓库名 `cellsight`。这不是重新发布模型性能结论，也不改变已有组件的版本号。

| 组件 | 选用交付目录 | 处理 |
|---|---|---|
| 71 个执行 Skill、执行 Registry、Schema | `cellsight-experts-v0.2.1` | 逐文件原样复制 |
| Planner 与 Evaluation | `cellsight-control-loading-patch-v1.1.1` | 完整独立包原样复制 |
| System Prompt | `cellsight-control-loading-patch-v1.1.1` | 使用补丁全文 |
| 静态 Skill Catalog | `cellsight-evaluation-meta-v0.5.1/system-prompt` | 原样复制；数量仍为 73 |
| Meta 与兼容接口测试、数值例 | `cellsight-evaluation-meta-v0.5.1` | 仅将资源位置改为仓库 `skills/` |
| 执行回归 | `cellsight-experts-v0.2.1/tests/test_execution.py` | 原样复制 |

核对补丁目录与 v0.5.1：两个控制包仅 `SKILL.md` 文本不同，其运行脚本、Schema 和资源与原 v0.5.1 一致。补丁版本 v1.1.1 是指令补丁版本，不是 Runtime 升级版本。Catalog 保留其原始版本声明，补丁来源由本文件记录。

`registry/source-provenance.json` 记录每个继承文件在用户指定 outputs 目录内的相对来源、源 SHA256 和整理转换；不记录个人绝对路径。`artifact-manifest.json` 记录当前仓库文件哈希，不包含自身及本地运行产物。ZIP 均从本仓库源码重新生成。

排除：旧控制包、旧分类集合、独立旧 Orchestration、旧规划协商测试、旧验证结果、实验/GT/预测记录、用户附件、视频、BGM、交接索引、历史 ZIP 和工作区缓存。旧 `test_planner.py` 依赖已废弃的 planning 布局，本集合以 v0.5.1 控制接口测试覆盖当前版本，不混入该旧布局。

新增的文件为 README、docs、requirements、Git 忽略规则、CI、仓库校验/打包工具及本次验证记录。未修改 73 个 Skill 的业务源码和科研定义。软件回归通过不证明 SciencePal 全链路、73 项全部运行或科学有效性。
