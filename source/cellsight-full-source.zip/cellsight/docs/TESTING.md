# 软件验证

在仓库根目录使用 Python 3.12。运行测试前可先执行静态检查，静态检查只使用标准库：

```bash
python scripts/validate_repository.py
python -m pip install -r requirements-test.txt
python -B -m unittest discover -s tests -p 'test_*.py' -v
python -B examples/run_numeric_examples.py --output work/numeric-example-001
```

测试中的数组、分类标签、随机权重来自明确的软件样例。torchvision 分类测试以 `weights=None` 构建小型网络并保存随机状态，不下载预训练权重，也不证明分类能力。OpenCV 或 torch 等缺失时，部分原测试会跳过；查看实际输出中的 skip 数量，不能把有跳过说成全部适配器已测。

Meta 回归覆盖 Spec 生成/冻结、Reuse/Compose/Generate、标签绑定、科学待审状态、缺 Judge 与结构校验等；兼容接口回归检查状态、预算和篡改检测；执行回归检查真实数组计算、坐标/单位/强度约束、请求校验和受限分类适配器。

仓库检查覆盖 73 个独立入口、名称唯一性、71 项执行 Registry、12 类标签、控制包目录副本一致性、Python 语法、JSON 解析、Skill 内本地文档链接、源码与 73 个上传 ZIP 的逐字节一致性、常见凭证和个人绝对路径模式，以及文件清单哈希。扫描有明确模式范围，不是对任意敏感内容的绝对保证。

上传包重建：`python scripts/package_skills.py`；修改文件并更新验证记录后，运行 `python scripts/update_manifest.py`，再执行仓库检查。CI 自动执行静态检查与完整软件回归；宿主导入、真实模型和科学域验证需另行进行。
