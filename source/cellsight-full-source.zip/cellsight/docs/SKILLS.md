# 73 个 Skill 目录与独立上传清单

每一项均为平级独立包；34 个执行 Skill 含计算适配器，37 个提供原生配方。适配器存在不表示已经安装、具备权重或验证科研性能。

## 控制入口

| Skill | 上传包 |
|---|---|
| [cellsight-planner](../skills/cellsight-planner/SKILL.md) | [cellsight-planner.zip](../upload-zips/cellsight-planner.zip) |
| [cellsight-evaluation](../skills/cellsight-evaluation/SKILL.md) | [cellsight-evaluation.zip](../upload-zips/cellsight-evaluation.zip) |

## 12 类执行能力

| 类别 | 数量 |
|---|---|
| 目标检测 / detection | 11 |
| 图像分割 / segmentation | 13 |
| 图像分类 / classification | 7 |
| 目标追踪 / tracking | 4 |
| 图像处理 / processing | 10 |
| 图像复原 / restoration | 6 |
| 视觉语言与特征 / vision-language | 5 |
| 科学定量 / quantification | 4 |
| 异常与缺陷检测 / anomaly | 3 |
| 关键点与姿态 / pose | 3 |
| 图像文字识别 / ocr | 3 |
| 深度估计 / depth | 2 |

## 目标检测（11）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-detection-yolo](../skills/cellsight-detection-yolo/SKILL.md) | `yolo` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-yolo.zip) |
| [cellsight-detection-rtdetr](../skills/cellsight-detection-rtdetr/SKILL.md) | `rtdetr` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-rtdetr.zip) |
| [cellsight-detection-fasterrcnn](../skills/cellsight-detection-fasterrcnn/SKILL.md) | `fasterrcnn` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-fasterrcnn.zip) |
| [cellsight-detection-retinanet](../skills/cellsight-detection-retinanet/SKILL.md) | `retinanet` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-retinanet.zip) |
| [cellsight-detection-fcos](../skills/cellsight-detection-fcos/SKILL.md) | `fcos` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-fcos.zip) |
| [cellsight-detection-ssdlite](../skills/cellsight-detection-ssdlite/SKILL.md) | `ssdlite` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-ssdlite.zip) |
| [cellsight-detection-rf-detr](../skills/cellsight-detection-rf-detr/SKILL.md) | `rf-detr` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-detection-rf-detr.zip) |
| [cellsight-detection-deimv2](../skills/cellsight-detection-deimv2/SKILL.md) | `deimv2` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-detection-deimv2.zip) |
| [cellsight-detection-d-fine](../skills/cellsight-detection-d-fine/SKILL.md) | `d-fine` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-detection-d-fine.zip) |
| [cellsight-detection-grounding-dino](../skills/cellsight-detection-grounding-dino/SKILL.md) | `grounding-dino` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-detection-grounding-dino.zip) |
| [cellsight-detection-threshold-boxes](../skills/cellsight-detection-threshold-boxes/SKILL.md) | `threshold-boxes` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-detection-threshold-boxes.zip) |

## 图像分割（13）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-segmentation-threshold-cc](../skills/cellsight-segmentation-threshold-cc/SKILL.md) | `threshold-cc` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-threshold-cc.zip) |
| [cellsight-segmentation-watershed](../skills/cellsight-segmentation-watershed/SKILL.md) | `watershed` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-watershed.zip) |
| [cellsight-segmentation-cellpose-sam](../skills/cellsight-segmentation-cellpose-sam/SKILL.md) | `cellpose-sam` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-cellpose-sam.zip) |
| [cellsight-segmentation-cellpose-dino](../skills/cellsight-segmentation-cellpose-dino/SKILL.md) | `cellpose-dino` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-cellpose-dino.zip) |
| [cellsight-segmentation-stardist](../skills/cellsight-segmentation-stardist/SKILL.md) | `stardist` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-stardist.zip) |
| [cellsight-segmentation-sam](../skills/cellsight-segmentation-sam/SKILL.md) | `sam` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-segmentation-sam.zip) |
| [cellsight-segmentation-sam2](../skills/cellsight-segmentation-sam2/SKILL.md) | `sam2` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-segmentation-sam2.zip) |
| [cellsight-segmentation-sam3](../skills/cellsight-segmentation-sam3/SKILL.md) | `sam3` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-segmentation-sam3.zip) |
| [cellsight-segmentation-yolo-seg](../skills/cellsight-segmentation-yolo-seg/SKILL.md) | `yolo-seg` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-yolo-seg.zip) |
| [cellsight-segmentation-maskrcnn](../skills/cellsight-segmentation-maskrcnn/SKILL.md) | `maskrcnn` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-segmentation-maskrcnn.zip) |
| [cellsight-segmentation-unet](../skills/cellsight-segmentation-unet/SKILL.md) | `unet` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-segmentation-unet.zip) |
| [cellsight-segmentation-nnunet](../skills/cellsight-segmentation-nnunet/SKILL.md) | `nnunet` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-segmentation-nnunet.zip) |
| [cellsight-segmentation-segformer](../skills/cellsight-segmentation-segformer/SKILL.md) | `segformer` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-segmentation-segformer.zip) |

## 图像分类（7）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-classification-resnet](../skills/cellsight-classification-resnet/SKILL.md) | `resnet` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-classification-resnet.zip) |
| [cellsight-classification-efficientnet](../skills/cellsight-classification-efficientnet/SKILL.md) | `efficientnet` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-classification-efficientnet.zip) |
| [cellsight-classification-mobilenet](../skills/cellsight-classification-mobilenet/SKILL.md) | `mobilenet` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-classification-mobilenet.zip) |
| [cellsight-classification-convnext](../skills/cellsight-classification-convnext/SKILL.md) | `convnext` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-classification-convnext.zip) |
| [cellsight-classification-vit](../skills/cellsight-classification-vit/SKILL.md) | `vit` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-classification-vit.zip) |
| [cellsight-classification-swin](../skills/cellsight-classification-swin/SKILL.md) | `swin` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-classification-swin.zip) |
| [cellsight-classification-dinov3-linear](../skills/cellsight-classification-dinov3-linear/SKILL.md) | `dinov3-linear` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-classification-dinov3-linear.zip) |

## 目标追踪（4）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-tracking-iou-tracker](../skills/cellsight-tracking-iou-tracker/SKILL.md) | `iou-tracker` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-tracking-iou-tracker.zip) |
| [cellsight-tracking-bytetrack](../skills/cellsight-tracking-bytetrack/SKILL.md) | `bytetrack` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-tracking-bytetrack.zip) |
| [cellsight-tracking-deepsort](../skills/cellsight-tracking-deepsort/SKILL.md) | `deepsort` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-tracking-deepsort.zip) |
| [cellsight-tracking-trackmate](../skills/cellsight-tracking-trackmate/SKILL.md) | `trackmate` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-tracking-trackmate.zip) |

## 图像处理（10）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-processing-identity](../skills/cellsight-processing-identity/SKILL.md) | `identity` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-identity.zip) |
| [cellsight-processing-percentile-normalize](../skills/cellsight-processing-percentile-normalize/SKILL.md) | `percentile-normalize` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-percentile-normalize.zip) |
| [cellsight-processing-gaussian](../skills/cellsight-processing-gaussian/SKILL.md) | `gaussian` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-gaussian.zip) |
| [cellsight-processing-median-filter](../skills/cellsight-processing-median-filter/SKILL.md) | `median-filter` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-median-filter.zip) |
| [cellsight-processing-clahe](../skills/cellsight-processing-clahe/SKILL.md) | `clahe` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-clahe.zip) |
| [cellsight-processing-morph-opening](../skills/cellsight-processing-morph-opening/SKILL.md) | `morph-opening` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-morph-opening.zip) |
| [cellsight-processing-morph-closing](../skills/cellsight-processing-morph-closing/SKILL.md) | `morph-closing` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-morph-closing.zip) |
| [cellsight-processing-crop](../skills/cellsight-processing-crop/SKILL.md) | `crop` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-crop.zip) |
| [cellsight-processing-flatfield](../skills/cellsight-processing-flatfield/SKILL.md) | `flatfield` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-processing-flatfield.zip) |
| [cellsight-processing-registration](../skills/cellsight-processing-registration/SKILL.md) | `registration` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-processing-registration.zip) |

## 图像复原（6）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-restoration-median-denoise](../skills/cellsight-restoration-median-denoise/SKILL.md) | `median-denoise` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-restoration-median-denoise.zip) |
| [cellsight-restoration-nlmeans](../skills/cellsight-restoration-nlmeans/SKILL.md) | `nlmeans` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-restoration-nlmeans.zip) |
| [cellsight-restoration-richardson-lucy](../skills/cellsight-restoration-richardson-lucy/SKILL.md) | `richardson-lucy` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-restoration-richardson-lucy.zip) |
| [cellsight-restoration-care](../skills/cellsight-restoration-care/SKILL.md) | `care` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-restoration-care.zip) |
| [cellsight-restoration-noise2void](../skills/cellsight-restoration-noise2void/SKILL.md) | `noise2void` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-restoration-noise2void.zip) |
| [cellsight-restoration-restormer](../skills/cellsight-restoration-restormer/SKILL.md) | `restormer` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-restoration-restormer.zip) |

## 视觉语言与特征（5）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-vision-language-clip](../skills/cellsight-vision-language-clip/SKILL.md) | `clip` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-vision-language-clip.zip) |
| [cellsight-vision-language-biomedclip](../skills/cellsight-vision-language-biomedclip/SKILL.md) | `biomedclip` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-vision-language-biomedclip.zip) |
| [cellsight-vision-language-siglip](../skills/cellsight-vision-language-siglip/SKILL.md) | `siglip` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-vision-language-siglip.zip) |
| [cellsight-vision-language-dinov3](../skills/cellsight-vision-language-dinov3/SKILL.md) | `dinov3` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-vision-language-dinov3.zip) |
| [cellsight-vision-language-vlm](../skills/cellsight-vision-language-vlm/SKILL.md) | `vlm` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-vision-language-vlm.zip) |

## 科学定量（4）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-quantification-morphology](../skills/cellsight-quantification-morphology/SKILL.md) | `morphology` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-quantification-morphology.zip) |
| [cellsight-quantification-fluorescence](../skills/cellsight-quantification-fluorescence/SKILL.md) | `fluorescence` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-quantification-fluorescence.zip) |
| [cellsight-quantification-regionprops](../skills/cellsight-quantification-regionprops/SKILL.md) | `regionprops` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-quantification-regionprops.zip) |
| [cellsight-quantification-spatial-statistics](../skills/cellsight-quantification-spatial-statistics/SKILL.md) | `spatial-statistics` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-quantification-spatial-statistics.zip) |

## 异常与缺陷检测（3）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-anomaly-patchcore](../skills/cellsight-anomaly-patchcore/SKILL.md) | `patchcore` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-anomaly-patchcore.zip) |
| [cellsight-anomaly-padim](../skills/cellsight-anomaly-padim/SKILL.md) | `padim` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-anomaly-padim.zip) |
| [cellsight-anomaly-efficientad](../skills/cellsight-anomaly-efficientad/SKILL.md) | `efficientad` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-anomaly-efficientad.zip) |

## 关键点与姿态（3）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-pose-yolo-pose](../skills/cellsight-pose-yolo-pose/SKILL.md) | `yolo-pose` | 有；仍须核实运行条件 | [ZIP](../upload-zips/cellsight-pose-yolo-pose.zip) |
| [cellsight-pose-mmpose](../skills/cellsight-pose-mmpose/SKILL.md) | `mmpose` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-pose-mmpose.zip) |
| [cellsight-pose-deeplabcut](../skills/cellsight-pose-deeplabcut/SKILL.md) | `deeplabcut` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-pose-deeplabcut.zip) |

## 图像文字识别（3）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-ocr-paddleocr](../skills/cellsight-ocr-paddleocr/SKILL.md) | `paddleocr` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-ocr-paddleocr.zip) |
| [cellsight-ocr-tesseract](../skills/cellsight-ocr-tesseract/SKILL.md) | `tesseract` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-ocr-tesseract.zip) |
| [cellsight-ocr-easyocr](../skills/cellsight-ocr-easyocr/SKILL.md) | `easyocr` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-ocr-easyocr.zip) |

## 深度估计（2）

| Skill | 实现 ID | 包内适配器 | 上传包 |
|---|---|---|---|
| [cellsight-depth-depth-anything-v2](../skills/cellsight-depth-depth-anything-v2/SKILL.md) | `depth-anything-v2` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-depth-depth-anything-v2.zip) |
| [cellsight-depth-midas](../skills/cellsight-depth-midas/SKILL.md) | `midas` | 无；使用原生流程 | [ZIP](../upload-zips/cellsight-depth-midas.zip) |
