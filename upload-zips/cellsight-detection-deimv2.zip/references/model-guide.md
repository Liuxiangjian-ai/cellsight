# DEIMv2

`implementation_id: deimv2` · 框架：official-repository · 支持任务：detect

## 选用条件与边界

使用各自框架；不能以YOLO权重名替换。检查输入限制、类别映射和查询上限。

## 执行配方

RF-DETR：当前API可从本地checkpoint恢复，用predict返回的xyxy/class_id/confidence映射产物；训练使用COCO数据目录与model.train(dataset_dir=...,epochs=...)，按版本核对from_checkpoint及模型类。DEIMv2/D-FINE：固定官方commit和模型配置，准备COCO annotations与images，按该commit的train.py帮助设置config和checkpoint；推理使用同commit的部署/推理入口。保存原生预测再转换成统一原图坐标，先对一张标注图检查类别和缩放。

本包模式：predict, train。内置CLI模式：无；按上述原生配方执行并适配标准产物。

依赖探测模块：torch。权重要求：本地预先提供，许可及哈希单独记录。

## 参数与前置条件

先探测已安装版本的实际API；不要根据本文猜测未安装模块已可运行。内置adapter只暴露代码中接受的参数；其他模式走原生流程。保留类映射、输入尺度、归一化、阈值、坐标与资源记录。容量变体不能算独立架构。

训练时按任务提供复核框、实例掩膜或类别标签；记录样品级划分、初始化权重、优化器、有效batch、轮次与早停。纯推理条目不因为底层存在其他能力就被当作本包训练适配器。

## 交付与评价接口

提交真实预测/掩膜/特征/表格、effective request、模型来源与依赖版本。所需评价契约类型：`detection`；具体指标由主控与Eval约定。本技能不自签通过，缺失真值不生成监督指标。运行失败保存错误和未完成状态，不用其他算法的结果冒充本模型。

## 官方依据

- https://github.com/Intellindust-AI-Lab/DEIMv2

资料整理日期：2026-10-25。原生API与权重兼容性未全部实测，SciencePal环境和科研性能适用性尚未验证；实际执行按所选版本官方资料核对。第三方代码与权重许可证分别核查，本包不分发权重。
