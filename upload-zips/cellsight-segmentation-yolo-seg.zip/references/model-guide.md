# YOLO实例分割

`implementation_id: yolo-seg` · 框架：ultralytics · 支持任务：instance_segment

## 选用条件与边界

必须使用-seg权重和实例标注；重叠掩膜以独立mask stack保留。

## 执行配方

YOLO(local_seg_weights).predict；训练使用YOLO多边形实例标注与data YAML。mask与原图尺寸不同需最近邻还原；polygon、阈值和实例顺序要记录。

本包模式：predict, train。内置CLI模式：predict。

依赖探测模块：numpy, PIL, ultralytics。权重要求：本地预先提供，许可及哈希单独记录。

## 参数与前置条件

先探测已安装版本的实际API；不要根据本文猜测未安装模块已可运行。内置adapter只暴露代码中接受的参数；其他模式走原生流程。保留类映射、输入尺度、归一化、阈值、坐标与资源记录。容量变体不能算独立架构。

训练时按任务提供复核框、实例掩膜或类别标签；记录样品级划分、初始化权重、优化器、有效batch、轮次与早停。纯推理条目不因为底层存在其他能力就被当作本包训练适配器。

## 交付与评价接口

提交真实预测/掩膜/特征/表格、effective request、模型来源与依赖版本。所需评价契约类型：`instance_segmentation`；具体指标由主控与Eval约定。本技能不自签通过，缺失真值不生成监督指标。运行失败保存错误和未完成状态，不用其他算法的结果冒充本模型。

## 官方依据

- https://docs.ultralytics.com/models/

资料整理日期：2026-10-25。原生API与权重兼容性未全部实测，SciencePal环境和科研性能适用性尚未验证；实际执行按所选版本官方资料核对。第三方代码与权重许可证分别核查，本包不分发权重。
