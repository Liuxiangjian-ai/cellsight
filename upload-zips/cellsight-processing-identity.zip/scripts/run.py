"""CellSight execution protocol v1.0. No model downloads or installs are performed."""
from __future__ import annotations
import argparse
import csv
import hashlib
import importlib.metadata
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import sys
import time
from datetime import datetime, timezone
VERSION = '0.2.1'
ROOT = Path(__file__).resolve().parents[1]

class Blocked(ValueError):
    pass

def require(condition, message):
    if not condition:
        raise Blocked(message)

def read_json(path):
    with Path(path).open(encoding='utf-8-sig') as f:
        return json.load(f)

def write_json(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, ensure_ascii=False, indent=2, allow_nan=False)
        f.write('\n')

def sha_file(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()

def sha_json(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, ensure_ascii=False, allow_nan=False).encode()).hexdigest()

def implementations():
    return read_json(ROOT / 'assets' / 'implementations.json')['implementations']

def lookup(identifier):
    return next((m for m in implementations() if m['id'] == identifier), None)

def package_state(module):
    try:
        present = importlib.util.find_spec(module) is not None
    except (ImportError, ValueError):
        present = False
    distributions = {'PIL': 'Pillow', 'cv2': 'opencv-python', 'skimage': 'scikit-image'}
    try:
        version = importlib.metadata.version(distributions.get(module, module))
    except importlib.metadata.PackageNotFoundError:
        version = None
    return {'module': module, 'installed': present, 'version': version}

def probe(identifier=None):
    items = [lookup(identifier)] if identifier else implementations()
    require(all(items), 'Unknown implementation_id for this skill.')
    return {'schema_version': '1.0', 'observed_at': datetime.now(timezone.utc).isoformat(), 'python': sys.version.split()[0], 'platform': platform.platform(), 'probe_scope': 'import_discovery_only_not_runtime_or_gpu_validation', 'implementations': [{'id': m['id'], 'adapter_implemented': m['adapter'] is not None, 'adapter_modes': m['adapter_modes'], 'dependencies': [package_state(p) for p in m['dependencies']], 'weights_available': None if m['requires_weights'] else True, 'device_compatible': None, 'ready': False, 'scientific_validation': 'not_established'} for m in items]}

def validate_request(req, request_dir):
    require(isinstance(req, dict) and req.get('schema_version') == '1.0', 'Unsupported request schema_version.')
    for k in ['experiment_id', 'request_id', 'dataset_version', 'implementation_id', 'task', 'mode']:
        require(isinstance(req.get(k), str) and bool(req[k].strip()), f'Missing {k}.')
    m = lookup(req['implementation_id'])
    require(m is not None, 'Implementation is not registered in this skill.')
    require(req['task'] in m['tasks'], 'Implementation/task mismatch.')
    require(req['mode'] in m['documented_modes'], 'Unsupported documented mode.')
    require(req.get('allow_download', False) is False, 'Runner is offline-only. Provision weights separately.')
    inputs = req.get('inputs')
    require(isinstance(inputs, list) and len(inputs) > 0, 'inputs must be a nonempty array.')
    seen = set()
    for item in inputs:
        require(isinstance(item, dict), 'Each input must be an object.')
        require(isinstance(item.get('artifact_id'), str) and item['artifact_id'], 'Input artifact_id required.')
        require(item['artifact_id'] not in seen, 'Duplicate input artifact_id.')
        seen.add(item['artifact_id'])
        require(isinstance(item.get('path'), str) and bool(item['path']), 'Local input path required.')
        require(not item['path'].startswith(('http://', 'https://', 's3://')), 'Resolve resource refs to local files first.')
        path = resolve_input(item['path'], request_dir)
        require(path.is_file(), f'Input file does not exist: {path}')
        require(item.get('type') in {'image', 'instance_masks', 'detections', 'points', 'table'}, 'Unknown input type.')
        if item['type'] in {'image', 'instance_masks'}:
            require(item.get('axes') in {'YX', 'YXC', 'ZYX', 'ZYXC', 'TZYX', 'TYXC'}, 'Explicit supported image axes required.')
            require(isinstance(item.get('space_id'), str) and bool(item['space_id']), 'Image/mask space_id required.')
        if 'sha256' in item:
            require(sha_file(path) == item['sha256'], 'Input content hash mismatch.')
    require(isinstance(req.get('params', {}), dict), 'params must be an object.')
    require(isinstance(req.get('model', {}), dict), 'model must be an object.')
    require(isinstance(req.get('eval_contract_ref'), str) and bool(req['eval_contract_ref']), 'eval_contract_ref required; this is a reference, not proof of approval.')
    contract = resolve_input(req['eval_contract_ref'], request_dir)
    require(contract.is_file(), 'Eval contract reference must resolve to an existing JSON file.')
    ec = read_json(contract)
    require(ec.get('schema_version') == '1.0', 'Unsupported eval contract schema_version.')
    evidence = ec.get('required_evidence')
    require(isinstance(evidence, list) and evidence and all((isinstance(x, str) and x for x in evidence)), 'Eval contract required_evidence must be explicit.')
    require(ec.get('experiment_id') == req['experiment_id'], 'Eval contract experiment_id mismatch.')
    require(ec.get('dataset_version') == req['dataset_version'], 'Eval contract dataset_version mismatch.')
    require(req['task'] in ec.get('tasks', []), 'Task missing from eval contract.')
    require(ec.get('status') == 'agreed', 'Eval contract has not been agreed.')
    budget = req.get('budget')
    require(isinstance(budget, dict), 'Budget required.')
    seconds = budget.get('wall_time_seconds')
    require(isinstance(seconds, (int, float)) and (not isinstance(seconds, bool)) and math.isfinite(seconds) and (seconds > 0), 'Positive finite wall_time_seconds required.')
    require(budget.get('device') in {'cpu', 'cuda', 'mps'}, 'Explicit cpu/cuda/mps device required.')
    if req['mode'] == 'train':
        manifest = read_json(resolve_input(req.get('training_manifest_ref', ''), request_dir))
        groups = {}
        splits = set()
        for row in manifest.get('images', []):
            require(row.get('annotation_source') in {'human', 'human_reviewed'}, 'Training labels need human review.')
            group, split = (row.get('sample_group'), row.get('split'))
            require(group and split in {'train', 'val', 'test'}, 'Training sample_group/split missing.')
            require(group not in groups or groups[group] == split, 'Sample leakage across splits.')
            groups[group] = split
            splits.add(split)
        require({'train', 'val'} <= splits, 'Train and validation records required.')
    return m

def resolve_input(path, base):
    p = Path(path).expanduser()
    return (p if p.is_absolute() else Path(base) / p).resolve()

def load_array(item, base):
    import numpy as np
    p = resolve_input(item['path'], base)
    if p.suffix.lower() == '.npy':
        arr = np.load(p, allow_pickle=False)
    elif p.suffix.lower() in {'.tif', '.tiff'}:
        import tifffile
        arr = tifffile.imread(p)
    else:
        from PIL import Image
        with Image.open(p) as im:
            require(getattr(im, 'n_frames', 1) == 1, 'Use tifffile for multipage data.')
            arr = np.asarray(im).copy()
    require(arr.dtype.kind in 'buif' and np.isfinite(arr).all(), 'Finite numeric image required.')
    axes = item['axes']
    require(arr.ndim == len(axes), 'Declared axes disagree with array dimensions.')
    return arr

def image_item(req, kind='image'):
    items = [i for i in req['inputs'] if i['type'] == kind]
    selected = req.get('params', {}).get('image_artifact_id' if kind == 'image' else 'mask_artifact_id')
    if selected:
        items = [i for i in items if i['artifact_id'] == selected]
    require(len(items) == 1, f'This adapter expects exactly one {kind} input per request; submit separate requests for a batch.')
    return items[0]

def image2d(req, base):
    item = image_item(req)
    require(item['axes'] == 'YX', 'This adapter requires an explicitly selected single 2D channel (YX).')
    return (item, load_array(item, base))

def artifact(path, kind, source=None, **extra):
    out = {'artifact_id': path.stem, 'path': str(path.resolve()), 'type': kind, 'sha256': sha_file(path)}
    if source:
        out.update({'source_artifact_id': source['artifact_id'], 'space_id': source.get('space_id')})
    out.update(extra)
    return out

def save_array(outdir, name, arr, kind, source, **extra):
    import numpy as np
    p = outdir / (name + '.npy')
    np.save(p, arr, allow_pickle=False)
    return artifact(p, kind, source, axes='YX', shape=list(arr.shape), dtype=str(arr.dtype), **extra)

def processing(req, base, outdir):
    import numpy as np
    item, arr = image2d(req, base)
    p = req.get('params', {})
    op = p.get('operation', 'identity')
    quant_ok = op == 'identity' and item.get('intensity_role') in {'raw', 'validated_corrected'}
    extras = {}
    if op == 'identity':
        result = arr.copy()
    elif op == 'percentile':
        low, high = p.get('percentiles', [1, 99])
        require(0 <= low < high <= 100, 'Invalid percentile range.')
        a, b = np.percentile(arr, [low, high])
        result = np.zeros_like(arr, dtype=np.float32) if b == a else np.clip((arr.astype(float) - a) / (b - a), 0, 1).astype(np.float32)
    elif op in {'gaussian', 'median', 'clahe', 'opening', 'closing'}:
        import cv2
        if op == 'gaussian':
            sigma = float(p.get('sigma', 1))
            require(sigma > 0, 'sigma must be positive.')
            result = cv2.GaussianBlur(arr.astype(np.float32), (0, 0), sigma)
        elif op == 'median':
            size = int(p.get('kernel', 3))
            require(size in {3, 5}, 'Median kernel currently supports 3 or 5.')
            result = cv2.medianBlur(arr.astype(np.float32), size)
        elif op == 'clahe':
            require(arr.dtype in {np.dtype('uint8'), np.dtype('uint16')}, 'CLAHE requires uint8/uint16.')
            result = cv2.createCLAHE(clipLimit=float(p.get('clip_limit', 2)), tileGridSize=(8, 8)).apply(arr)
        else:
            size = int(p.get('kernel', 3))
            require(size > 0 and size % 2 == 1, 'Odd positive morphology kernel required.')
            result = cv2.morphologyEx(arr.astype(np.float32), cv2.MORPH_OPEN if op == 'opening' else cv2.MORPH_CLOSE, np.ones((size, size), np.uint8))
    elif op == 'crop':
        x0, y0, x1, y1 = p['bbox_xyxy']
        require(all((type(v) is int for v in (x0, y0, x1, y1))) and 0 <= x0 < x1 <= arr.shape[1] and (0 <= y0 < y1 <= arr.shape[0]), 'Invalid crop bounds.')
        result = arr[y0:y1, x0:x1].copy()
        extras = {'space_id': item['space_id'] + ':crop', 'transform_to_parent': {'type': 'translation', 'x': x0, 'y': y0}}
        quant_ok = item.get('intensity_role') in {'raw', 'validated_corrected'}
    elif op == 'flatfield':
        require(p.get('calibration_ref'), 'Flat-field correction needs a recorded calibration_ref.')
        flat_item = next((i for i in req['inputs'] if i['artifact_id'] == p.get('flat_artifact_id')), None)
        require(flat_item is not None, 'Flat-field artifact not found.')
        flat = load_array(flat_item, base).astype(float)
        require(flat.shape == arr.shape, 'Flat-field shape mismatch.')
        dark = float(p.get('dark_offset', 0))
        denom = flat - dark
        require(np.all(denom > 0), 'Flat-field minus dark must be positive.')
        result = ((arr.astype(float) - dark) * denom.mean() / denom).astype(np.float32)
        quant_ok = item.get('intensity_role') in {'raw', 'validated_corrected'}
    else:
        raise Blocked('Unsupported processing operation.')
    role = item.get('intensity_role', 'unknown') if op in {'identity', 'crop'} else 'validated_corrected' if quant_ok else 'model_input_only'
    art = save_array(outdir, 'processed', result, 'image', item, intensity_role=role, processing_history=[*item.get('processing_history', []), {'operation': op, 'params': p}], quantitative_intensity_eligible=quant_ok, **extras)
    return ([art], {'operation': op}, [] if quant_ok else ['Not validated for fluorescence intensity quantification.'])
HANDLERS = {'processing': processing}

def run(request_path, outdir):
    started = time.monotonic()
    req = read_json(request_path)
    base = Path(request_path).resolve().parent
    outdir = Path(outdir).resolve()
    require(not outdir.exists(), 'Output directory already exists; use a fresh directory to preserve history.')
    m = validate_request(req, base)
    original_request_hash = sha_json(req)
    req['params'] = {**m.get('default_params', {}), **req.get('params', {})}
    if 'operation' in m.get('default_params', {}):
        require(req['params']['operation'] == m['default_params']['operation'], 'Operation does not match selected implementation.')
    require(m['adapter'] in HANDLERS and req['mode'] in m['adapter_modes'], 'No built-in adapter for this implementation/mode. Follow the versioned native workflow in references; do not report a run as completed.')
    for dep in m['dependencies']:
        require(package_state(dep)['installed'], f'Dependency missing: {dep}')
    outdir.mkdir(parents=True)
    write_json(outdir / 'request.json', req)
    provenance = []
    for inp in req['inputs']:
        provenance.append({'artifact_id': inp['artifact_id'], 'path': str(resolve_input(inp['path'], base)), 'sha256': sha_file(resolve_input(inp['path'], base))})
    model = req.get('model', {})
    weight = model.get('weights_path')
    if weight:
        wp = resolve_input(weight, base)
        if wp.is_file():
            provenance.append({'artifact_id': 'model_weights', 'path': str(wp), 'sha256': sha_file(wp)})
        elif wp.is_dir():
            for f in sorted(wp.rglob('*')):
                if f.is_file():
                    provenance.append({'artifact_id': 'model_file', 'path': str(f), 'sha256': sha_file(f)})
    env = {'python': sys.version, 'platform': platform.platform(), 'packages': [package_state(d) for d in m['dependencies']]}
    write_json(outdir / 'environment.json', env)
    ec = resolve_input(req['eval_contract_ref'], base)
    write_json(outdir / 'eval-contract.snapshot.json', read_json(ec))
    result = {'schema_version': '1.0', 'library_version': VERSION, 'experiment_id': req['experiment_id'], 'request_id': req['request_id'], 'dataset_version': req['dataset_version'], 'implementation_id': m['id'], 'task': req['task'], 'mode': req['mode'], 'request_hash': sha_json(req), 'original_request_hash': original_request_hash, 'eval_contract_sha256': sha_file(ec), 'status': 'running', 'artifacts': [], 'provenance': provenance, 'warnings': [], 'evaluation_status': 'not_evaluated', 'scientific_validation': 'not_established', 'started_at': datetime.now(timezone.utc).isoformat(), 'error': None}
    try:
        artifacts, summary, warnings = HANDLERS[m['adapter']](req, base, outdir)
        require(all((Path(a['path']).is_file() and sha_file(a['path']) == a['sha256'] for a in artifacts)), 'Output artifact missing or hash mismatch.')
        result.update(status='succeeded', artifacts=artifacts, summary=summary, warnings=warnings)
    except Exception as exc:
        result.update(status='blocked' if isinstance(exc, Blocked) else 'failed', error={'type': type(exc).__name__, 'message': str(exc)})
    result['wall_time_seconds'] = time.monotonic() - started
    if result['wall_time_seconds'] > req['budget']['wall_time_seconds']:
        result['warnings'].append('Wall-time budget exceeded. Runner reports overrun; external supervisor is needed for hard timeout.')
        if result['status'] == 'succeeded':
            result['status'] = 'budget_exhausted'
    write_json(outdir / 'result.json', result)
    with (outdir / 'events.jsonl').open('x', encoding='utf-8') as f:
        f.write(json.dumps({'stage': 'execute', 'status': result['status'], 'request_hash': result['request_hash'], 'elapsed': result['wall_time_seconds']}, ensure_ascii=False) + '\n')
    return result

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('list')
    p = commands.add_parser('probe')
    p.add_argument('--implementation')
    p = commands.add_parser('validate-request')
    p.add_argument('--request', required=True)
    p = commands.add_parser('run')
    p.add_argument('--request', required=True)
    p.add_argument('--output', required=True)
    args = parser.parse_args()
    try:
        if args.command == 'list':
            output = {'implementations': implementations()}
        elif args.command == 'probe':
            output = probe(args.implementation)
        elif args.command == 'validate-request':
            req = read_json(args.request)
            m = validate_request(req, Path(args.request).resolve().parent)
            output = {'status': 'request_metadata_validated', 'implementation_id': m['id'], 'execution_performed': False, 'evaluation_status': 'not_evaluated'}
        else:
            output = run(args.request, args.output)
        print(json.dumps(output, ensure_ascii=False, indent=2, allow_nan=False))
        return 0 if output.get('status') not in {'failed', 'blocked', 'budget_exhausted'} else 2
    except Exception as exc:
        print(json.dumps({'status': 'blocked' if isinstance(exc, Blocked) else 'failed', 'error': {'type': type(exc).__name__, 'message': str(exc)}, 'execution_performed': False}, ensure_ascii=False), file=sys.stderr)
        return 2
if __name__ == '__main__':
    raise SystemExit(main())
