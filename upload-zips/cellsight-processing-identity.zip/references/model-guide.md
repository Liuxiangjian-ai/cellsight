# 保留原值副本

`implementation_id: identity` · 框架：numpy/opencv · 支持任务：process

## 选用条件与边界

必须输出处理历史；除保值裁剪与经验证校正外，默认model_input_only。

## 执行配方

使用内置run入口；operation由implementation固定。crop提供整数bbox_xyxy并记录到父图的平移；flatfield提供flat_artifact_id、image_artifact_id和calibration_ref，公式(raw-dark)*mean(flat-dark)/(flat-dark)，拒绝分母非正。

本包模式：predict。内置CLI模式：predict。

依赖探测模块：numpy。权重要求：无模型权重。

## 参数与前置条件

先探测已安装版本的实际API；不要根据本文猜测未安装模块已可运行。内置adapter只暴露代码中接受的参数；其他模式走原生流程。保留类映射、输入尺度、归一化、阈值、坐标与资源记录。容量变体不能算独立架构。

训练时按任务提供复核框、实例掩膜或类别标签；记录样品级划分、初始化权重、优化器、有效batch、轮次与早停。纯推理条目不因为底层存在其他能力就被当作本包训练适配器。

## 交付与评价接口

提交真实预测/掩膜/特征/表格、effective request、模型来源与依赖版本。所需评价契约类型：`processing_integrity`；具体指标由主控与Eval约定。本技能不自签通过，缺失真值不生成监督指标。运行失败保存错误和未完成状态，不用其他算法的结果冒充本模型。

## 官方依据

- https://docs.opencv.org/4.x/d4/d13/tutorial_py_filtering.html

资料整理日期：2026-10-25。原生API与权重兼容性未全部实测，SciencePal环境和科研性能适用性尚未验证；实际执行按所选版本官方资料核对。第三方代码与权重许可证分别核查，本包不分发权重。
