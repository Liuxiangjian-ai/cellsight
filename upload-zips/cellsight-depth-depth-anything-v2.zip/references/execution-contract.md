# CellSight 执行契约 v1.0

本技能执行任务，不作最终科研验收。先读取真实请求与Eval契约，不能自行降低目标或把status=agreed当作已经通过科学审计。

## 请求

必需schema_version=1.0、experiment_id、request_id、dataset_version、implementation_id、task、mode、inputs、eval_contract_ref、budget。JSON Schema在assets/request.schema.json。

每项输入通过artifact_id、type和本地path传递；路径相对请求JSON所在目录解释，不相对skill目录。图像声明axes与space_id。YX=单通道二维，YXC=RGB或显式通道，ZYX=体数据；脚本当前只暴露明确支持的二维适配器，不猜测TIFF通道。TIFF依赖tifffile；.npy使用allow_pickle=False。

输入可以附sha256，运行器读取真实文件重新计算。instance_masks为背景0、正整数ID；mask stack为IYX独立掩膜，不可在重叠区域静默压成单一标签。当前定量脚本只接受整数YX实例图；mask stack若需定量，先明确重叠策略并生成有来源的新实例图，不能静默转换。

Eval契约是现有JSON文件，至少含schema_version、experiment_id、dataset_version、tasks、status=agreed和required_evidence。执行器只核对元数据与引用并保存哈希，不对上传者身份、规则正确性或签名作认证。

model包含本地weights_path；Torchvision另需architecture与classes有序列表，分类另需input_size/mean/std。运行器不安装依赖、不下载权重、不连接外部服务。原生工作流也遵守数据驻留与资源约束，不自行上传科研图像。

## 返回与交接

result.json保存请求哈希、契约哈希、输入/权重来源、依赖版本、实际耗时、artifacts、warnings与error。artifacts逐项包括path/type/sha256，图像额外包含axes/space_id/shape/dtype及来源。

status区分succeeded、blocked、failed、budget_exhausted。成功只代表执行产物存在，不代表科学结论合格；evaluation_status始终为not_evaluated。没有真值时不生成Precision/Recall/AP。没有实例分数时score=null。

输出目录必须不存在；输入原图、标注和历史结果不覆盖。request_id应由主控保持唯一；当前CLI拒绝复用输出目录，但不提供跨目录的全局作业去重/异步作业数据库。耗时在结束后核对预算，硬超时/显存限制由运行环境监督，不能声称提示词能保证。

坐标使用原图像素。裁剪产生新space_id与回父图的变换。上游路径更新后下游需要明确接入，不会自动搜索最近一次文件。权重许可与代码许可分别记录；不复制第三方权重。

## 公共科学检查

训练使用人工确认标签与独立样品分组；先分组再裁块。验证集选权重、阈值和处理参数，锁定后才独立测试。标签或处理链改变产生新版本。运行器的元数据检查不代替真实漏标、近重复与样品归属审计。

测量保持instance_id、通道、位深、空间单位。增强/去噪副本用于分割时，掩膜映射回原始坐标后在原始/验证校正强度上测量。原图声明可能被错误填写，仍需Eval复核来源与处理历史。

参考：https://pmc.ncbi.nlm.nih.gov/articles/PMC2712964/ ；https://agentskills.io/specification
